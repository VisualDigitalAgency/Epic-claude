"""
EPIC-Claude CLI entry point.

Registered as `epic-claude` in pyproject.toml [project.scripts].

Execution model: per-command, per-invocation. No background daemon. No ports.
All writes are atomic. Safe to kill at any time.
"""

from __future__ import annotations
import sys

try:
    import typer
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    from rich.table import Table
    _RICH = True
except ImportError:
    typer = None   # type: ignore
    _RICH = False
    class Console:  # type: ignore
        def print(self, *a, **kw):
            import re; s = str(a[0]) if a else ""; print(re.sub(r"[[][^]]*[]]", "", s))
    class Panel:  # type: ignore
        def __init__(self, *a, **kw): pass
    class Text:  # type: ignore
        def __init__(self, t="", **kw): self.t = t
    class Table:  # type: ignore
        def __init__(self, *a, **kw): pass
        def add_column(self, *a, **kw): pass
        def add_row(self, *a, **kw): pass

from epic_claude import __version__

# ---------------------------------------------------------------------------
# Lazy helpers
# ---------------------------------------------------------------------------

def _bootstrap_home() -> None:
    from epic_claude.registry import bootstrap_home; bootstrap_home()

def _home_is_initialised() -> bool:
    from epic_claude.registry import home_is_initialised; return home_is_initialised()

def _get_home_path() -> str:
    from epic_claude.registry import EPIC_CLAUDE_HOME; return str(EPIC_CLAUDE_HOME)

def _load_config():
    from epic_claude.config import load_config; return load_config()

# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

if typer is None:
    raise ImportError(
        "typer is required to run epic-claude. Install with: pipx install epic-claude"
    )

app = typer.Typer(
    name="epic-claude",
    help="Universal AI Solutions Architect for Claude Code — Global MCP Server.",
    add_completion=True,
    rich_markup_mode="rich" if _RICH else None,
    no_args_is_help=False,
)

console     = Console()
err_console = Console()

# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------

try:
    from epic_claude.cli.serve       import serve_app
    from epic_claude.cli.projects    import projects_app
    from epic_claude.cli.stack_cmd   import stack_app
    from epic_claude.cli.memory_cmd  import memory_app
    from epic_claude.cli.sync_cmd    import sync_app
    from epic_claude.cli.status_cmd  import status_app
    from epic_claude.cli.migrate_cmd  import migrate_app
    from epic_claude.cli.generate_cmd import generate_app

    app.add_typer(serve_app,    name="serve",    no_args_is_help=False)
    app.add_typer(projects_app, name="projects", no_args_is_help=True)
    app.add_typer(stack_app,    name="stack",    no_args_is_help=True)
    app.add_typer(memory_app,   name="memory",   no_args_is_help=True)
    app.add_typer(sync_app,     name="sync",     no_args_is_help=False)
    app.add_typer(status_app,   name="status",   no_args_is_help=False)
    if migrate_app:
        app.add_typer(migrate_app,  name="migrate",  no_args_is_help=False)
    if generate_app:
        app.add_typer(generate_app, name="generate", no_args_is_help=False)
except Exception:
    pass

# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@app.command()
def version() -> None:
    """Show version, Python, and platform info."""
    import platform
    if _RICH:
        console.print(Panel(
            f"[bold cyan]EPIC-Claude v{__version__}[/bold cyan]\n"
            f"[dim]Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
            f" · {platform.system()} {platform.machine()}[/dim]\n"
            f"[dim]State: {_get_home_path()}[/dim]",
            subtitle="[dim]Universal AI Solutions Architect[/dim]",
            border_style="cyan",
        ))
    else:
        print(f"epic-claude v{__version__}")


@app.command()
def init() -> None:
    """Initialise the global registry. Safe to run multiple times."""
    _bootstrap_home()
    try:
        cfg = _load_config(); model = cfg.llm_model; db_eng = cfg.db_engine
    except Exception:
        model = "claude-sonnet-4-20250514"; db_eng = "sqlite"

    home = _get_home_path()
    if _RICH:
        console.print(Panel(
            f"[green]✓[/green] EPIC-Claude home initialised\n"
            f"[dim]Path:[/dim]      {home}\n"
            f"[dim]Model:[/dim]     {model}\n"
            f"[dim]DB engine:[/dim] {db_eng}\n\n"
            "[dim]Next steps:[/dim]\n"
            "  [cyan]export ANTHROPIC_API_KEY=your-key[/cyan]\n"
            "  [cyan]epic-claude plan \"describe your project\"[/cyan]",
            title="[bold]epic-claude init[/bold]",
            border_style="green",
        ))
    else:
        print(f"Initialised: {home}")
        print("Next: export ANTHROPIC_API_KEY=your-key")


@app.command()
def doctor() -> None:
    """Health check: Python, home dir, API key, schema versions."""
    import os
    from pathlib import Path

    checks = []
    py_ver = sys.version_info
    py_ok  = py_ver >= (3, 11)
    checks.append(("Python version", py_ok,
                    f"{py_ver.major}.{py_ver.minor}.{py_ver.micro}",
                    "" if py_ok else "(3.11+ required)"))

    home_ok = _home_is_initialised()
    checks.append(("Home directory", home_ok, _get_home_path(),
                    "" if home_ok else "Run: epic-claude init"))

    cfg_path = Path(_get_home_path()) / "config.json"
    cfg_ok   = cfg_path.exists()
    checks.append(("config.json", cfg_ok,
                    str(cfg_path), "" if cfg_ok else "Run: epic-claude init"))

    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    api_ok  = bool(api_key)
    checks.append(("ANTHROPIC_API_KEY", api_ok,
                    f"sk-...{api_key[-4:]}" if api_ok else "Not set",
                    "" if api_ok else "export ANTHROPIC_API_KEY=your-key"))

    try:
        from epic_claude.migrations.runner import (
            needs_migration, CURRENT_REGISTRY_SCHEMA,
        )
        from epic_claude.registry import REGISTRY_DB_PATH
        mig = REGISTRY_DB_PATH.exists() and needs_migration(REGISTRY_DB_PATH, CURRENT_REGISTRY_SCHEMA)
        checks.append(("Schema versions", not mig,
                        f"registry v{CURRENT_REGISTRY_SCHEMA}",
                        "Run: epic-claude migrate" if mig else ""))
    except Exception:
        pass

    if _RICH:
        table = Table(title="EPIC-Claude Health Check", show_header=True, header_style="bold")
        table.add_column("Check",  style="dim")
        table.add_column("Status")
        table.add_column("Detail")
        for label, ok, detail, hint in checks:
            colour = "green" if ok else ("yellow" if hint else "red")
            status = "[green]✓ OK[/green]" if ok else f"[{colour}]⚠ {hint or 'FAIL'}[/{colour}]"
            table.add_row(label, status, detail)
        console.print(table)
    else:
        for label, ok, detail, hint in checks:
            print(f"  {'OK' if ok else 'FAIL'}  {label}: {detail} {hint}")

    if not py_ok:
        err_console.print("Python 3.11+ is required.")
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# Callback — global flags + first-run UX (P1 Fix 8)
# ---------------------------------------------------------------------------

@app.callback(invoke_without_command=True)
def _callback(
    ctx:        typer.Context,
    quiet:      bool = typer.Option(False, "--quiet",      "-q",  help="Suppress decorative output."),
    json_out:   bool = typer.Option(False, "--json",               help="Raw JSON output."),
    project_id: str  = typer.Option(None,  "--project-id",         help="Override project detection."),
) -> None:
    """EPIC-Claude — Universal AI Solutions Architect for Claude Code."""
    try:
        from epic_claude.cli.output import set_json_mode, set_quiet_mode
        set_json_mode(json_out)
        set_quiet_mode(quiet)
    except Exception:
        pass

    if not _home_is_initialised():
        _bootstrap_home()

    # Bare invocation with no subcommand → onboarding panel
    if ctx.invoked_subcommand is None:
        _show_onboarding()


def _show_onboarding() -> None:
    """First-run UX panel — shown on bare `epic-claude` invocation."""
    initialised = _home_is_initialised()
    if _RICH:
        if not initialised:
            console.print(Panel(
                f"[bold]Welcome to EPIC-Claude v{__version__}[/bold]\n\n"
                "[bold]Get started in 3 steps:[/bold]\n"
                "  1. [cyan]epic-claude init[/cyan]\n"
                "  2. [cyan]export ANTHROPIC_API_KEY=your-key[/cyan]\n"
                "  3. [cyan]epic-claude plan \"describe your project\"[/cyan]\n\n"
                "[dim]epic-claude --help  →  full command reference[/dim]",
                title="[bold cyan]EPIC-Claude[/bold cyan]",
                border_style="cyan",
            ))
        else:
            console.print(Panel(
                f"[bold]EPIC-Claude v{__version__}[/bold]  [dim]— ready[/dim]\n\n"
                "[bold]Common commands:[/bold]\n"
                "  [cyan]epic-claude plan \"<description>\"[/cyan]   → start a new project\n"
                "  [cyan]epic-claude status[/cyan]                  → check active project\n"
                "  [cyan]epic-claude sync[/cyan]                    → sync to CLAUDE.md\n"
                "  [cyan]epic-claude --help[/cyan]                  → full reference\n\n"
                f"[dim]State: {_get_home_path()}[/dim]",
                title="[bold cyan]EPIC-Claude[/bold cyan]",
                border_style="cyan",
            ))
    else:
        print(f"epic-claude v{__version__}")
        if not initialised:
            print("Run: epic-claude init  then  epic-claude plan \"your project\"")
        else:
            print("Run: epic-claude --help  for commands")

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    app()

if __name__ == "__main__":
    main()
