"""
EPIC-Claude Agents — EC-F002, EC-F003, EC-F004.

  register_agent_handlers()     — wire EC-F002 + EC-F003 handlers
  register_architect_handlers() — wire EC-F004 handlers
  get_llm_client()              — global LLM client
"""

from epic_claude.agents.handlers import register_agent_handlers
from epic_claude.agents.architect_handlers import register_architect_handlers
from epic_claude.agents.llm import get_llm_client, close_llm_client
from epic_claude.agents import clarification, stack

__all__ = [
    "register_agent_handlers",
    "register_architect_handlers",
    "get_llm_client",
    "close_llm_client",
    "clarification",
    "stack",
]
