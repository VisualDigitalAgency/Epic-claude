"""
EPIC-Claude global configuration.

Loaded from ~/.epic-claude/config.json on server startup.
No credentials are ever stored here — LLM API key comes from environment only.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


# ---------------------------------------------------------------------------
# XDG / home directory resolution
# ---------------------------------------------------------------------------

def _resolve_epic_claude_home() -> Path:
    """
    Resolve the global state directory.
    Must stay in sync with registry._resolve_home().

    Priority:
      1. EPIC_CLAUDE_HOME env var  (explicit override — all platforms)
      2. Windows: %APPDATA%/epic-claude
      3. Linux/Mac XDG: $XDG_DATA_HOME/epic-claude
      4. Linux/Mac default: ~/.epic-claude
    """
    explicit = os.environ.get("EPIC_CLAUDE_HOME")
    if explicit:
        return Path(explicit)

    if os.name == "nt":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "epic-claude"
        return Path.home() / ".epic-claude"

    xdg = os.environ.get("XDG_DATA_HOME")
    if xdg:
        return Path(xdg) / "epic-claude"

    return Path.home() / ".epic-claude"


EPIC_CLAUDE_HOME: Path = _resolve_epic_claude_home()


# ---------------------------------------------------------------------------
# Config schema
# ---------------------------------------------------------------------------

class EpicClaudeConfig(BaseSettings):
    """
    Global configuration for EPIC-Claude.
    Maps 1:1 to ~/.epic-claude/config.json (PRD §11).
    All fields have safe defaults — no field is required at startup.
    """

    model_config = SettingsConfigDict(
        env_prefix="EPIC_CLAUDE_",
        env_file=".env",
        case_sensitive=False,
        extra="ignore",
    )

    # -----------------------------------------------------------------------
    # Platform identity
    # -----------------------------------------------------------------------
    version: str = Field(default="1.0.0", description="EPIC-Claude version")

    # -----------------------------------------------------------------------
    # LLM
    # -----------------------------------------------------------------------
    llm_model: str = Field(
        default="claude-sonnet-4-20250514",
        description="Anthropic model used for all agent calls",
    )
    # NOTE: API key NEVER stored in config. Read from ANTHROPIC_API_KEY env var only.

    # -----------------------------------------------------------------------
    # Database
    # -----------------------------------------------------------------------
    db_engine: Literal["sqlite"] = Field(
        default="sqlite",
        description="Database engine. Only sqlite in v1. PostgreSQL deferred to v2.",
    )

    # -----------------------------------------------------------------------
    # Clarification Agent
    # -----------------------------------------------------------------------
    clarification_max_rounds: int = Field(
        default=3,
        ge=1,
        le=5,
        description="Maximum clarification rounds before proceeding with assumptions",
    )
    unknown_answer_followup: bool = Field(
        default=True,
        description="Ask exactly one follow-up for unknown answers before assuming",
    )

    # -----------------------------------------------------------------------
    # Artifact generation
    # -----------------------------------------------------------------------
    diagram_format: Literal["mermaid"] = Field(
        default="mermaid",
        description="Diagram format for architecture diagrams. Only mermaid in v1.",
    )

    # -----------------------------------------------------------------------
    # Feature ID namespacing — NON-NEGOTIABLE per PRD §21
    # -----------------------------------------------------------------------
    platform_feature_prefix: str = Field(
        default="EC-F",
        description="Prefix for EPIC-Claude platform features. NEVER use in generated PRDs.",
    )
    generated_feature_prefix: str = Field(
        default="F",
        description="Prefix for user project features. NEVER mix with EC-F prefix.",
    )
    generated_feature_id_padding: int = Field(
        default=3,
        description="Zero-padding width for generated F-IDs (e.g. 3 → F001, F002)",
    )

    # -----------------------------------------------------------------------
    # Sync / CLAUDE.md
    # -----------------------------------------------------------------------
    sync_on_session_start: bool = Field(
        default=True,
        description="Auto-sync CLAUDE.md when a Claude Code session starts",
    )
    claude_md_section_marker: str = Field(
        default="EPIC-CLAUDE-MANAGED",
        description="Marker string used to delimit the managed section in CLAUDE.md",
    )
    claude_md_backup_retention_days: int = Field(
        default=30,
        ge=1,
        description="Days to retain CLAUDE.md pre-sync backups",
    )
    active_project_banner: bool = Field(
        default=True,
        description="Show active project banner on all CLI output",
    )

    # -----------------------------------------------------------------------
    # Validation
    # -----------------------------------------------------------------------
    validation_gates_enabled: bool = Field(
        default=True,
        description="Enable Gate 2 + Gate 3 validation. Never disable in production.",
    )

    # -----------------------------------------------------------------------
    # Logging
    # -----------------------------------------------------------------------
    log_level: Literal["debug", "info", "warning", "error"] = Field(
        default="info",
        description="Log level for ~/.epic-claude/server.log",
    )
    log_max_bytes: int = Field(
        default=10_485_760,  # 10 MB
        description="Max log file size before rotation",
    )
    log_backup_count: int = Field(
        default=5,
        description="Number of rotated log file backups to keep",
    )

    # -----------------------------------------------------------------------
    # Security guard — no credentials in config
    # -----------------------------------------------------------------------
    @model_validator(mode="after")
    def no_credentials_in_config(self) -> "EpicClaudeConfig":
        """PRD §18 Security — config.json must never contain credentials."""
        forbidden_fields = {"api_key", "secret", "password", "token"}
        for field_name in self.model_fields_set:
            if any(f in field_name.lower() for f in forbidden_fields):
                raise ValueError(
                    f"Security violation: field '{field_name}' looks like a credential. "
                    "Store API keys in environment variables only, never in config.json."
                )
        return self

    @field_validator("generated_feature_prefix")
    @classmethod
    def prefix_must_not_conflict(cls, v: str) -> str:
        if v.startswith("EC-"):
            raise ValueError(
                "generated_feature_prefix must not start with 'EC-'. "
                "That namespace is reserved for EPIC-Claude platform features."
            )
        return v


# ---------------------------------------------------------------------------
# Config file I/O
# ---------------------------------------------------------------------------

def load_config() -> EpicClaudeConfig:
    """
    Load config from ~/.epic-claude/config.json.
    Falls back to all defaults if file does not exist.
    Environment variables (EPIC_CLAUDE_*) always override file values.
    """
    config_path = EPIC_CLAUDE_HOME / "config.json"
    if config_path.exists():
        raw = json.loads(config_path.read_text(encoding="utf-8"))
        return EpicClaudeConfig(**raw)
    return EpicClaudeConfig()


def save_config(config: EpicClaudeConfig) -> None:
    """Persist config to ~/.epic-claude/config.json (no credentials)."""
    config_path = EPIC_CLAUDE_HOME / "config.json"
    config_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    data = config.model_dump(exclude={"version"})
    config_path.write_text(
        json.dumps(data, indent=2) + "\n",
        encoding="utf-8",
    )


def get_api_key() -> str:
    """
    Return ANTHROPIC_API_KEY from environment.
    Raises clearly if not set — never reads from config file.
    PRD §18 Security.
    """
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not key:
        raise EnvironmentError(
            "ANTHROPIC_API_KEY environment variable is not set.\n"
            "EPIC-Claude requires it for all agent operations.\n"
            "Set it with: export ANTHROPIC_API_KEY=your-key-here"
        )
    return key
