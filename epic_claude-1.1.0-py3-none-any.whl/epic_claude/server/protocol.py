"""
JSON-RPC 2.0 protocol models for EPIC-Claude MCP server.

All wire-format types live here. These are the only objects that cross
the stdio boundary — everything else is internal domain logic.

Spec: https://www.jsonrpc.org/specification
MCP:  https://spec.modelcontextprotocol.io
PRD §13 EC-F001 — error codes, request/response shapes.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from epic_claude.constants import JsonRpcError


# ---------------------------------------------------------------------------
# JSON-RPC 2.0 wire types
# ---------------------------------------------------------------------------

JSONRPC_VERSION = "2.0"


@dataclass(frozen=True)
class JsonRpcRequest:
    """Incoming JSON-RPC 2.0 request from Claude Code."""

    method: str
    id: int | str | None = None          # None → notification (no response sent)
    params: dict[str, Any] | None = None
    jsonrpc: str = JSONRPC_VERSION

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "JsonRpcRequest":
        """Parse a raw decoded dict into a JsonRpcRequest. Raises ValueError on bad input."""
        if data.get("jsonrpc") != JSONRPC_VERSION:
            raise ValueError(f"Invalid jsonrpc version: {data.get('jsonrpc')!r}")
        method = data.get("method")
        if not method or not isinstance(method, str):
            raise ValueError("Request missing required 'method' field")
        return cls(
            method=method,
            id=data.get("id"),
            params=data.get("params"),
            jsonrpc=data.get("jsonrpc", JSONRPC_VERSION),
        )

    @classmethod
    def from_json(cls, raw: str) -> "JsonRpcRequest":
        """Parse a raw JSON string. Raises ValueError or json.JSONDecodeError."""
        return cls.from_dict(json.loads(raw))

    @property
    def is_notification(self) -> bool:
        """Notifications have no id field — no response should be sent."""
        return self.id is None


@dataclass(frozen=True)
class JsonRpcResponse:
    """Outgoing JSON-RPC 2.0 success response."""

    id: int | str | None
    result: Any
    jsonrpc: str = JSONRPC_VERSION

    def to_dict(self) -> dict[str, Any]:
        return {"jsonrpc": self.jsonrpc, "id": self.id, "result": self.result}

    def to_json(self) -> str:
        return json.dumps(self.to_dict())


@dataclass(frozen=True)
class JsonRpcErrorDetail:
    """JSON-RPC 2.0 error object."""

    code: int
    message: str
    data: Any = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"code": self.code, "message": self.message}
        if self.data is not None:
            d["data"] = self.data
        return d


@dataclass(frozen=True)
class JsonRpcErrorResponse:
    """Outgoing JSON-RPC 2.0 error response."""

    id: int | str | None
    error: JsonRpcErrorDetail
    jsonrpc: str = JSONRPC_VERSION

    def to_dict(self) -> dict[str, Any]:
        return {
            "jsonrpc": self.jsonrpc,
            "id": self.id,
            "error": self.error.to_dict(),
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict())


# ---------------------------------------------------------------------------
# Error response factory helpers (PRD §13 EC-F001)
# ---------------------------------------------------------------------------

def make_error(
    req_id: int | str | None,
    code: int,
    message: str,
    data: Any = None,
) -> JsonRpcErrorResponse:
    return JsonRpcErrorResponse(
        id=req_id,
        error=JsonRpcErrorDetail(code=code, message=message, data=data),
    )


def parse_error(req_id: int | str | None = None) -> JsonRpcErrorResponse:
    return make_error(req_id, JsonRpcError.PARSE_ERROR, "Parse error")


def invalid_request(req_id: int | str | None, detail: str = "") -> JsonRpcErrorResponse:
    return make_error(
        req_id, JsonRpcError.INVALID_REQUEST,
        f"Invalid Request{': ' + detail if detail else ''}",
    )


def method_not_found(req_id: int | str | None, method: str) -> JsonRpcErrorResponse:
    return make_error(
        req_id, JsonRpcError.METHOD_NOT_FOUND,
        f"Method not found: {method}",
    )


def invalid_params(req_id: int | str | None, detail: str = "") -> JsonRpcErrorResponse:
    return make_error(
        req_id, JsonRpcError.INVALID_PARAMS,
        f"Invalid params{': ' + detail if detail else ''}",
    )


def internal_error(req_id: int | str | None, detail: str = "") -> JsonRpcErrorResponse:
    return make_error(
        req_id, JsonRpcError.INTERNAL_ERROR,
        f"Internal error{': ' + detail if detail else ''}",
    )


# ---------------------------------------------------------------------------
# MCP protocol constants and shapes
# ---------------------------------------------------------------------------

MCP_PROTOCOL_VERSION = "2024-11-05"


@dataclass(frozen=True)
class McpServerInfo:
    name: str = "epic-claude"
    version: str = "1.0.0"

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "version": self.version}


@dataclass(frozen=True)
class McpCapabilities:
    """Server capabilities advertised during MCP initialize handshake."""
    tools: dict[str, Any] = field(default_factory=lambda: {"listChanged": False})

    def to_dict(self) -> dict[str, Any]:
        return {"tools": self.tools}


@dataclass(frozen=True)
class McpToolDefinition:
    """
    A single MCP tool as returned by tools/list.
    name, description, inputSchema follow the MCP spec.
    """
    name: str
    description: str
    input_schema: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }


@dataclass
class McpToolRegistry:
    """
    Registry of all MCP tools available on this server.
    Tools are registered by each EC-F feature module.
    """
    _tools: dict[str, McpToolDefinition] = field(default_factory=dict)

    def register(self, tool: McpToolDefinition) -> None:
        """Register a tool. Raises ValueError on duplicate name."""
        if tool.name in self._tools:
            raise ValueError(f"Tool already registered: {tool.name!r}")
        self._tools[tool.name] = tool

    def get(self, name: str) -> McpToolDefinition | None:
        return self._tools.get(name)

    def list_all(self) -> list[dict[str, Any]]:
        """Return all tools serialised for tools/list response."""
        return [t.to_dict() for t in self._tools.values()]

    def __len__(self) -> int:
        return len(self._tools)

    def __contains__(self, name: object) -> bool:
        return name in self._tools
