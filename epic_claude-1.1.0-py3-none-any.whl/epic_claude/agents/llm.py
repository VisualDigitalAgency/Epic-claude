"""
LLM client for EPIC-Claude agents.

Wraps the Anthropic API using httpx (async).
All agent LLM calls go through this module.

PRD §10 tech stack:
  - httpx 0.27+ for async HTTP
  - anthropic SDK (or direct API call)
  - model: claude-sonnet-4-20250514

PRD §18 perf targets:
  - clarify_answer response  < 3s
  - stack_decide response    < 5s
  - architect_generate       < 90s (5 sequential LLM calls)
"""

from __future__ import annotations

import json
import os
from typing import Any

from epic_claude.exceptions import LLMError, LLMTimeoutError
from epic_claude.server.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_API_VERSION = "2023-06-01"
DEFAULT_MODEL = "claude-sonnet-4-20250514"
DEFAULT_MAX_TOKENS = 4096


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class LLMClient:
    """
    Async Anthropic API client.
    One instance shared across all agents via get_llm_client().
    """

    def __init__(
        self,
        api_key: str,
        model: str = DEFAULT_MODEL,
        timeout: float = 120.0,
    ) -> None:
        import httpx  # lazy import — only needed when actually calling the API
        self.api_key = api_key
        self.model = model
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(timeout),
            headers={
                "x-api-key": api_key,
                "anthropic-version": ANTHROPIC_API_VERSION,
                "content-type": "application/json",
            },
        )

    async def complete(
        self,
        system: str,
        user: str,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        temperature: float = 0.3,
    ) -> str:
        """
        Send a single-turn completion request and return the text response.

        Args:
            system:     System prompt.
            user:       User message content.
            max_tokens: Max tokens to generate.
            temperature: Sampling temperature (0.3 = focused, reliable).

        Returns:
            The assistant's text response as a string.

        Raises:
            LLMTimeoutError: on httpx timeout.
            LLMError:        on API error (4xx/5xx).
        """
        payload: dict[str, Any] = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        }

        logger.debug("LLM call | model=%s | max_tokens=%d", self.model, max_tokens)

        try:
            response = await self._client.post(ANTHROPIC_API_URL, json=payload)
        except Exception as exc:
            import httpx  # noqa: PLC0415
            if isinstance(exc, httpx.TimeoutException):
                logger.error("LLM timeout: %s", exc)
                raise LLMTimeoutError(
                    f"LLM API call timed out",
                    detail={"model": self.model},
                ) from exc
            if isinstance(exc, httpx.RequestError):
                logger.error("LLM request error: %s", exc)
                raise LLMError(f"LLM request failed: {exc}") from exc
            raise

        if response.status_code != 200:
            body = response.text[:500]
            logger.error("LLM API error %d: %s", response.status_code, body)
            raise LLMError(
                f"LLM API returned {response.status_code}",
                detail={"status": response.status_code, "body": body},
            )

        data = response.json()
        text = _extract_text(data)
        logger.debug("LLM response: %d chars", len(text))
        return text

    async def complete_json(
        self,
        system: str,
        user: str,
        max_tokens: int = DEFAULT_MAX_TOKENS,
    ) -> dict[str, Any]:
        """
        Like complete() but expects a JSON response.
        Strips markdown fences before parsing.

        Raises:
            LLMError: if response is not valid JSON.
        """
        raw = await self.complete(
            system=system + "\n\nRESPOND ONLY WITH VALID JSON. No preamble. No markdown fences.",
            user=user,
            max_tokens=max_tokens,
            temperature=0.1,  # lower temperature for JSON outputs
        )
        cleaned = _strip_json_fences(raw)
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as exc:
            logger.error("LLM returned invalid JSON: %s | raw=%r", exc, raw[:300])
            raise LLMError(
                "LLM response was not valid JSON",
                detail={"raw_preview": raw[:300], "error": str(exc)},
            ) from exc

    async def close(self) -> None:
        await self._client.aclose()


# ---------------------------------------------------------------------------
# Global singleton
# ---------------------------------------------------------------------------

_client: LLMClient | None = None


def get_llm_client(model: str = DEFAULT_MODEL) -> LLMClient:
    """
    Return the global LLMClient instance.
    Created on first call using ANTHROPIC_API_KEY from environment.

    Raises:
        EnvironmentError: if ANTHROPIC_API_KEY is not set.
    """
    global _client
    if _client is None:
        api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
        if not api_key:
            raise EnvironmentError(
                "ANTHROPIC_API_KEY is not set. "
                "Export it with: export ANTHROPIC_API_KEY=your-key"
            )
        _client = LLMClient(api_key=api_key, model=model)
        logger.info("LLM client initialised | model=%s", model)
    return _client


async def close_llm_client() -> None:
    """Close the global client. Called on server shutdown."""
    global _client
    if _client:
        await _client.close()
        _client = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_text(response_data: dict[str, Any]) -> str:
    """Extract text content from Anthropic API response."""
    content = response_data.get("content", [])
    parts = [block["text"] for block in content if block.get("type") == "text"]
    return "\n".join(parts).strip()


def _strip_json_fences(text: str) -> str:
    """Remove ```json ... ``` or ``` ... ``` markdown fences."""
    text = text.strip()
    for fence in ("```json", "```"):
        if text.startswith(fence):
            text = text[len(fence):]
            break
    if text.endswith("```"):
        text = text[:-3]
    return text.strip()
