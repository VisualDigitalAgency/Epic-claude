"""
EC-F002 + EC-F003 — MCP tool handlers.

Wires 8 tools into the global dispatch table:
  EC-F002: project_start, clarify_answer, clarify_status, clarify_revise
  EC-F003: stack_decide, stack_confirm, stack_adjust, stack_get

Each handler:
  1. Validates required params
  2. Resolves DB paths from project registry
  3. Calls clarification or stack agent
  4. Returns JSON-serialisable result dict

Called once at server startup via register_agent_handlers().
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import epic_claude.registry as reg_mod
from epic_claude.agents import clarification as clarification_agent
from epic_claude.agents import stack as stack_agent
from epic_claude.exceptions import (
    ClarificationNotCompleteError,
    ClarificationSessionNotFoundError,
    UnsupportedProjectTypeError,
)
from epic_claude.memory.database import bootstrap_memory_db
from epic_claude.memory.registry_store import RegistryStore
from epic_claude.server.detection import detect_project, DetectionStatus
from epic_claude.server.logging import get_logger
from epic_claude.server.tools import register_handler

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# EC-F002 handlers
# ---------------------------------------------------------------------------

async def _handle_project_start(params: dict[str, Any]) -> dict[str, Any]:
    """
    Begin a new project: detect or create registry entry, start clarification.

    Required: description, cwd
    """
    description = _require(params, "description")
    cwd_str     = _require(params, "cwd")
    cwd         = Path(cwd_str)

    # Project detection
    detection = detect_project(
        cwd=cwd,
        registry_projects_dir=reg_mod.PROJECTS_DIR,
    )

    registry_db   = reg_mod.REGISTRY_DB_PATH
    registry_store = RegistryStore(registry_db)
    registry_store.open()

    try:
        if detection.status in (DetectionStatus.FOUND, DetectionStatus.FOUND_AMBIGUOUS):
            # Use existing project
            project = registry_store.require_by_id(detection.project.project_id)
            project_id   = project.id
            project_name = project.name
        else:
            # Create new project
            project_name = _infer_project_name(description, cwd)
            project = registry_store.create_project(
                name=project_name,
                root_path=str(cwd),
                description=description[:200],
            )
            project_id = project.id

    finally:
        registry_store.close()

    # Bootstrap memory.db for this project
    memory_db = reg_mod.PROJECTS_DIR / project_id / "memory.db"
    bootstrap_memory_db(memory_db)

    # Start clarification
    try:
        result = await clarification_agent.start_clarification(
            project_id=project_id,
            project_name=project_name,
            description=description,
            memory_db_path=memory_db,
        )
    except UnsupportedProjectTypeError as exc:
        return {
            "success": False,
            "error": "unsupported_project_type",
            "message": str(exc),
            "supported_types": ["backend_saas", "rest_api", "fullstack_web"],
        }

    return {
        "success": True,
        "project_id": project_id,
        "project_name": project_name,
        "detection_status": detection.status.value,
        **result,
    }


async def _handle_clarify_answer(params: dict[str, Any]) -> dict[str, Any]:
    """
    Submit answers for a clarification round.

    Required: session_id, answers (dict)
    """
    session_id = _require(params, "session_id")
    answers    = _require(params, "answers")

    if not isinstance(answers, dict):
        raise TypeError("'answers' must be a JSON object")

    try:
        state = clarification_agent._get_session(session_id)
    except ClarificationSessionNotFoundError as exc:
        return {"success": False, "error": exc.message}

    memory_db = _memory_db_path(state.project_id)
    result = await clarification_agent.submit_answers(
        session_id=session_id,
        answers=answers,
        memory_db_path=memory_db,
    )

    # If clarification is now ready, mark complete in registry
    if result.get("ready"):
        await _mark_clarification_complete(state.project_id, state)

    return {"success": True, **result}


async def _handle_clarify_status(params: dict[str, Any]) -> dict[str, Any]:
    """Return current status of a clarification session."""
    session_id = _require(params, "session_id")
    try:
        return {"success": True, **clarification_agent.get_status(session_id)}
    except ClarificationSessionNotFoundError as exc:
        return {"success": False, "error": exc.message}


async def _handle_clarify_revise(params: dict[str, Any]) -> dict[str, Any]:
    """Revise a single answer in an active clarification session."""
    session_id   = _require(params, "session_id")
    question_key = _require(params, "question_key")
    new_answer   = _require(params, "new_answer")

    try:
        state = clarification_agent._get_session(session_id)
    except ClarificationSessionNotFoundError as exc:
        return {"success": False, "error": exc.message}

    memory_db = _memory_db_path(state.project_id)
    result = clarification_agent.revise_answer(
        session_id=session_id,
        question_key=question_key,
        new_answer=new_answer,
        memory_db_path=memory_db,
    )
    return {"success": True, **result}


# ---------------------------------------------------------------------------
# EC-F003 handlers
# ---------------------------------------------------------------------------

async def _handle_stack_decide(params: dict[str, Any]) -> dict[str, Any]:
    """
    Propose a tech stack based on completed clarification.
    Blocked until clarification_complete=True.

    Required: project_id
    """
    project_id = _require(params, "project_id")

    registry_db = reg_mod.REGISTRY_DB_PATH
    registry    = RegistryStore(registry_db)
    registry.open()
    try:
        project = registry.require_by_id(project_id)
    finally:
        registry.close()

    memory_db = _memory_db_path(project_id)

    try:
        result = await stack_agent.propose_stack(
            project_id=project_id,
            project_name=project.name,
            description=project.description or "",
            registry_db_path=registry_db,
            memory_db_path=memory_db,
        )
    except ClarificationNotCompleteError as exc:
        return {"success": False, "error": exc.message}

    return {"success": True, **result}


async def _handle_stack_confirm(params: dict[str, Any]) -> dict[str, Any]:
    """
    Lock the proposed stack. Gates architect_generate.

    Required: project_id
    """
    project_id = _require(params, "project_id")
    registry_db = reg_mod.REGISTRY_DB_PATH
    memory_db   = _memory_db_path(project_id)

    result = stack_agent.confirm_stack(
        project_id=project_id,
        registry_db_path=registry_db,
        memory_db_path=memory_db,
    )
    return {"success": True, **result}


async def _handle_stack_adjust(params: dict[str, Any]) -> dict[str, Any]:
    """
    Adjust one stack category without re-running clarification.

    Required: project_id, category, name, rationale
    Optional: version
    """
    project_id = _require(params, "project_id")
    category   = _require(params, "category")
    name       = _require(params, "name")
    rationale  = _require(params, "rationale")
    version    = params.get("version", "")

    memory_db = _memory_db_path(project_id)

    try:
        result = stack_agent.adjust_stack(
            project_id=project_id,
            category=category,
            name=name,
            rationale=rationale,
            memory_db_path=memory_db,
            version=version,
        )
    except ValueError as exc:
        return {"success": False, "error": str(exc)}

    return {"success": True, **result}


async def _handle_stack_get(params: dict[str, Any]) -> dict[str, Any]:
    """Retrieve current stack (confirmed or proposed)."""
    project_id = _require(params, "project_id")
    memory_db  = _memory_db_path(project_id)
    result = stack_agent.get_stack(project_id=project_id, memory_db_path=memory_db)
    return {"success": True, **result}


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register_agent_handlers() -> None:
    """
    Wire all EC-F002 + EC-F003 tool handlers into the global MCP tool registry.
    Called once at server startup.
    """
    # EC-F002
    register_handler("project_start",   _handle_project_start)
    register_handler("clarify_answer",  _handle_clarify_answer)
    register_handler("clarify_status",  _handle_clarify_status)
    register_handler("clarify_revise",  _handle_clarify_revise)
    # EC-F003
    register_handler("stack_decide",    _handle_stack_decide)
    register_handler("stack_confirm",   _handle_stack_confirm)
    register_handler("stack_adjust",    _handle_stack_adjust)
    register_handler("stack_get",       _handle_stack_get)

    logger.info("EC-F002 + EC-F003 handlers registered (8 tools)")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _require(params: dict[str, Any], key: str) -> Any:
    val = params.get(key)
    if val is None:
        raise TypeError(f"Required parameter missing: '{key}'")
    return val


def _memory_db_path(project_id: str) -> Path:
    return reg_mod.PROJECTS_DIR / project_id / "memory.db"


def _infer_project_name(description: str, cwd: Path) -> str:
    """Best-effort project name from description or directory name."""
    words = description.strip().split()
    if len(words) <= 6:
        return description.strip().title()
    return cwd.name.replace("-", " ").replace("_", " ").title() or "New Project"


async def _mark_clarification_complete(
    project_id: str,
    state: clarification_agent.ClarificationState,
) -> None:
    """Update registry when clarification is complete."""
    registry_db = reg_mod.REGISTRY_DB_PATH
    registry    = RegistryStore(registry_db)
    registry.open()
    try:
        project_type = state.inferred.get("project_type") or state.answers.get("project_type")
        registry.update_fields(
            project_id,
            clarification_complete=True,
            clarification_rounds=state.round,
            project_type=project_type,
        )
        logger.info(
            "Registry updated: clarification_complete=True | project=%s | type=%s",
            project_id, project_type,
        )
    finally:
        registry.close()
