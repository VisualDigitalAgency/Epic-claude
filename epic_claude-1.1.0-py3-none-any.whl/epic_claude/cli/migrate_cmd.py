"""
CLI: epic-claude migrate — run pending DB schema migrations.

Called automatically on server startup.
Can be run manually after upgrading epic-claude.
"""

from __future__ import annotations

try:
    import typer
except ImportError:
    typer = None  # type: ignore

try:
    from rich.table import Table
    from rich.panel import Panel
except ImportError:
    Table = Panel = None  # type: ignore

from epic_claude.cli.output import console, print_error, print_success, print_json, is_json_mode

migrate_app = typer.Typer() if typer else None


def _run_migrate(check_only: bool = False) -> int:
    """Core migration logic. Returns exit code."""
    import epic_claude.registry as reg_mod
    from epic_claude.migrations.runner import (
        migrate_all, check_all_projects,
        needs_migration, CURRENT_REGISTRY_SCHEMA, CURRENT_MEMORY_SCHEMA,
    )

    registry_db  = reg_mod.REGISTRY_DB_PATH
    projects_dir = reg_mod.PROJECTS_DIR

    if check_only:
        # Just report — don't apply
        issues = []
        if registry_db.exists() and needs_migration(registry_db, CURRENT_REGISTRY_SCHEMA):
            issues.append(f"registry.db needs migration to v{CURRENT_REGISTRY_SCHEMA}")
        for p in check_all_projects(projects_dir):
            if p["needs_migration"]:
                issues.append(
                    f"project {p['project_id'][:8]}: "
                    f"memory.db at v{p['current_version']} → needs v{CURRENT_MEMORY_SCHEMA}"
                )
        if is_json_mode():
            print_json({"needs_migration": bool(issues), "issues": issues})
        elif issues:
            console.print(f"[yellow]⚠ {len(issues)} migration(s) pending:[/yellow]")
            for issue in issues:
                console.print(f"  • {issue}")
            console.print("\nRun: [cyan]epic-claude migrate[/cyan]")
            return 1
        else:
            print_success("All schemas up to date.")
        return 0

    # Apply migrations
    if not is_json_mode():
        console.print("[bold]Running schema migrations...[/bold]\n")

    result = migrate_all(registry_db, projects_dir)

    if is_json_mode():
        print_json(result)
        return 1 if result["errors"] else 0

    # Registry result
    reg_result = result["registry"].get("result", {})
    applied    = reg_result.get("applied", [])
    if applied:
        console.print(f"  [green]✓[/green] registry.db: applied migrations {applied}")
    elif "skipped" not in reg_result:
        console.print(f"  [dim]✓ registry.db: already up to date[/dim]")

    # Project results
    for p in result["projects"]:
        proj_applied = p["result"].get("applied", [])
        pid = p["project_id"][:8]
        if proj_applied:
            console.print(f"  [green]✓[/green] project {pid}: applied {proj_applied}")
        else:
            console.print(f"  [dim]✓ project {pid}: already up to date[/dim]")

    # Errors
    if result["errors"]:
        console.print(f"\n[red]✗ {len(result['errors'])} error(s):[/red]")
        for err in result["errors"]:
            console.print(f"  • {err}")
        return 1

    console.print("\n[green]✓ All migrations complete.[/green]")
    return 0


if migrate_app and typer:
    @migrate_app.callback(invoke_without_command=True)
    def migrate(
        check: bool = typer.Option(False, "--check",
            help="Check for pending migrations without applying them."),
    ) -> None:
        """Run pending DB schema migrations after upgrading epic-claude."""
        try:
            exit_code = _run_migrate(check_only=check)
            if exit_code != 0:
                raise typer.Exit(code=exit_code)
        except typer.Exit:
            raise
        except Exception as exc:
            print_error(f"Migration failed: {exc}")
            raise typer.Exit(code=1)
