"""
MCP Tool Registry — all JSON-RPC 2.0 tool definitions for EPIC-Claude.

This module owns two things:
  1. The canonical tool definitions (name + description + inputSchema)
     for every tool in the MCP Tool Registry (PRD §14).
  2. The handler dispatch table — maps tool name → async handler function.

Tool handlers are registered by each EC-F feature module (Phase 2-5).
Phase 1 registers only the scaffolding; the actual implementations
are wired in as each phase is built.

PRD §14 — Full tool list:
  EC-F002: project_start, clarify_answer, clarify_status, clarify_revise
  EC-F003: stack_decide, stack_confirm, stack_adjust, stack_get
  EC-F004: architect_generate, architect_regenerate, artifact_get, artifact_list
  EC-F005: memory_write, memory_recall, memory_list, memory_supersede
  EC-F006: context_sync, context_recall
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from epic_claude.server.protocol import McpToolDefinition, McpToolRegistry
from epic_claude.server.logging import get_logger

logger = get_logger(__name__)

# Type alias for tool handler functions
ToolHandler = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


# ---------------------------------------------------------------------------
# Global tool registry instance
# ---------------------------------------------------------------------------

TOOL_REGISTRY = McpToolRegistry()

# Handler dispatch table: tool_name → async handler
_HANDLERS: dict[str, ToolHandler] = {}


def register_handler(tool_name: str, handler: ToolHandler) -> None:
    """Register an async handler for a tool name. Called by each EC-F module."""
    if tool_name not in TOOL_REGISTRY:
        raise ValueError(
            f"Cannot register handler for unknown tool: {tool_name!r}. "
            "Register the tool definition first."
        )
    if tool_name in _HANDLERS:
        raise ValueError(f"Handler already registered for tool: {tool_name!r}")
    _HANDLERS[tool_name] = handler
    logger.debug("Handler registered for tool: %s", tool_name)


async def dispatch(tool_name: str, params: dict[str, Any]) -> dict[str, Any]:
    """
    Dispatch a tools/call request to the correct handler.
    Returns the handler result dict, or raises KeyError if tool not found.
    """
    handler = _HANDLERS.get(tool_name)
    if handler is None:
        raise KeyError(f"No handler registered for tool: {tool_name!r}")
    logger.info("Dispatching tool: %s | params=%s", tool_name, list(params.keys()))
    return await handler(params)


def is_registered(tool_name: str) -> bool:
    return tool_name in _HANDLERS


# ---------------------------------------------------------------------------
# Tool definitions (PRD §14) — registered at module import time
# ---------------------------------------------------------------------------

def _register_tool_definitions() -> None:
    """Register all tool definitions. Called once at server startup."""

    # -----------------------------------------------------------------------
    # EC-F002 — Clarification Agent
    # -----------------------------------------------------------------------
    TOOL_REGISTRY.register(McpToolDefinition(
        name="project_start",
        description=(
            "Begin a new EPIC-Claude project. Runs project detection, creates a registry "
            "entry, and starts the clarification session. Always call this first for a "
            "new project."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "description": {
                    "type": "string",
                    "description": "Natural language description of what you want to build.",
                },
                "cwd": {
                    "type": "string",
                    "description": "Absolute path to the project root directory.",
                },
            },
            "required": ["description", "cwd"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="clarify_answer",
        description=(
            "Submit answers to clarification questions. Pass answers as a dict keyed by "
            "question_key. For unknown answers pass null — a follow-up will be asked."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "Clarification session ID from project_start response.",
                },
                "answers": {
                    "type": "object",
                    "description": "Dict of question_key → answer string (or null if unknown).",
                },
            },
            "required": ["session_id", "answers"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="clarify_status",
        description="Check completeness of the clarification session and list any remaining unknowns.",
        input_schema={
            "type": "object",
            "properties": {
                "session_id": {
                    "type": "string",
                    "description": "Clarification session ID.",
                },
            },
            "required": ["session_id"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="clarify_revise",
        description=(
            "Revise a single answer before the clarification session is marked complete. "
            "Cannot be called after stack_confirm."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "session_id": {"type": "string"},
                "question_key": {
                    "type": "string",
                    "description": "The key of the answer to revise.",
                },
                "new_answer": {
                    "type": "string",
                    "description": "Revised answer value.",
                },
            },
            "required": ["session_id", "question_key", "new_answer"],
        },
    ))

    # -----------------------------------------------------------------------
    # EC-F003 — Tech Stack Decider
    # -----------------------------------------------------------------------
    TOOL_REGISTRY.register(McpToolDefinition(
        name="stack_decide",
        description=(
            "Generate a proposed tech stack based on completed clarification. "
            "Blocked until clarification_complete=true. Returns proposed stack with "
            "rationale and alternatives for each category."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string", "description": "Project UUID."},
            },
            "required": ["project_id"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="stack_confirm",
        description=(
            "Lock the proposed tech stack. Blocks architect_generate until called. "
            "Cannot be undone without stack_adjust."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
            },
            "required": ["project_id"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="stack_adjust",
        description=(
            "Change a single tech stack category after confirmation. "
            "Does not require re-running clarification."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
                "category": {
                    "type": "string",
                    "description": "Stack category to change (e.g. 'framework', 'database').",
                },
                "name": {
                    "type": "string",
                    "description": "New technology choice for this category.",
                },
                "rationale": {
                    "type": "string",
                    "description": "Reason for the change.",
                },
            },
            "required": ["project_id", "category", "name", "rationale"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="stack_get",
        description="Retrieve the current tech stack (confirmed or proposed) for a project.",
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
            },
            "required": ["project_id"],
        },
    ))

    # -----------------------------------------------------------------------
    # EC-F004 — Architect Agent
    # -----------------------------------------------------------------------
    TOOL_REGISTRY.register(McpToolDefinition(
        name="architect_generate",
        description=(
            "Run the pre-generation checklist, generate all 5 architecture artifacts "
            "(prd.md, api.yaml, schema.sql, techstack.md, boundaries.md), validate all "
            "through Gate 2, and persist atomically. Blocked until stack_confirmed=true."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
            },
            "required": ["project_id"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="architect_regenerate",
        description=(
            "Regenerate all artifacts or a specific artifact type. "
            "Use scope to limit to one artifact."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
                "scope": {
                    "type": "string",
                    "enum": ["prd", "api_spec", "db_schema", "tech_stack", "boundaries"],
                    "description": "Artifact type to regenerate. Omit to regenerate all.",
                },
            },
            "required": ["project_id"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="artifact_get",
        description="Get the current content of a specific artifact by type.",
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
                "type": {
                    "type": "string",
                    "enum": ["prd", "api_spec", "db_schema", "tech_stack", "boundaries"],
                },
            },
            "required": ["project_id", "type"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="artifact_list",
        description="List all artifacts for a project with their validation status and versions.",
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
            },
            "required": ["project_id"],
        },
    ))

    # -----------------------------------------------------------------------
    # EC-F005 — Memory Bank
    # -----------------------------------------------------------------------
    TOOL_REGISTRY.register(McpToolDefinition(
        name="memory_write",
        description=(
            "Store a memory entry (decision, constraint, assumption, context, "
            "api_change, schema_change) in the project's Memory Bank."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
                "type": {
                    "type": "string",
                    "enum": ["decision", "constraint", "assumption", "context",
                             "api_change", "schema_change"],
                },
                "title": {"type": "string", "description": "One-line summary."},
                "content": {"type": "string", "description": "Full detail in Markdown."},
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "e.g. ['auth', 'billing', 'db']",
                },
                "importance": {
                    "type": "string",
                    "enum": ["low", "normal", "high", "critical"],
                    "default": "normal",
                },
                "confidence": {
                    "type": "string",
                    "enum": ["high", "medium", "low", "unknown"],
                    "default": "high",
                },
            },
            "required": ["project_id", "type", "title", "content"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="memory_recall",
        description=(
            "Query the Memory Bank using full-text search and/or filters. "
            "Returns the most relevant entries for the current task."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
                "query": {"type": "string", "description": "Full-text search query."},
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter by tags (OR logic).",
                },
                "type": {
                    "type": "string",
                    "enum": ["decision", "constraint", "assumption", "context",
                             "api_change", "schema_change"],
                },
                "importance": {
                    "type": "string",
                    "enum": ["low", "normal", "high", "critical"],
                },
                "confidence": {
                    "type": "string",
                    "enum": ["high", "medium", "low", "unknown"],
                },
                "limit": {
                    "type": "integer",
                    "default": 20,
                    "description": "Max results to return.",
                },
            },
            "required": ["project_id"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="memory_list",
        description="List memory entries with optional type/limit filters (paginated).",
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
                "type": {
                    "type": "string",
                    "enum": ["decision", "constraint", "assumption", "context",
                             "api_change", "schema_change"],
                },
                "limit": {"type": "integer", "default": 50},
                "offset": {"type": "integer", "default": 0},
            },
            "required": ["project_id"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="memory_supersede",
        description=(
            "Mark a memory entry as superseded by a newer decision. "
            "The old entry is preserved for audit — never deleted."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
                "entry_id": {"type": "string", "description": "UUID of entry to supersede."},
                "reason": {"type": "string", "description": "Why this entry is superseded."},
                "replacement_content": {
                    "type": "string",
                    "description": "Optional new entry content to store as replacement.",
                },
            },
            "required": ["project_id", "entry_id", "reason"],
        },
    ))

    # -----------------------------------------------------------------------
    # EC-F006 — Context Syncer
    # -----------------------------------------------------------------------
    TOOL_REGISTRY.register(McpToolDefinition(
        name="context_sync",
        description=(
            "Sync the project architecture into CLAUDE.md via the managed section. "
            "Backs up before write, verifies after write, rolls back on any failure. "
            "CLAUDE.md managed section is always derived — never authoritative."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
                "task": {
                    "type": "string",
                    "description": (
                        "Optional task description to scope context to relevant features only. "
                        "e.g. 'implement payments'"
                    ),
                },
            },
            "required": ["project_id"],
        },
    ))

    TOOL_REGISTRY.register(McpToolDefinition(
        name="context_recall",
        description=(
            "Get task-relevant architectural context without writing to CLAUDE.md. "
            "Use this to answer questions about the architecture mid-session."
        ),
        input_schema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string"},
                "task": {
                    "type": "string",
                    "description": "Task or question to retrieve context for.",
                },
                "limit": {"type": "integer", "default": 10},
            },
            "required": ["project_id", "task"],
        },
    ))

    logger.info("Tool registry initialised | %d tools registered", len(TOOL_REGISTRY))


# Register all definitions when this module is imported
_register_tool_definitions()
