"""
CLI: epic-claude stack — show, confirm, adjust tech stack.

Commands:
  epic-claude stack show
  epic-claude stack confirm
  epic-claude stack adjust [--category <cat>]
"""

from __future__ import annotations

from typing import Optional
try:
    import typer
except ImportError:
    typer = None  # type: ignore

from epic_claude.cli.output import console, print_error, print_success, print_json, is_json_mode
try:
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    from rich.markdown import Markdown
except ImportError:
    Table = Panel = Text = Markdown = None  # type: ignore


tech_app  = typer.Typer(help="Tech stack decisions: show, confirm, adjust.")
stack_app = tech_app  # legacy alias kept for backward compat


def _resolve_project_and_db(project_id: str | None):
    """Resolve project record and memory_db path. Raises on failure."""
    import epic_claude.registry as reg_mod
    from epic_claude.memory.registry_store import RegistryStore
    from epic_claude.server.detection import detect_project, DetectionStatus
    from pathlib import Path
    import os

    registry_db = reg_mod.REGISTRY_DB_PATH

    if project_id is None:
        cwd = Path(os.getcwd())
        detection = detect_project(cwd=cwd, registry_projects_dir=reg_mod.PROJECTS_DIR)
        if detection.status == DetectionStatus.NOT_FOUND or detection.project is None:
            from epic_claude.cli.output import print_no_project_found
        print_no_project_found(str(cwd))
        raise typer.Exit(code=1)
        project_id = detection.project.project_id

    rs = RegistryStore(registry_db); rs.open()
    try:
        project = rs.require_by_id(project_id)
    finally:
        rs.close()

    memory_db = reg_mod.PROJECTS_DIR / project_id / "memory.db"
    return project, memory_db, registry_db


@stack_app.command("show")
def stack_show(
    project_id: Optional[str] = typer.Option(None, "--project-id", help="Project UUID."),
) -> None:
    """Show the current tech stack for the active project."""
    try:
        project, memory_db, _ = _resolve_project_and_db(project_id)

        from epic_claude.agents.stack import get_stack
        result = get_stack(project.id, memory_db)
        stack = result["stack"]

        if is_json_mode():
            print_json(result)
            return

        if not stack:
            console.print("[dim]No stack proposed yet. Run: epic-claude stack decide[/dim]")
            return

        table = Table(
            title=f"Tech Stack — {project.name}",
            show_header=True, header_style="bold cyan",
        )
        table.add_column("Category",  style="bold", width=12)
        table.add_column("Choice",    width=20)
        table.add_column("Version",   width=10)
        table.add_column("Rationale", style="dim")
        table.add_column("Status",    width=12)

        for category, entry in stack.items():
            if not isinstance(entry, dict):
                continue
            status = ""
            if entry.get("confirmed"):
                status = "[green]confirmed[/green]"
            if entry.get("adjusted"):
                status += " [yellow]adjusted[/yellow]"
            table.add_row(
                category,
                entry.get("name", "—"),
                entry.get("version", "—"),
                entry.get("rationale", "—")[:60],
                status or "[dim]proposed[/dim]",
            )
        console.print(table)

        missing = result.get("missing_required", [])
        if missing:
            console.print(f"\n[yellow]⚠ Missing required categories: {missing}[/yellow]")

    except Exception as exc:
        print_error(f"Stack show failed: {exc}")
        raise typer.Exit(code=1)


@stack_app.command("confirm")
def stack_confirm(
    project_id: Optional[str] = typer.Option(None, "--project-id"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
) -> None:
    """Lock the proposed stack (gates architect_generate)."""
    try:
        project, memory_db, registry_db = _resolve_project_and_db(project_id)

        from epic_claude.agents.stack import get_stack, confirm_stack

        result = get_stack(project.id, memory_db)
        if not result["stack"]:
            print_error("No stack to confirm. Run stack decide first.")
            raise typer.Exit(code=1)

        if not is_json_mode():
            # Show summary before confirming
            console.print(f"\n[bold]Stack to confirm for {project.name}:[/bold]")
            for cat, entry in result["stack"].items():
                if isinstance(entry, dict):
                    console.print(f"  {cat:<12} {entry.get('name','?')} {entry.get('version','')}")
            console.print()

            if not yes:
                typer.confirm("Confirm this stack?", abort=True)

        confirmed = confirm_stack(project.id, registry_db, memory_db)

        if is_json_mode():
            print_json(confirmed)
        else:
            print_success(f"Stack confirmed for {project.name}")

    except typer.Abort:
        console.print("[dim]Cancelled.[/dim]")
    except Exception as exc:
        print_error(f"Stack confirm failed: {exc}")
        raise typer.Exit(code=1)


@stack_app.command("adjust")
def stack_adjust(
    category: Optional[str] = typer.Option(None, "--category", "-c", help="Stack category to adjust."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New technology name."),
    rationale: Optional[str] = typer.Option(None, "--rationale", "-r", help="Reason for change."),
    version: str = typer.Option("", "--version", help="Version constraint."),
    project_id: Optional[str] = typer.Option(None, "--project-id"),
) -> None:
    """Adjust one stack category without re-running clarification."""
    try:
        project, memory_db, _ = _resolve_project_and_db(project_id)

        from epic_claude.agents.stack import get_stack, adjust_stack, ALL_CATEGORIES

        # Interactive mode if args not provided
        if not category:
            result = get_stack(project.id, memory_db)
            console.print("\n[bold]Current stack categories:[/bold]")
            for i, (cat, entry) in enumerate(result["stack"].items(), 1):
                if isinstance(entry, dict):
                    console.print(f"  [{i}] {cat:<12} {entry.get('name','?')}")
            console.print()
            category = typer.prompt("Category to adjust")

        if not name:
            name = typer.prompt(f"New choice for '{category}'")
        if not rationale:
            rationale = typer.prompt("Reason for change")

        result = adjust_stack(project.id, category, name, rationale, memory_db, version)

        if is_json_mode():
            print_json(result)
        else:
            print_success(
                f"Stack adjusted: {category} → {name}"
                + (f" (was: {result.get('old_name','?')})" if result.get("old_name") else "")
            )

    except ValueError as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    except Exception as exc:
        print_error(f"Stack adjust failed: {exc}")
        raise typer.Exit(code=1)
