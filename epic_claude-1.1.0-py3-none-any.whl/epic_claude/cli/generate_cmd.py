"""
CLI: epic-claude generate — run the Architect Agent.

Commands:
  epic-claude generate
  epic-claude generate --scope prd
  epic-claude generate --yes          (CI/non-interactive: skip assumption prompts)
"""

from __future__ import annotations

from typing import Optional

try:
    import typer
except ImportError:
    typer = None  # type: ignore

try:
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import Progress, SpinnerColumn, TextColumn
except ImportError:
    Table = Panel = Progress = SpinnerColumn = TextColumn = None  # type: ignore

from epic_claude.cli.output import (
    console, print_error, print_success, print_warning,
    print_json, print_no_project_found, is_json_mode,
)

generate_app = typer.Typer(help="Run the Architect Agent for the active project.") if typer else None


def _get_project(project_id: str | None):
    """Resolve project + paths. Raises on failure."""
    import os
    from pathlib import Path
    import epic_claude.registry as reg_mod
    from epic_claude.memory.registry_store import RegistryStore
    from epic_claude.server.detection import detect_project, DetectionStatus

    if project_id is None:
        cwd = Path(os.getcwd())
        detection = detect_project(cwd=cwd, registry_projects_dir=reg_mod.PROJECTS_DIR)
        if detection.status == DetectionStatus.NOT_FOUND or detection.project is None:
            print_no_project_found(str(cwd))
            raise typer.Exit(code=1)
        project_id = detection.project.project_id

    registry_db = reg_mod.REGISTRY_DB_PATH
    rs = RegistryStore(registry_db); rs.open()
    try:
        project = rs.require_by_id(project_id)
    finally:
        rs.close()

    memory_db = reg_mod.PROJECTS_DIR / project_id / "memory.db"
    return project, memory_db, registry_db, reg_mod.PROJECTS_DIR


if generate_app and typer:

    @generate_app.callback(invoke_without_command=True)
    def generate(
        scope: Optional[str] = typer.Option(
            None, "--scope", "-s",
            help="Artifact to regenerate: prd|api_spec|db_schema|tech_stack|boundaries",
        ),
        yes: bool = typer.Option(
            False, "--yes", "-y",
            help="Non-interactive: proceed with assumptions without prompting. (CI-safe)",
        ),
        project_id: Optional[str] = typer.Option(None, "--project-id"),
    ) -> None:
        """
        Run the Architect Agent: Gate 1 → generate 5 artifacts → Gate 2 → Gate 3.

        Use --yes for CI/CD pipelines to skip assumption confirmation prompts.
        Use --scope to regenerate a single artifact type.
        """
        try:
            project, memory_db, registry_db, projects_dir = _get_project(project_id)

            # Gate: stack must be confirmed
            if not project.stack_confirmed:
                print_error(
                    "Stack not confirmed yet.\n"
                    "  Run: epic-claude stack show\n"
                    "       epic-claude stack confirm"
                )
                raise typer.Exit(code=1)

            # Show assumptions warning in interactive mode
            if not yes and not is_json_mode():
                from epic_claude.memory.database import db_exists
                if db_exists(memory_db):
                    from epic_claude.memory.store import get_store, RecallRequest
                    store = get_store(project.id, memory_db)
                    assumptions = store.recall(RecallRequest(
                        project_id=project.id,
                        entry_type="assumption",
                        confidence="low",
                        limit=10,
                    ))
                    if assumptions:
                        console.print(
                            f"\n[yellow]⚠ {len(assumptions)} low-confidence assumption(s) will be used:[/yellow]"
                        )
                        for a in assumptions:
                            console.print(f"   • {a.title}")
                        console.print()
                        typer.confirm(
                            "Proceed with these assumptions?",
                            default=True,
                            abort=True,
                        )

            # Run generation
            if not is_json_mode():
                action = f"Regenerating {scope}" if scope else "Generating architecture"
                console.print(f"\n[bold]{action} for {project.name}...[/bold]\n")

            import asyncio
            from epic_claude.agents.architect import generate_architecture
            from epic_claude.memory.database import bootstrap_memory_db
            bootstrap_memory_db(memory_db)

            result = asyncio.run(generate_architecture(
                project_id=project.id,
                registry_db_path=registry_db,
                memory_db_path=memory_db,
                projects_dir=projects_dir,
                scope=scope,
            ))

            if is_json_mode():
                print_json(result)
                return

            console.print(f"[green]✓[/green] Architecture generated successfully\n")
            console.print(f"  Features:  {result.get('feature_count', 0)}")
            console.print(f"  Artifacts: {len(result.get('artifacts', []))}")
            console.print(f"  Output:    {result.get('arch_dir', '?')}\n")

            if result.get("assumptions"):
                console.print(f"[yellow]⚠ {len(result['assumptions'])} assumption(s) made — review before building:[/yellow]")
                for a in result["assumptions"][:5]:
                    console.print(f"   • {a.get('assumption_text', a.get('assumed_value', '?'))}")
                console.print()

            console.print("[dim]Next: epic-claude sync[/dim]")

        except typer.Abort:
            console.print("[dim]Cancelled.[/dim]")
        except typer.Exit:
            raise
        except Exception as exc:
            print_error(f"Generation failed: {exc}")
            raise typer.Exit(code=1)
