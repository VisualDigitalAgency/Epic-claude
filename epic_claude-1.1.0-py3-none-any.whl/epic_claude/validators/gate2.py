"""
Gate 2 — Per-Artifact Validators.

Runs after generation, before any file is written.
ALL five artifacts must pass before ANY one of them is written.

PRD §6 Gate 2:
  - prd.md      → PRD Validator  (F-ID uniqueness, depends_on refs, AC present)
  - api.yaml    → OpenAPI 3.1    (openapi-spec-validator, $ref resolved)
  - schema.sql  → SQL Validator  (sqlglot syntax, FK refs valid)
  - boundaries.md → Mermaid      (syntax valid, services referenced)
  - techstack.md  → Stack completeness (all required categories)
  - All         → SHA256 checksum gate

PRD §21 Namespace Rule:
  - F-IDs in generated PRD must use "F" prefix, NEVER "EC-F"
  - Validated here — mixing namespaces is a blocking failure
"""

from __future__ import annotations

import hashlib
import re
import yaml
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from epic_claude.constants import PLATFORM_FEATURE_PREFIX, GENERATED_FEATURE_PREFIX
from epic_claude.exceptions import Gate2ValidationError, NamespaceViolationError
from epic_claude.server.logging import get_logger

logger = get_logger(__name__)

# Required stack categories for Gate 2 (PRD §6)
REQUIRED_STACK_CATEGORIES = {"language", "framework", "database", "auth", "deployment", "testing"}


# ---------------------------------------------------------------------------
# Validation result
# ---------------------------------------------------------------------------

@dataclass
class ArtifactValidation:
    artifact_type: str
    passed: bool
    errors: list[str] = field(default_factory=list)
    checksum: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "artifact_type": self.artifact_type,
            "passed": self.passed,
            "errors": self.errors,
            "checksum": self.checksum,
        }


# ---------------------------------------------------------------------------
# Gate 2 entry point
# ---------------------------------------------------------------------------

def run_gate2(artifacts: dict[str, str]) -> list[ArtifactValidation]:
    """
    Validate all generated artifacts.

    Args:
        artifacts: dict mapping artifact_type → content string.
                   Keys: "prd", "api_spec", "db_schema", "tech_stack", "boundaries"

    Returns:
        List of ArtifactValidation results.
        If any has passed=False, caller must abort all writes.

    Raises:
        Gate2ValidationError: on first failure (with all errors collected).
    """
    results: list[ArtifactValidation] = []
    all_errors: list[str] = []

    validators = {
        "prd":        validate_prd,
        "api_spec":   validate_openapi,
        "db_schema":  validate_sql,
        "tech_stack": validate_stack,
        "boundaries": validate_boundaries,
    }

    for artifact_type, content in artifacts.items():
        validator = validators.get(artifact_type)
        if not validator:
            logger.warning("No validator for artifact type: %s", artifact_type)
            continue

        validation = validator(content)
        validation.checksum = compute_sha256(content)
        results.append(validation)

        if not validation.passed:
            all_errors.extend(
                [f"[{artifact_type}] {e}" for e in validation.errors]
            )
            logger.error(
                "Gate 2 FAILED | artifact=%s | errors=%s",
                artifact_type, validation.errors,
            )

    if all_errors:
        raise Gate2ValidationError(
            message=f"Gate 2 validation failed: {len(all_errors)} error(s)",
            artifact_type="multiple",
            errors=all_errors,
        )

    logger.info("Gate 2 PASSED | artifacts=%s", list(artifacts.keys()))
    return results


# ---------------------------------------------------------------------------
# PRD Validator
# ---------------------------------------------------------------------------

def validate_prd(content: str) -> ArtifactValidation:
    """
    Validate prd.md content.

    Checks:
    - F-ID format: each feature uses F001, F002 … (not EC-F prefix)
    - No duplicate F-IDs
    - depends_on references only valid F-IDs
    - Each feature section has description + acceptance criteria
    """
    errors: list[str] = []

    # Extract all F-IDs (e.g. ## F001 — Title)
    fid_pattern = re.compile(r"^##\s+(F\d{3,})\s+[—-]", re.MULTILINE)
    feature_ids = fid_pattern.findall(content)

    # Namespace violation check — EC-F prefix must not appear in generated PRD features
    ec_f_pattern = re.compile(r"\bEC-F\d{3,}\b")
    ec_violations = ec_f_pattern.findall(content)
    if ec_violations:
        errors.append(
            f"Namespace violation: EC-F IDs found in generated PRD: {ec_violations[:5]}. "
            "Generated features must use F-prefix only (PRD §21)."
        )

    # Duplicate F-ID check
    if len(feature_ids) != len(set(feature_ids)):
        dupes = [fid for fid in feature_ids if feature_ids.count(fid) > 1]
        errors.append(f"Duplicate F-IDs found: {list(set(dupes))}")

    # Each feature must have description and at least one acceptance criterion
    for fid in set(feature_ids):
        # Find the section content for this feature
        pattern = re.compile(
            rf"##\s+{re.escape(fid)}\s+[—-].*?(?=\n##\s+F\d|$)",
            re.DOTALL,
        )
        match = pattern.search(content)
        if match:
            section = match.group(0)
            if "**Description:**" not in section and "Description" not in section:
                errors.append(f"{fid}: missing Description section")
            if "- [ ]" not in section and "Acceptance Criteria" not in section:
                errors.append(f"{fid}: missing Acceptance Criteria")

    # depends_on references must point to valid F-IDs
    depends_pattern = re.compile(r"\*\*Depends on:\*\*\s+(F\d{3,}(?:,\s*F\d{3,})*)")
    for match in depends_pattern.finditer(content):
        refs = [r.strip() for r in match.group(1).split(",")]
        for ref in refs:
            if ref not in feature_ids:
                errors.append(f"depends_on references unknown F-ID: {ref}")

    if not feature_ids:
        errors.append("No F-ID features found in PRD (expected ## F001 — Title format)")

    return ArtifactValidation("prd", len(errors) == 0, errors)


# ---------------------------------------------------------------------------
# OpenAPI 3.1 Validator
# ---------------------------------------------------------------------------

def validate_openapi(content: str) -> ArtifactValidation:
    """
    Validate api.yaml as OpenAPI 3.1.

    Checks:
    - Valid YAML
    - Has openapi: "3.1.0" or "3.0.x"
    - Has info.title and info.version
    - Has paths section
    - All $ref values are syntactically valid
    - Valid HTTP methods on path items
    """
    errors: list[str] = []

    # Parse YAML
    try:
        spec = yaml.safe_load(content)
    except yaml.YAMLError as exc:
        return ArtifactValidation("api_spec", False, [f"Invalid YAML: {exc}"])

    if not isinstance(spec, dict):
        return ArtifactValidation("api_spec", False, ["OpenAPI spec must be a YAML object"])

    # OpenAPI version
    openapi_version = spec.get("openapi", "")
    if not str(openapi_version).startswith(("3.0", "3.1")):
        errors.append(f"Invalid OpenAPI version: {openapi_version!r} (expected 3.0.x or 3.1.x)")

    # info block
    info = spec.get("info", {})
    if not info.get("title"):
        errors.append("Missing info.title")
    if not info.get("version"):
        errors.append("Missing info.version")

    # paths
    paths = spec.get("paths", {})
    if not paths:
        errors.append("Missing or empty paths section")

    valid_methods = {"get", "post", "put", "patch", "delete", "head", "options", "trace"}
    for path, path_item in paths.items():
        if not path.startswith("/"):
            errors.append(f"Path must start with '/': {path!r}")
        if isinstance(path_item, dict):
            for method in path_item:
                if method.lower() not in valid_methods and not method.startswith("x-"):
                    errors.append(f"Invalid HTTP method '{method}' on path {path!r}")

    # $ref validation — all refs must be syntactically valid
    refs = _extract_refs(content)
    for ref in refs:
        if not ref.startswith("#/") and not ref.startswith("http"):
            errors.append(f"Invalid $ref format: {ref!r} (must start with '#/' or 'http')")

    return ArtifactValidation("api_spec", len(errors) == 0, errors)


# ---------------------------------------------------------------------------
# SQL Validator
# ---------------------------------------------------------------------------

def validate_sql(content: str) -> ArtifactValidation:
    """
    Validate schema.sql.

    Checks:
    - At least one CREATE TABLE statement
    - All FK references point to tables defined in the same file
    - All PK columns defined (PRIMARY KEY present)
    - Uses sqlglot for syntax validation if available
    """
    errors: list[str] = []

    # Extract table names from CREATE TABLE statements
    table_pattern = re.compile(
        r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:\w+\.)?(\w+)\s*\(",
        re.IGNORECASE,
    )
    defined_tables = set(table_pattern.findall(content))

    if not defined_tables:
        errors.append("No CREATE TABLE statements found in schema.sql")
        return ArtifactValidation("db_schema", False, errors)

    # Check PK presence in each table block
    # Split content into table blocks
    table_blocks = re.split(r"(?=CREATE\s+TABLE)", content, flags=re.IGNORECASE)
    for block in table_blocks:
        if not re.search(r"CREATE\s+TABLE", block, re.IGNORECASE):
            continue
        if "PRIMARY KEY" not in block.upper():
            match = table_pattern.search(block)
            table_name = match.group(1) if match else "unknown"
            errors.append(f"Table '{table_name}' missing PRIMARY KEY")

    # FK reference validation
    fk_pattern = re.compile(
        r"REFERENCES\s+(?:\w+\.)?(\w+)\s*\(",
        re.IGNORECASE,
    )
    for match in fk_pattern.finditer(content):
        ref_table = match.group(1)
        if ref_table not in defined_tables:
            errors.append(
                f"FK references undefined table: '{ref_table}'. "
                f"Defined tables: {sorted(defined_tables)}"
            )

    # sqlglot syntax validation (if available)
    try:
        import sqlglot
        for stmt in _split_sql_statements(content):
            if not stmt.strip():
                continue
            try:
                sqlglot.parse(stmt)
            except Exception as exc:
                errors.append(f"SQL syntax error: {exc} | near: {stmt[:80]!r}")
    except ImportError:
        logger.debug("sqlglot not installed — skipping syntax validation")

    return ArtifactValidation("db_schema", len(errors) == 0, errors)


# ---------------------------------------------------------------------------
# Stack Completeness Validator
# ---------------------------------------------------------------------------

def validate_stack(content: str) -> ArtifactValidation:
    """
    Validate techstack.md.

    Checks:
    - All required categories present: language, framework, database, auth, deployment, testing
    """
    errors: list[str] = []
    content_lower = content.lower()

    for category in REQUIRED_STACK_CATEGORIES:
        if category not in content_lower:
            errors.append(f"Missing required stack category: {category}")

    return ArtifactValidation("tech_stack", len(errors) == 0, errors)


# ---------------------------------------------------------------------------
# Mermaid / Boundaries Validator
# ---------------------------------------------------------------------------

def validate_boundaries(content: str) -> ArtifactValidation:
    """
    Validate boundaries.md.

    Checks:
    - Contains a ```mermaid block
    - Mermaid block has a valid graph type declaration
    - Services defined in the table are referenced in the diagram
    """
    errors: list[str] = []

    # Extract mermaid block
    mermaid_pattern = re.compile(r"```mermaid\s*(.*?)```", re.DOTALL)
    mermaid_matches = mermaid_pattern.findall(content)

    if not mermaid_matches:
        errors.append("No ```mermaid block found in boundaries.md")
        return ArtifactValidation("boundaries", False, errors)

    for mermaid_content in mermaid_matches:
        mermaid_content = mermaid_content.strip()
        # Must start with a valid graph type
        valid_starts = ("graph", "flowchart", "sequenceDiagram", "erDiagram", "stateDiagram")
        if not any(mermaid_content.lower().startswith(s.lower()) for s in valid_starts):
            errors.append(
                f"Mermaid block missing valid graph type declaration. "
                f"Expected one of: {valid_starts}. "
                f"Got: {mermaid_content[:40]!r}"
            )

    # Services table check — if a Services table exists, extract service names
    service_table_pattern = re.compile(
        r"\|\s*([A-Za-z][\w-]*-service|[A-Za-z][\w-]*Service)\s*\|",
        re.IGNORECASE,
    )
    service_names_in_table = {
        m.group(1).lower() for m in service_table_pattern.finditer(content)
    }

    # If services were found in the table, they should appear in the diagram
    mermaid_body = mermaid_matches[0] if mermaid_matches else ""
    for svc in service_names_in_table:
        svc_key = svc.replace("-", "").replace("service", "").strip()
        if svc_key and svc_key not in mermaid_body.lower():
            # Soft warning — don't fail, just note it
            logger.debug("Service '%s' in table but not clearly in diagram", svc)

    return ArtifactValidation("boundaries", len(errors) == 0, errors)


# ---------------------------------------------------------------------------
# Gate 3 — Post-write checksum verification
# ---------------------------------------------------------------------------

def verify_written_file(
    file_path: Path,
    expected_checksum: str,
    artifact_type: str,
) -> None:
    """
    Gate 3: Re-read written file, compute SHA256, compare to expected.

    Raises:
        Gate2ValidationError (reused as Gate3): on checksum mismatch.
    """
    from epic_claude.exceptions import Gate3ValidationError

    actual_content = file_path.read_text(encoding="utf-8")
    actual_checksum = compute_sha256(actual_content)

    if actual_checksum != expected_checksum:
        raise Gate3ValidationError(
            message=f"Gate 3 checksum mismatch for {artifact_type}: file may be corrupted",
            artifact_type=artifact_type,
            errors=[
                f"Expected checksum: {expected_checksum}",
                f"Actual checksum:   {actual_checksum}",
                f"File path:         {file_path}",
            ],
        )
    logger.debug("Gate 3 PASSED | artifact=%s | checksum=%s", artifact_type, actual_checksum[:12])


# ---------------------------------------------------------------------------
# Checksum utility
# ---------------------------------------------------------------------------

def compute_sha256(content: str) -> str:
    """Compute SHA256 hex digest of UTF-8 encoded content string."""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _extract_refs(content: str) -> list[str]:
    """Extract all $ref values from YAML/JSON content."""
    pattern = re.compile(r"""['"]\$ref['"]\s*:\s*['"]([^'"]+)['"]""")
    return pattern.findall(content)


def _split_sql_statements(sql: str) -> list[str]:
    """Split SQL into individual statements for per-statement validation."""
    statements = []
    current: list[str] = []
    depth = 0

    for line in sql.splitlines():
        stripped = line.strip().upper()
        depth += stripped.count("BEGIN")
        depth -= stripped.count("END")
        depth = max(0, depth)
        current.append(line)
        if line.strip().endswith(";") and depth == 0:
            statements.append("\n".join(current))
            current = []

    if current:
        statements.append("\n".join(current))

    return statements
