"""
EC-F005 — Memory Bank.

Public API:
  - MemoryStore:             per-project memory.db operations
  - RegistryStore:           registry.db project identity operations
  - get_store():             cached store factory
  - close_all_stores():      called on server shutdown
  - register_memory_handlers(): wires MCP tool handlers (call at startup)
  - bootstrap_memory_db():   creates memory.db schema
  - bootstrap_registry_db(): creates registry.db schema
"""

from epic_claude.memory.store import (
    MemoryStore,
    MemoryEntry,
    WriteRequest,
    RecallRequest,
    ListRequest,
    get_store,
    close_all_stores,
)
from epic_claude.memory.registry_store import RegistryStore, ProjectRecord
from epic_claude.memory.database import bootstrap_memory_db, bootstrap_registry_db
from epic_claude.memory.handlers import register_memory_handlers

__all__ = [
    "MemoryStore",
    "MemoryEntry",
    "WriteRequest",
    "RecallRequest",
    "ListRequest",
    "get_store",
    "close_all_stores",
    "RegistryStore",
    "ProjectRecord",
    "bootstrap_memory_db",
    "bootstrap_registry_db",
    "register_memory_handlers",
]
