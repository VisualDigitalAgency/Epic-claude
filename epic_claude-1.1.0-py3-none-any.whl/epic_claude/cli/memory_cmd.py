"""
CLI: epic-claude memory — list, search, show Memory Bank entries.

Commands:
  epic-claude memory list  [--type] [--tag] [--limit]
  epic-claude memory search "<query>"
  epic-claude memory show <id>
"""

from __future__ import annotations

from typing import Optional
try:
    import typer
except ImportError:
    typer = None  # type: ignore

from epic_claude.cli.output import console, print_error, print_json, is_json_mode
try:
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    from rich.markdown import Markdown
except ImportError:
    Table = Panel = Text = Markdown = None  # type: ignore


memory_app = typer.Typer(help="Memory Bank: list, search, show.")


def _get_store(project_id: str | None):
    import os
    import epic_claude.registry as reg_mod
    from epic_claude.memory.store import get_store
    from epic_claude.server.detection import detect_project, DetectionStatus
    from pathlib import Path

    if project_id is None:
        cwd = Path(os.getcwd())
        detection = detect_project(cwd=cwd, registry_projects_dir=reg_mod.PROJECTS_DIR)
        if detection.status == DetectionStatus.NOT_FOUND or detection.project is None:
            from epic_claude.cli.output import print_no_project_found
        import os as _os; print_no_project_found(_os.getcwd())
        raise typer.Exit(code=1)
        project_id = detection.project.project_id

    memory_db = reg_mod.PROJECTS_DIR / project_id / "memory.db"
    return get_store(project_id, memory_db), project_id


@memory_app.command("list")
def memory_list(
    type_filter: Optional[str] = typer.Option(None, "--type", "-t",
        help="Filter by type: decision|constraint|assumption|context|api_change|schema_change"),
    tag: Optional[str] = typer.Option(None, "--tag", help="Filter by tag."),
    limit: int = typer.Option(50, "--limit", "-n", help="Max results."),
    project_id: Optional[str] = typer.Option(None, "--project-id"),
) -> None:
    """List memory entries with optional filters."""
    try:
        store, pid = _get_store(project_id)
        from epic_claude.memory.store import ListRequest
        result = store.list_entries(ListRequest(
            project_id=pid,
            entry_type=type_filter,
            limit=limit,
        ))

        if is_json_mode():
            print_json([e.to_dict() for e in result])
            return

        if not result:
            console.print("[dim]No memory entries found.[/dim]")
            return

        table = Table(show_header=True, header_style="bold cyan",
                      title=f"Memory Entries ({len(result)} shown)")
        table.add_column("ID",         style="dim", width=10)
        table.add_column("Type",       width=14)
        table.add_column("Title",      style="bold")
        table.add_column("Confidence", width=10)
        table.add_column("Created",    style="dim", width=12)

        for entry in result:
            # Tag filter (post-query — FTS handles full queries)
            if tag and tag not in entry.tags:
                continue
            table.add_row(
                entry.id[:8],
                entry.entry_type,
                entry.title[:60],
                entry.confidence,
                entry.created_at[:10] if entry.created_at else "—",
            )
        console.print(table)

    except Exception as exc:
        print_error(f"Memory list failed: {exc}")
        raise typer.Exit(code=1)


@memory_app.command("search")
def memory_search(
    query: str = typer.Argument(..., help="Full-text search query."),
    limit: int = typer.Option(20, "--limit", "-n"),
    project_id: Optional[str] = typer.Option(None, "--project-id"),
) -> None:
    """Full-text search across title, content, and tags."""
    try:
        store, pid = _get_store(project_id)
        from epic_claude.memory.store import RecallRequest
        result = store.recall(RecallRequest(project_id=pid, query=query, limit=limit))

        if is_json_mode():
            print_json([e.to_dict() for e in result])
            return

        if not result:
            console.print(f"[dim]No results for: {query!r}[/dim]")
            return

        console.print(f"\n[bold]Search results for:[/bold] [cyan]{query}[/cyan]\n")
        for entry in result:
            console.print(f"  [bold]{entry.entry_type}[/bold] [{entry.id[:8]}] {entry.title}")
            preview = entry.content[:120].replace("\n", " ")
            console.print(f"  [dim]{preview}...[/dim]\n")

    except Exception as exc:
        print_error(f"Memory search failed: {exc}")
        raise typer.Exit(code=1)


@memory_app.command("show")
def memory_show(
    entry_id: str = typer.Argument(..., help="Memory entry ID (or prefix)."),
    project_id: Optional[str] = typer.Option(None, "--project-id"),
) -> None:
    """Show full details of a memory entry."""
    try:
        store, pid = _get_store(project_id)
        entry = store.get_by_id(entry_id)

        if entry is None:
            print_error(f"Entry not found: {entry_id}")
            raise typer.Exit(code=1)

        if is_json_mode():
            print_json(entry.to_dict())
            return

        console.print(f"\n[bold]Memory Entry: {entry.id}[/bold]")
        console.print(f"Type:       {entry.entry_type}")
        console.print(f"Title:      {entry.title}")
        console.print(f"Importance: {entry.importance}")
        console.print(f"Confidence: {entry.confidence}")
        console.print(f"Source:     {entry.source}")
        console.print(f"Tags:       {', '.join(entry.tags) or '—'}")
        console.print(f"Superseded: {'yes' if entry.is_superseded else 'no'}")
        console.print(f"Created:    {entry.created_at}")
        console.print(f"\n[bold]Content:[/bold]")
        console.print(Markdown(entry.content))

    except typer.Exit:
        raise
    except Exception as exc:
        print_error(f"Memory show failed: {exc}")
        raise typer.Exit(code=1)
