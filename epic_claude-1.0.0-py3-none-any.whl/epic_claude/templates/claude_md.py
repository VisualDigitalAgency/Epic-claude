"""
CLAUDE.md managed section template renderer — Context Syncer.

Builds the inner content for the managed section from project artifacts
and memory entries. Uses string formatting (no Jinja2 dependency at runtime
— Jinja2 is available but we keep this self-contained for reliability).

PRD §17 managed section structure:
  ## Architecture Context (EPIC-Claude — do not edit manually)
  > Derived view. Source of truth: ~/.epic-claude/projects/<id>/
  > Edit via: epic-claude sync
  > Rollback via: epic-claude sync --rollback

  ### Active Tech Stack
  Python 3.11+ · FastAPI · PostgreSQL 15+ · JWT Auth · Railway

  ### Key Architectural Decisions
  - decision1
  - decision2

  ### Feature Context
  [F001 · done] User Management · [F002 · planned] Auth & Sessions · ...

  ### Assumptions (review before building)
  - assumption1
"""

from __future__ import annotations

from typing import Any


def render_managed_section(
    project_id: str,
    project_name: str,
    stack: dict[str, Any],
    artifacts: list[dict[str, Any]],
    memory_entries: list[dict[str, Any]],
    assumptions: list[str],
    task: str | None = None,
) -> str:
    """
    Render the inner content of the managed section.

    Args:
        project_id:     Project UUID.
        project_name:   Human-readable project name.
        stack:          Tech stack dict (category → {name, version, ...}).
        artifacts:      List of artifact dicts from memory.db.
        memory_entries: List of memory entry dicts (decisions, constraints).
        assumptions:    List of assumption strings.
        task:           Optional task for scoped context.

    Returns:
        Inner content string (between markers — no markers included).
    """
    lines: list[str] = []

    # Header
    lines.append("## Architecture Context (EPIC-Claude — do not edit manually)")
    lines.append("")
    lines.append(f"> Derived view. Source of truth: ~/.epic-claude/projects/{project_id[:8]}/")
    lines.append("> Edit via: epic-claude sync")
    lines.append("> Rollback via: epic-claude sync --rollback")

    if task:
        lines.append(f"> Task context: {task}")

    lines.append("")

    # Active Tech Stack
    lines.append("### Active Tech Stack")
    if stack:
        stack_parts = []
        for category in ("language", "framework", "database", "auth", "deployment"):
            entry = stack.get(category, {})
            if isinstance(entry, dict) and entry.get("name"):
                ver = entry.get("version", "")
                part = entry["name"]
                if ver and ver not in ("—", "-", ""):
                    part += f" {ver}"
                stack_parts.append(part)
        lines.append(" · ".join(stack_parts) if stack_parts else "_No stack confirmed yet_")
    else:
        lines.append("_No stack confirmed yet_")
    lines.append("")

    # Key Architectural Decisions
    decisions = [
        e for e in memory_entries
        if e.get("entry_type") in ("decision", "constraint")
        and not e.get("is_superseded")
    ]
    if decisions:
        lines.append("### Key Architectural Decisions")
        # Show top decisions (importance=high/critical first, limit 10)
        sorted_decisions = sorted(
            decisions,
            key=lambda e: {"critical": 0, "high": 1, "normal": 2, "low": 3}.get(
                e.get("importance", "normal"), 2
            ),
        )
        for entry in sorted_decisions[:10]:
            title = entry.get("title", "?")
            fid = _extract_fid(entry)
            line = f"- {title}"
            if fid:
                line += f" ({fid})"
            lines.append(line)
        lines.append("")

    # Feature Context
    prd_artifact = next(
        (a for a in artifacts if a.get("artifact_type") == "prd" and a.get("is_current")),
        None,
    )
    if prd_artifact:
        feature_summaries = _extract_feature_summaries(prd_artifact.get("content", ""))
        if feature_summaries:
            lines.append("### Feature Context")
            lines.append(" · ".join(feature_summaries[:12]))
            lines.append("")

    # Assumptions
    if assumptions:
        lines.append("### Assumptions (review before building)")
        for assumption in assumptions[:8]:
            lines.append(f"- {assumption}")
        lines.append("")

    return "\n".join(lines)


def render_recall_context(
    project_name: str,
    stack: dict[str, Any],
    memory_entries: list[dict[str, Any]],
    task: str,
    limit: int = 10,
) -> str:
    """
    Render task-relevant context for context_recall (no file write).
    Returns a compact markdown summary.
    """
    lines = [
        f"## Context for: {task}",
        f"Project: {project_name}",
        "",
    ]

    # Stack summary
    if stack:
        stack_parts = [
            f"{v['name']}" for k, v in stack.items()
            if isinstance(v, dict) and v.get("name")
            and k in ("language", "framework", "database")
        ]
        if stack_parts:
            lines.append(f"**Stack:** {' · '.join(stack_parts)}")
            lines.append("")

    # Relevant memory entries
    if memory_entries:
        lines.append("**Relevant decisions:**")
        for entry in memory_entries[:limit]:
            lines.append(f"- [{entry.get('entry_type','?')}] {entry.get('title','?')}")
            content_preview = entry.get("content", "")[:100]
            if content_preview:
                lines.append(f"  {content_preview}...")
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _extract_fid(entry: dict[str, Any]) -> str | None:
    """Try to extract an F-ID reference from a memory entry."""
    import re
    content = entry.get("content", "") + " " + entry.get("title", "")
    match = re.search(r"\bF\d{3,}\b", content)
    return match.group(0) if match else None


def _extract_feature_summaries(prd_content: str) -> list[str]:
    """Extract [FXXX · status] title from PRD content."""
    import re
    summaries = []
    pattern = re.compile(
        r"##\s+(F\d{3,})\s+[—-]\s+([^\n]+)\n.*?\*\*Status:\*\*\s+(\w+)",
        re.DOTALL,
    )
    for match in pattern.finditer(prd_content):
        fid, title, status = match.group(1), match.group(2).strip(), match.group(3).strip()
        summaries.append(f"[{fid} · {status}] {title}")
    return summaries
