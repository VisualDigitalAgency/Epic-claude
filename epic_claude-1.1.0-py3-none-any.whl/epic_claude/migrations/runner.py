"""
Migration runner for EPIC-Claude.

Checks schema_version in each SQLite DB and applies any pending migrations.
Called by:
  - `epic-claude migrate` CLI command
  - `epic-claude status` (for version mismatch warning only)
  - Automatically during `epic-claude serve` startup

Design:
  - Each migration is a Python function in migrations/v{N}_{description}.py
  - Migrations are idempotent — safe to re-run
  - Never destructive — only ADD columns/tables, never DROP
  - DB schema version tracked in schema_version table
  - CLI/app version tracked in epic_claude.__version__
  - Project version tracked in project.json
"""

from __future__ import annotations

import importlib
import pkgutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from epic_claude.server.logging import get_logger

logger = get_logger(__name__)

CURRENT_REGISTRY_SCHEMA = 1
CURRENT_MEMORY_SCHEMA   = 1


# ---------------------------------------------------------------------------
# Migration descriptor
# ---------------------------------------------------------------------------

@dataclass
class Migration:
    version: int
    description: str
    apply: Callable  # fn(conn) -> None


# ---------------------------------------------------------------------------
# Built-in migrations
# ---------------------------------------------------------------------------

def _m1_initial(conn) -> None:
    """
    v1 — Baseline. All tables created by bootstrap.
    This migration just records that the DB is at v1.
    Nothing to do structurally.
    """
    pass


REGISTRY_MIGRATIONS: list[Migration] = [
    Migration(1, "initial_registry_schema", _m1_initial),
]

MEMORY_MIGRATIONS: list[Migration] = [
    Migration(1, "initial_memory_schema", _m1_initial),
]


# ---------------------------------------------------------------------------
# Version check
# ---------------------------------------------------------------------------

def get_db_schema_version(db_path: Path) -> int | None:
    """
    Read current schema version from a DB.
    Returns None if schema_version table doesn't exist (pre-versioned DB).
    """
    try:
        from epic_claude.memory.database import open_db
        conn = open_db(db_path)
        try:
            row = conn.execute(
                "SELECT MAX(version) FROM schema_version"
            ).fetchone()
            return row[0] if row and row[0] is not None else 0
        except Exception:
            return None  # Table doesn't exist yet
        finally:
            conn.close()
    except Exception:
        return None


def needs_migration(db_path: Path, target_version: int) -> bool:
    """Return True if the DB needs migration to reach target_version."""
    current = get_db_schema_version(db_path)
    if current is None:
        return True  # No schema_version table — needs initial migration
    return current < target_version


def check_all_projects(projects_dir: Path) -> list[dict]:
    """
    Check all project memory.db files for version mismatches.
    Returns list of {project_id, current_version, needs_migration} dicts.
    """
    results = []
    if not projects_dir.exists():
        return results

    for proj_dir in projects_dir.iterdir():
        if not proj_dir.is_dir():
            continue
        mem_db = proj_dir / "memory.db"
        if not mem_db.exists():
            continue
        current = get_db_schema_version(mem_db)
        results.append({
            "project_id": proj_dir.name,
            "db_path": str(mem_db),
            "current_version": current,
            "target_version": CURRENT_MEMORY_SCHEMA,
            "needs_migration": (current is None or current < CURRENT_MEMORY_SCHEMA),
        })
    return results


# ---------------------------------------------------------------------------
# Migration runner
# ---------------------------------------------------------------------------

def run_migrations(db_path: Path, migrations: list[Migration]) -> dict:
    """
    Apply pending migrations to a DB.

    Returns:
        {"applied": [list of versions applied], "current_version": int}
    """
    from epic_claude.memory.database import open_db, transaction

    current = get_db_schema_version(db_path) or 0
    target  = migrations[-1].version if migrations else 0

    if current >= target:
        logger.debug("DB already at v%d: %s", current, db_path)
        return {"applied": [], "current_version": current}

    conn = open_db(db_path)
    applied = []

    try:
        # Ensure schema_version table exists
        # With isolation_level=None, DDL auto-commits — no explicit COMMIT needed
        conn.execute("""
            CREATE TABLE IF NOT EXISTS schema_version (
                version     INTEGER NOT NULL,
                applied_at  DATETIME NOT NULL DEFAULT (CURRENT_TIMESTAMP),
                description TEXT
            )
        """)

        for migration in migrations:
            if migration.version <= current:
                continue

            logger.info(
                "Applying migration v%d (%s) to %s",
                migration.version, migration.description, db_path.name,
            )

            with transaction(conn, str(db_path)):
                migration.apply(conn)
                conn.execute(
                    "INSERT INTO schema_version (version, applied_at, description) VALUES (?, ?, ?)",
                    (
                        migration.version,
                        datetime.now(timezone.utc).isoformat(),
                        migration.description,
                    ),
                )

            applied.append(migration.version)
            logger.info("Migration v%d applied", migration.version)

    finally:
        conn.close()

    return {"applied": applied, "current_version": target}


def migrate_registry(registry_db: Path) -> dict:
    """Run all pending migrations on registry.db."""
    return run_migrations(registry_db, REGISTRY_MIGRATIONS)


def migrate_memory(memory_db: Path) -> dict:
    """Run all pending migrations on a project's memory.db."""
    return run_migrations(memory_db, MEMORY_MIGRATIONS)


def migrate_all(registry_db: Path, projects_dir: Path) -> dict:
    """
    Run all pending migrations on registry.db and every project's memory.db.

    Returns summary dict.
    """
    summary = {
        "registry": {"path": str(registry_db), "result": None},
        "projects": [],
        "errors": [],
    }

    # Migrate registry.db
    try:
        if registry_db.exists():
            result = migrate_registry(registry_db)
            summary["registry"]["result"] = result
        else:
            summary["registry"]["result"] = {"skipped": "registry.db not found"}
    except Exception as exc:
        summary["errors"].append(f"registry.db: {exc}")
        logger.error("Registry migration failed: %s", exc)

    # Migrate all project memory.db files
    if projects_dir.exists():
        for proj_dir in sorted(projects_dir.iterdir()):
            if not proj_dir.is_dir():
                continue
            mem_db = proj_dir / "memory.db"
            if not mem_db.exists():
                continue
            try:
                result = migrate_memory(mem_db)
                summary["projects"].append({
                    "project_id": proj_dir.name,
                    "result": result,
                })
            except Exception as exc:
                msg = f"project {proj_dir.name}: {exc}"
                summary["errors"].append(msg)
                logger.error("Memory migration failed for %s: %s", proj_dir.name, exc)

    return summary
