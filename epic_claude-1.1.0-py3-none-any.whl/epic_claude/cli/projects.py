"""
CLI: epic-claude projects — list and switch projects.

Commands:
  epic-claude projects list
  epic-claude projects switch <id|path>
"""

from __future__ import annotations

try:
    import typer
except ImportError:
    typer = None  # type: ignore

from epic_claude.cli.output import console, print_error, print_json, is_json_mode
try:
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    from rich.markdown import Markdown
except ImportError:
    Table = Panel = Text = Markdown = None  # type: ignore


projects_app = typer.Typer(help="List and switch projects in the global registry.")


@projects_app.command("list")
def projects_list() -> None:
    """List all registered projects."""
    try:
        import epic_claude.registry as reg_mod
        from epic_claude.memory.registry_store import RegistryStore
        from epic_claude.memory.database import db_exists, bootstrap_registry_db

        db = reg_mod.REGISTRY_DB_PATH
        if not db.exists():
            bootstrap_registry_db(db)

        rs = RegistryStore(db); rs.open()
        try:
            projects = rs.list_active()
        finally:
            rs.close()

        if is_json_mode():
            print_json([p.to_dict() for p in projects])
            return

        if not projects:
            console.print("[dim]No projects registered. Run: epic-claude plan \"<description>\"[/dim]")
            return

        table = Table(title="Registered Projects", show_header=True, header_style="bold cyan")
        table.add_column("ID",       style="dim", width=12)
        table.add_column("Name",     style="bold")
        table.add_column("Type",     width=16)
        table.add_column("Stack",    width=10)
        table.add_column("Arch",     width=10)
        table.add_column("Path",     style="dim")

        for p in projects:
            table.add_row(
                p.id[:8] + "...",
                p.name,
                p.project_type or "—",
                "✓" if p.stack_confirmed else "—",
                "✓" if p.architect_generated else "—",
                p.root_path,
            )
        console.print(table)

    except Exception as exc:
        print_error(f"Failed to list projects: {exc}")
        raise typer.Exit(code=1)


@projects_app.command("switch")
def projects_switch(
    project: str = typer.Argument(None, help="Project ID or root path to switch to."),
) -> None:
    """Switch active project (interactive if no argument given)."""
    try:
        import epic_claude.registry as reg_mod
        from epic_claude.memory.registry_store import RegistryStore

        rs = RegistryStore(reg_mod.REGISTRY_DB_PATH); rs.open()
        try:
            all_projects = rs.list_active()
        finally:
            rs.close()

        if not all_projects:
            print_error("No projects registered.")
            raise typer.Exit(code=1)

        # Find by ID prefix or root_path
        if project:
            matched = [
                p for p in all_projects
                if p.id.startswith(project) or p.root_path == project
            ]
            if not matched:
                print_error(f"No project found matching: {project!r}")
                raise typer.Exit(code=1)
            selected = matched[0]
        else:
            # Interactive picker
            console.print("\n[bold]Available projects:[/bold]")
            for i, p in enumerate(all_projects, 1):
                status = "✓ confirmed" if p.stack_confirmed else "pending"
                console.print(f"  [{i}] {p.name} — {p.root_path} [{status}]")
            console.print()
            choice = typer.prompt("Select project number", default="1")
            try:
                idx = int(choice) - 1
                selected = all_projects[idx]
            except (ValueError, IndexError):
                print_error("Invalid selection.")
                raise typer.Exit(code=1)

        if is_json_mode():
            print_json({"switched_to": selected.to_dict()})
        else:
            console.print(f"[green]✓[/green] Switched to: [bold]{selected.name}[/bold]")
            console.print(f"  Path: [dim]{selected.root_path}[/dim]")
            console.print(f"  ID:   [dim]{selected.id}[/dim]")

    except typer.Exit:
        raise
    except Exception as exc:
        print_error(f"Switch failed: {exc}")
        raise typer.Exit(code=1)
