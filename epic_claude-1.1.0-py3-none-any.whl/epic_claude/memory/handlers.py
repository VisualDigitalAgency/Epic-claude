"""
EC-F005 — Memory Bank MCP tool handlers.

Wires the 4 memory tools into the global MCP tool registry:
  - memory_write
  - memory_recall
  - memory_list
  - memory_supersede

Each handler:
  1. Validates params
  2. Resolves the MemoryStore for the project
  3. Delegates to store operation
  4. Returns a JSON-serialisable dict

Called at server startup by register_memory_handlers().
PRD §13 EC-F005 — MCP Tools.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from epic_claude.exceptions import MemoryEntryNotFoundError
from epic_claude.memory.store import (
    ListRequest,
    RecallRequest,
    WriteRequest,
    close_all_stores,
    get_store,
)
from epic_claude.registry import memory_db_path
from epic_claude.server.logging import get_logger
from epic_claude.server.tools import register_handler

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# memory_write
# ---------------------------------------------------------------------------

async def _handle_memory_write(params: dict[str, Any]) -> dict[str, Any]:
    """
    Store a new memory entry.

    Required: project_id, type, title, content
    Optional: tags, importance, confidence, session_id, feature_id
    """
    project_id = _require(params, "project_id")
    entry_type = _require(params, "type")
    title      = _require(params, "title")
    content    = _require(params, "content")

    req = WriteRequest(
        project_id=project_id,
        entry_type=entry_type,
        title=title,
        content=content,
        tags=params.get("tags") or [],
        importance=params.get("importance", "normal"),
        confidence=params.get("confidence", "high"),
        source=params.get("source", "agent"),
        session_id=params.get("session_id"),
        feature_id=params.get("feature_id"),
    )

    store = _get_store(project_id)
    entry = store.write(req)

    logger.info("memory_write OK: %s | type=%s", entry.id, entry_type)
    return {
        "success": True,
        "entry": entry.to_dict(),
    }


# ---------------------------------------------------------------------------
# memory_recall
# ---------------------------------------------------------------------------

async def _handle_memory_recall(params: dict[str, Any]) -> dict[str, Any]:
    """
    Query memory using FTS and/or column filters.

    Required: project_id
    Optional: query, tags, type, importance, confidence, limit
    """
    project_id = _require(params, "project_id")

    req = RecallRequest(
        project_id=project_id,
        query=params.get("query"),
        tags=params.get("tags") or [],
        entry_type=params.get("type"),
        importance=params.get("importance"),
        confidence=params.get("confidence"),
        include_superseded=bool(params.get("include_superseded", False)),
        limit=int(params.get("limit", 20)),
    )

    store = _get_store(project_id)
    entries = store.recall(req)

    return {
        "entries": [e.to_dict() for e in entries],
        "count": len(entries),
        "query": req.query,
        "filters": {
            "type": req.entry_type,
            "tags": req.tags,
            "importance": req.importance,
            "confidence": req.confidence,
        },
    }


# ---------------------------------------------------------------------------
# memory_list
# ---------------------------------------------------------------------------

async def _handle_memory_list(params: dict[str, Any]) -> dict[str, Any]:
    """
    Paginated list of memory entries.

    Required: project_id
    Optional: type, limit, offset
    """
    project_id = _require(params, "project_id")

    req = ListRequest(
        project_id=project_id,
        entry_type=params.get("type"),
        limit=int(params.get("limit", 50)),
        offset=int(params.get("offset", 0)),
        include_superseded=bool(params.get("include_superseded", False)),
    )

    store = _get_store(project_id)
    entries = store.list_entries(req)
    total = store.count_entries(project_id)

    return {
        "entries": [e.to_dict() for e in entries],
        "count": len(entries),
        "total": total,
        "offset": req.offset,
        "limit": req.limit,
    }


# ---------------------------------------------------------------------------
# memory_supersede
# ---------------------------------------------------------------------------

async def _handle_memory_supersede(params: dict[str, Any]) -> dict[str, Any]:
    """
    Mark a memory entry as superseded.
    Never deletes — preserves full audit trail.

    Required: project_id, entry_id, reason
    Optional: replacement_content
    """
    project_id          = _require(params, "project_id")
    entry_id            = _require(params, "entry_id")
    reason              = _require(params, "reason")
    replacement_content = params.get("replacement_content")

    store = _get_store(project_id)

    try:
        updated = store.supersede(
            project_id=project_id,
            entry_id=entry_id,
            reason=reason,
            replacement_content=replacement_content,
        )
    except MemoryEntryNotFoundError as exc:
        return {"success": False, "error": exc.message}

    return {
        "success": True,
        "entry": updated.to_dict(),
        "replacement_written": replacement_content is not None,
    }


# ---------------------------------------------------------------------------
# Registration — called once at server startup
# ---------------------------------------------------------------------------

def register_memory_handlers() -> None:
    """
    Wire all EC-F005 tool handlers into the global MCP tool registry.
    Called during server initialisation (Phase 1 server startup).
    """
    register_handler("memory_write",     _handle_memory_write)
    register_handler("memory_recall",    _handle_memory_recall)
    register_handler("memory_list",      _handle_memory_list)
    register_handler("memory_supersede", _handle_memory_supersede)
    logger.info("EC-F005 Memory Bank handlers registered (4 tools)")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _require(params: dict[str, Any], key: str) -> Any:
    val = params.get(key)
    if val is None:
        raise TypeError(f"Required parameter missing: '{key}'")
    return val


def _get_store(project_id: str):
    """Resolve the MemoryStore for a project using the global registry path."""
    from epic_claude.registry import PROJECTS_DIR
    db_path = PROJECTS_DIR / project_id / "memory.db"
    return get_store(project_id, db_path)
