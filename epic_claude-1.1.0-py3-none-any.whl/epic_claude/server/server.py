"""
EPIC-Claude MCP Server — stdio transport.

The server reads newline-delimited JSON-RPC 2.0 messages from stdin,
dispatches them to handlers, and writes responses to stdout.

Execution model: per-command stdio transport, no background daemon, no ports.
Spawned by Claude Code on demand, exits on EOF. Safe to kill — all writes atomic.

CRITICAL: stdout is reserved exclusively for JSON-RPC wire traffic.
          ALL logging goes to ~/.epic/server.log via the file handler.
          Any accidental write to stdout would corrupt the MCP protocol.

PRD §13 EC-F001 acceptance criteria:
  ✓ epic-claude serve starts via stdio transport
  ✓ MCP initialize handshake
  ✓ tools/list + tools/call routing
  ✓ JSON-RPC 2.0 id field always in responses
  ✓ Graceful shutdown on SIGINT / SIGTERM
  ✓ Config loaded from ~/.epic/config.json on startup
  ✓ epic-claude serve --dry-run validates config and exits cleanly
  ✓ All server activity logged to server.log — never to stdio

PRD §18 perf: MCP initialize < 200ms
"""

from __future__ import annotations

import asyncio
import json
import signal
import sys
from pathlib import Path
from typing import TYPE_CHECKING

from epic_claude.server.handlers import dispatch_method
from epic_claude.server.logging import get_logger, setup_server_logging
from epic_claude.server.protocol import (
    JsonRpcRequest,
    internal_error,
    invalid_request,
    parse_error,
)

if TYPE_CHECKING:
    from epic_claude.config import EpicClaudeConfig

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Server class
# ---------------------------------------------------------------------------

class EpicClaudeServer:
    """
    Async stdio MCP server.

    Reads from stdin, writes to stdout.
    One message per line (newline-delimited JSON).
    """

    def __init__(self, config: "EpicClaudeConfig", log_path: Path) -> None:
        self.config   = config
        self.log_path = log_path
        self._running  = False
        self._shutdown_event = asyncio.Event()

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------

    async def run(self) -> None:
        """Start the server loop. Blocks until shutdown."""
        self._running = True
        self._install_signal_handlers()

        logger.info(
            "EPIC-Claude MCP server starting | model=%s | pid=%d",
            self.config.llm_model,
            __import__("os").getpid(),
        )

        # Use asyncio streams wrapping stdin/stdout
        reader = await self._make_stdin_reader()
        writer = self._make_stdout_writer()

        logger.info("MCP server ready — waiting for messages on stdio")

        try:
            await self._message_loop(reader, writer)
        except asyncio.CancelledError:
            logger.info("Server loop cancelled")
        finally:
            await self._shutdown(writer)

    async def dry_run(self) -> bool:
        """
        Validate config and tool registry without starting the server.
        PRD §13 EC-F001: epic-claude serve --dry-run validates config and exits cleanly.
        Returns True on success.
        """
        from epic_claude.server.tools import TOOL_REGISTRY

        logger.info("Dry run: validating config and tool registry")

        errors: list[str] = []

        # Validate config
        if not self.config.validation_gates_enabled:
            errors.append("WARNING: validation_gates_enabled=false (should be true in production)")

        # Validate tool registry
        tool_count = len(TOOL_REGISTRY)
        if tool_count == 0:
            errors.append("ERROR: No tools registered in tool registry")

        # Validate log path is writable
        try:
            self.log_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        except OSError as exc:
            errors.append(f"ERROR: Cannot create log directory: {exc}")

        for err in errors:
            logger.warning("Dry run: %s", err)

        if any(e.startswith("ERROR") for e in errors):
            logger.error("Dry run FAILED: %d error(s)", sum(1 for e in errors if e.startswith("ERROR")))
            return False

        logger.info(
            "Dry run OK | tools=%d | log=%s | model=%s",
            tool_count, self.log_path, self.config.llm_model,
        )
        return True

    # -----------------------------------------------------------------------
    # Message loop
    # -----------------------------------------------------------------------

    async def _message_loop(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        """Core read → parse → dispatch → write loop."""
        while self._running and not self._shutdown_event.is_set():
            try:
                line = await asyncio.wait_for(
                    reader.readline(),
                    timeout=1.0,  # allows checking shutdown_event periodically
                )
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break

            if not line:
                # EOF — Claude Code disconnected
                logger.info("EOF on stdin — shutting down")
                break

            raw = line.decode("utf-8", errors="replace").strip()
            if not raw:
                continue

            response = await self._handle_raw_message(raw)

            if response is not None:
                response_json = response.to_json()
                writer.write((response_json + "\n").encode("utf-8"))
                await writer.drain()
                logger.debug("Response sent: %d bytes", len(response_json))

    async def _handle_raw_message(self, raw: str) -> "JsonRpcResponse | JsonRpcErrorResponse | None":
        """Parse one raw JSON string and dispatch it. Always returns a response or None."""
        # Parse JSON
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            logger.warning("JSON parse error: %s | raw=%r", exc, raw[:200])
            return parse_error(req_id=None)

        # Must be a dict
        if not isinstance(data, dict):
            logger.warning("Invalid request (not a dict): %r", raw[:200])
            return invalid_request(req_id=None, detail="Request must be a JSON object")

        # Parse into JsonRpcRequest
        try:
            req = JsonRpcRequest.from_dict(data)
        except ValueError as exc:
            req_id = data.get("id")
            logger.warning("Invalid JSON-RPC request: %s", exc)
            return invalid_request(req_id=req_id, detail=str(exc))

        # Dispatch
        try:
            return await dispatch_method(req)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Unhandled exception dispatching %s: %s", req.method, exc)
            return internal_error(req.id, f"{type(exc).__name__}: {exc}")

    # -----------------------------------------------------------------------
    # Startup / shutdown
    # -----------------------------------------------------------------------

    def _install_signal_handlers(self) -> None:
        """
        Install SIGINT/SIGTERM handlers for graceful shutdown.
        PRD §13 EC-F001: closes DB connections cleanly.
        """
        loop = asyncio.get_event_loop()

        def _handle_signal(sig: signal.Signals) -> None:
            logger.info("Signal received: %s — initiating graceful shutdown", sig.name)
            self._running = False
            self._shutdown_event.set()

        try:
            loop.add_signal_handler(signal.SIGINT,  lambda: _handle_signal(signal.SIGINT))
            loop.add_signal_handler(signal.SIGTERM, lambda: _handle_signal(signal.SIGTERM))
        except NotImplementedError:
            # Windows — signal handlers not supported in asyncio event loop
            logger.warning("Signal handlers not available on this platform (Windows?)")

    async def _shutdown(self, writer: asyncio.StreamWriter) -> None:
        """Clean shutdown: flush writer, close DB connections."""
        logger.info("Shutting down EPIC-Claude MCP server")
        self._running = False

        try:
            writer.close()
            await writer.wait_closed()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Error closing stdout writer: %s", exc)

        # DB connection cleanup will be handled by each feature module
        # (registered via atexit or explicit close in Phase 2)
        logger.info("Server shutdown complete")

    # -----------------------------------------------------------------------
    # stdio stream helpers
    # -----------------------------------------------------------------------

    @staticmethod
    async def _make_stdin_reader() -> asyncio.StreamReader:
        """Wrap sys.stdin.buffer as an asyncio StreamReader."""
        loop = asyncio.get_event_loop()
        reader = asyncio.StreamReader()
        protocol = asyncio.StreamReaderProtocol(reader)
        await loop.connect_read_pipe(lambda: protocol, sys.stdin.buffer)
        return reader

    @staticmethod
    def _make_stdout_writer() -> asyncio.StreamWriter:
        """Wrap sys.stdout.buffer as an asyncio StreamWriter."""
        loop = asyncio.get_event_loop()

        # Use a synchronous wrapper since stdout writes are typically fast
        class _SyncWriter:
            """Minimal asyncio.StreamWriter-compatible wrapper for stdout."""

            def write(self, data: bytes) -> None:
                sys.stdout.buffer.write(data)

            async def drain(self) -> None:
                sys.stdout.buffer.flush()

            def close(self) -> None:
                sys.stdout.buffer.flush()

            async def wait_closed(self) -> None:
                pass

        return _SyncWriter()  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Entry point (called by CLI `epic-claude serve`)
# ---------------------------------------------------------------------------

def run_server(config: "EpicClaudeConfig", log_path: Path, dry_run: bool = False) -> int:
    """
    Synchronous entry point for starting the MCP server.
    Returns exit code (0 = success, 1 = error).
    Called by epic_claude/cli/serve.py.
    """
    # Setup logging FIRST — before any other output
    setup_server_logging(config, log_path)

    server = EpicClaudeServer(config=config, log_path=log_path)

    if dry_run:
        result = asyncio.run(_dry_run(server))
        return 0 if result else 1

    try:
        asyncio.run(server.run())
        return 0
    except KeyboardInterrupt:
        logger.info("KeyboardInterrupt received — server stopped")
        return 0
    except Exception as exc:  # noqa: BLE001
        logger.exception("Fatal server error: %s", exc)
        return 1


async def _dry_run(server: EpicClaudeServer) -> bool:
    return await server.dry_run()
