"""
CLI: epic-claude status — project health dashboard.

Shows: stack status, artifacts, last sync, memory count, recent errors.
PRD §13 EC-F007: epic-claude status < 300ms (no LLM calls).
"""

from __future__ import annotations

from typing import Optional
try:
    import typer
except ImportError:
    typer = None  # type: ignore

from epic_claude.cli.output import console, print_error, print_json, is_json_mode
try:
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    from rich.markdown import Markdown
except ImportError:
    Table = Panel = Text = Markdown = None  # type: ignore


status_app = typer.Typer()


@status_app.callback(invoke_without_command=True)
def status(
    project_id: Optional[str] = typer.Option(None, "--project-id"),
) -> None:
    """Show project health dashboard (stack, artifacts, sync state, memory count)."""
    try:
        import os
        from pathlib import Path
        import epic_claude.registry as reg_mod
        from epic_claude.memory.registry_store import RegistryStore
        from epic_claude.memory.database import db_exists
        from epic_claude.server.detection import detect_project, DetectionStatus

        if project_id is None:
            cwd = Path(os.getcwd())
            detection = detect_project(cwd=cwd, registry_projects_dir=reg_mod.PROJECTS_DIR)
            if detection.status == DetectionStatus.NOT_FOUND or detection.project is None:
                from epic_claude.cli.output import print_no_project_found
                print_no_project_found(str(cwd))
                return
            project_id = detection.project.project_id

        registry_db = reg_mod.REGISTRY_DB_PATH
        rs = RegistryStore(registry_db); rs.open()
        try:
            project = rs.require_by_id(project_id)
        finally:
            rs.close()

        memory_db = reg_mod.PROJECTS_DIR / project_id / "memory.db"

        # Gather data (all DB reads — no LLM)
        memory_count    = 0
        artifact_count  = 0
        last_sync_state = "never"
        last_sync_at    = "—"

        if db_exists(memory_db):
            from epic_claude.memory.store import get_store
            from epic_claude.sync.state_machine import get_last_sync

            store = get_store(project_id, memory_db)
            memory_count = store.count_entries(project_id)

            from epic_claude.agents.architect import list_artifacts
            artifact_count = len(list_artifacts(project_id, memory_db))

            last = get_last_sync(project_id, memory_db)
            if last:
                last_sync_state = last["sync_state"]
                last_sync_at    = last["synced_at"][:19] if last.get("synced_at") else "—"

        data = {
            "project_id":          project.id,
            "name":                project.name,
            "project_type":        project.project_type or "unknown",
            "root_path":           project.root_path,
            "clarification":       "complete" if project.clarification_complete else "pending",
            "stack":               "confirmed" if project.stack_confirmed else "pending",
            "architecture":        "generated" if project.architect_generated else "pending",
            "artifact_count":      artifact_count,
            "memory_entry_count":  memory_count,
            "last_sync_state":     last_sync_state,
            "last_sync_at":        last_sync_at,
        }

        if is_json_mode():
            print_json(data)
            return

        # Rich dashboard
        grid = Table.grid(padding=(0, 2))
        grid.add_column(style="bold cyan", width=22)
        grid.add_column()

        grid.add_row("Project",       f"[bold]{project.name}[/bold]")
        grid.add_row("Type",          project.project_type or "—")
        grid.add_row("ID",            f"[dim]{project.id[:8]}...[/dim]")
        grid.add_row("Path",          f"[dim]{project.root_path}[/dim]")
        grid.add_row("", "")
        grid.add_row("Clarification", _status_badge(project.clarification_complete))
        grid.add_row("Stack",         _status_badge(project.stack_confirmed))
        grid.add_row("Architecture",  _status_badge(project.architect_generated))
        grid.add_row("", "")
        grid.add_row("Artifacts",     str(artifact_count))
        grid.add_row("Memory entries",str(memory_count))
        grid.add_row("", "")
        grid.add_row("Last sync",     f"{last_sync_state} at {last_sync_at}")

        console.print(Panel(grid, title=f"[bold]epic-claude status[/bold]",
                            border_style="cyan", padding=(1, 2)))

    except Exception as exc:
        print_error(f"Status failed: {exc}")
        raise typer.Exit(code=1)


def _status_badge(done: bool) -> str:
    return "[green]✓ done[/green]" if done else "[yellow]⏳ pending[/yellow]"
