# EPIC-Claude

> Universal AI Solutions Architect for Claude Code

[![CI](https://github.com/epic-claude/epic-claude/actions/workflows/ci.yml/badge.svg)](https://github.com/epic-claude/epic-claude/actions)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

EPIC-Claude is an open-source **global MCP server** for Claude Code. Install it once. It works across every project you open.

When you describe what you want to build, EPIC-Claude asks targeted questions, confirms a tech stack, then generates a complete production-grade architecture — PRD, Mermaid diagram, SQL schema, OpenAPI 3.1 spec, and service boundaries. All outputs are validated before write, stored in a global registry, and synced safely into your project's `CLAUDE.md`.

Claude Code then builds with full architectural awareness that persists across sessions.

---

## What EPIC-Claude Does

```
Describe project → Clarify requirements → Confirm tech stack
→ Validate checklist → Generate architecture → Validate outputs
→ Persist to memory → Sync to CLAUDE.md → Claude Code builds
```

### Generated Artifacts (all validated before write)

| Artifact | Format | Validator |
|---|---|---|
| `prd.md` | Markdown | F-ID uniqueness + reference integrity |
| `api.yaml` | OpenAPI 3.1 | `openapi-spec-validator` |
| `schema.sql` | SQL | `sqlglot` syntax + FK integrity |
| `techstack.md` | Markdown | All categories present |
| `boundaries.md` | Mermaid | Syntax + service reference check |

### Supported Project Types (v1)

- **Backend SaaS** — multi-tenant APIs, subscriptions, auth, billing
- **REST APIs** — resource-oriented, CRUD, webhooks, versioning
- **Fullstack Web** — frontend + backend + DB + auth

---

## Install

### Recommended: pipx (isolated, no env conflicts)

```bash
# Install pipx first if needed
pip install --user pipx
pipx ensurepath

# Install epic globally
pipx install epic-claude

# Verify
epic version
```

### Alternative: uv

```bash
uv tool install epic-claude
```

### Alternative: pip

```bash
pip install epic-claude
```

> **Why pipx?** It installs epic-claude in an isolated environment — no dependency conflicts
> with your project's venv. This is the recommended approach for any global CLI tool.

### Fix PATH after install

If `epic` is not found after installing:

```bash
# Add pipx bin directory to PATH
pipx ensurepath

# Then reload your shell
source ~/.bashrc    # bash
source ~/.zshrc     # zsh
# Or just restart your terminal
```

### First-time setup

```bash
# Initialise global registry (~/.epic/)
epic init

# Set your Anthropic API key (never stored in config files)
export ANTHROPIC_API_KEY=your-key-here  # add to ~/.bashrc or ~/.zshrc

# Health check
epic doctor
```

### Add to Claude Code

Add to `~/.claude/settings.json`:

```json
{
  "mcpServers": {
    "epic": {
      "command": "epic",
      "args": ["serve"]
    }
  }
}
```

### Set API key

```bash
export ANTHROPIC_API_KEY=your-key-here
```

> The API key is **never** stored in config files. Environment variable only.

---

## Quickstart

```bash
# Start a new project architecture
epic plan "I want to build a SaaS invoicing app"

# After clarification + stack confirmation, generate architecture
epic generate

# Sync architecture into CLAUDE.md
epic sync

# Check project status
epic status
```

---

## Execution Model

EPIC-Claude runs **per-command, per-invocation** — no background daemon, no ports, no zombie processes.

```
Claude Code  ──JSON-RPC 2.0──▶  epic serve  ──▶  exits when Claude Code disconnects
CLI user     ──────────────▶  epic <command>  ──▶  runs, writes, exits
```

- **No background server** — `epic serve` is spawned by Claude Code on demand via stdio
- **No port conflicts** — transport is stdin/stdout, not TCP
- **No session state** — every invocation reads from SQLite, writes to SQLite, exits cleanly
- **Safe to kill** — all writes are atomic (tmpfile → rename); partial writes are impossible

## Architecture

```
~/.epic-claude/           ← Global registry (one install, all projects)
├── registry.db           ← Tier 4: project identity
├── config.json           ← Global config (no credentials)
├── server.log            ← MCP server log (rotated)
└── projects/
    └── <project-uuid>/
        ├── memory.db     ← Tier 1: all decisions (source of truth)
        ├── project.json  ← Project metadata
        ├── architecture/ ← Tier 2: generated artifacts
        │   ├── prd.md
        │   ├── techstack.md
        │   ├── api.yaml
        │   ├── schema.sql
        │   └── boundaries.md
        └── claude_md_backups/  ← Pre-sync backups (30 day retention)
```

### State Authority (highest → lowest)

```
memory.db  >  architecture/  >  CLAUDE.md (managed section)  >  registry.db
```

`CLAUDE.md` is **always derived, never authoritative.** It can be deleted and reconstructed at any time with `epic sync`.

---

## CLI Reference

```bash
epic version              # Show version
epic init                 # Initialise ~/.epic/
epic doctor               # Health check
epic serve                # Start MCP server (stdio transport)
epic plan "<description>" # Start new project
epic stack show           # Show confirmed tech stack
epic stack confirm        # Confirm proposed stack
epic stack adjust         # Adjust one stack category
epic generate             # Generate all 5 architecture artifacts
epic memory list          # List memory entries
epic memory search "<q>"  # Full-text search memory
epic sync                 # Sync architecture to CLAUDE.md
epic sync --dry-run       # Preview sync output
epic sync --rollback      # Restore from last backup
epic status               # Show project state summary
epic projects list        # List all registered projects
epic projects switch      # Switch active project
```

---

## Design Principles

| Principle | Meaning |
|---|---|
| Global, not local | One install. All projects on the machine. |
| Clarify first | Ask before deciding. One follow-up for unknowns. |
| Validate before write | No artifact reaches disk without passing validation. |
| State has one owner | Every piece of data has exactly one authoritative source. |
| Sync is safe by design | Backup, managed section, state machine, rollback. |
| Fail loudly, recover cleanly | No silent failures. Every error is logged and actionable. |
| CLI-first | Everything works in terminal. No browser required. |
| MCP-native | JSON-RPC 2.0 over stdio. Zero network config. |

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).

Branch naming: `feature/EC-FXXX-short-description`
PR title must reference the EC-F feature ID.

**Namespace rule (non-negotiable):**
- `EC-FXXX` = EPIC-Claude platform features
- `FXXX` = Features in a user's generated project PRD
- **Never mix these in code, docs, CLI output, or issues.**

---

## License

MIT — see [LICENSE](LICENSE).
