"""
EPIC-Claude shared constants.

Single source of truth for:
- JSON-RPC 2.0 error codes (PRD §13 EC-F001)
- Project type literals (PRD §2)
- Sync state machine states (PRD §7)
- Artifact types (PRD §12)
- Memory entry types (PRD §12)
- Feature ID namespaces (PRD §21 — NON-NEGOTIABLE)
"""

from __future__ import annotations

import sys
if sys.version_info >= (3, 11):
    from enum import StrEnum
else:
    # StrEnum backport for Python 3.10
    from enum import Enum
    class StrEnum(str, Enum):
        """str + Enum combined — identical to Python 3.11 StrEnum."""
        def __str__(self) -> str:
            return self.value


# ---------------------------------------------------------------------------
# JSON-RPC 2.0 error codes (PRD §13 EC-F001)
# ---------------------------------------------------------------------------

class JsonRpcError:
    PARSE_ERROR      = -32700
    INVALID_REQUEST  = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS   = -32602
    INTERNAL_ERROR   = -32603


# ---------------------------------------------------------------------------
# Supported project types — v1 only (PRD §2)
# ---------------------------------------------------------------------------

class ProjectType(StrEnum):
    BACKEND_SAAS  = "backend_saas"
    REST_API      = "rest_api"
    FULLSTACK_WEB = "fullstack_web"

SUPPORTED_PROJECT_TYPES = frozenset(ProjectType)

UNSUPPORTED_PROJECT_TYPE_MESSAGE = """\
✗ Project type not supported in v1: {project_type}

  EPIC-Claude v1 supports:
  · Backend SaaS
  · REST APIs
  · Fullstack Web

  Could your project be expressed as a REST API backend?
  If yes, re-describe it with that framing and try again.
  Mobile, infra, data pipeline, and AI/ML support is planned for v2.
"""


# ---------------------------------------------------------------------------
# Sync state machine states (PRD §7)
# ---------------------------------------------------------------------------

class SyncState(StrEnum):
    READY      = "READY"
    BACKING_UP = "BACKING_UP"
    WRITING    = "WRITING"
    VERIFYING  = "VERIFYING"
    LOGGING    = "LOGGING"
    DONE       = "DONE"
    ABORTED    = "ABORTED"
    RESTORING  = "RESTORING"
    RESTORED   = "RESTORED"
    FAILED     = "FAILED"

SYNC_FAILURE_MESSAGES = {
    SyncState.ABORTED:   "Sync aborted: could not create backup. CLAUDE.md was not modified.",
    SyncState.RESTORING: "Write failed. Restoring CLAUDE.md from backup at {backup_path}.",
    SyncState.RESTORED:  "CLAUDE.md restored successfully from backup. No changes were made.",
    SyncState.FAILED:    "Critical: CLAUDE.md restore also failed. Manual recovery needed. Backup at: {backup_path}",
}


# ---------------------------------------------------------------------------
# Artifact types (PRD §12)
# ---------------------------------------------------------------------------

class ArtifactType(StrEnum):
    PRD        = "prd"
    API_SPEC   = "api_spec"
    DB_SCHEMA  = "db_schema"
    TECH_STACK = "tech_stack"
    BOUNDARIES = "boundaries"

ALL_ARTIFACT_TYPES = [
    ArtifactType.PRD,
    ArtifactType.API_SPEC,
    ArtifactType.DB_SCHEMA,
    ArtifactType.TECH_STACK,
    ArtifactType.BOUNDARIES,
]

ARTIFACT_CONTENT_FORMATS = {
    ArtifactType.PRD:        "markdown",
    ArtifactType.API_SPEC:   "yaml",
    ArtifactType.DB_SCHEMA:  "sql",
    ArtifactType.TECH_STACK: "markdown",
    ArtifactType.BOUNDARIES: "markdown",
}


# ---------------------------------------------------------------------------
# Memory entry types (PRD §12)
# ---------------------------------------------------------------------------

class MemoryEntryType(StrEnum):
    DECISION     = "decision"
    CONSTRAINT   = "constraint"
    ASSUMPTION   = "assumption"
    CONTEXT      = "context"
    API_CHANGE   = "api_change"
    SCHEMA_CHANGE = "schema_change"


# ---------------------------------------------------------------------------
# Confidence levels (PRD §8)
# ---------------------------------------------------------------------------

class Confidence(StrEnum):
    HIGH    = "high"
    MEDIUM  = "medium"
    LOW     = "low"
    UNKNOWN = "unknown"


# ---------------------------------------------------------------------------
# Feature status / priority (PRD §12)
# ---------------------------------------------------------------------------

class FeatureStatus(StrEnum):
    PLANNED     = "planned"
    IN_PROGRESS = "in_progress"
    DONE        = "done"
    DEPRECATED  = "deprecated"

class FeaturePriority(StrEnum):
    LOW      = "low"
    MEDIUM   = "medium"
    HIGH     = "high"
    CRITICAL = "critical"


# ---------------------------------------------------------------------------
# Memory entry importance (PRD §12)
# ---------------------------------------------------------------------------

class Importance(StrEnum):
    LOW      = "low"
    NORMAL   = "normal"
    HIGH     = "high"
    CRITICAL = "critical"


# ---------------------------------------------------------------------------
# Session status (PRD §12)
# ---------------------------------------------------------------------------

class SessionStatus(StrEnum):
    ACTIVE    = "active"
    COMPLETED = "completed"
    ABANDONED = "abandoned"


# ---------------------------------------------------------------------------
# Sync trigger source (PRD §12)
# ---------------------------------------------------------------------------

class SyncTrigger(StrEnum):
    MANUAL        = "manual"
    SESSION_START = "session_start"
    AUTO          = "auto"


# ---------------------------------------------------------------------------
# Feature ID namespace — NON-NEGOTIABLE (PRD §21)
# ---------------------------------------------------------------------------

PLATFORM_FEATURE_PREFIX  = "EC-F"   # EPIC-Claude platform: EC-F001, EC-F002 ...
GENERATED_FEATURE_PREFIX = "F"      # User project features: F001, F002 ...

NAMESPACE_VIOLATION_MESSAGE = (
    "Namespace violation: '{feature_id}' uses the wrong prefix. "
    f"Platform features use '{PLATFORM_FEATURE_PREFIX}XXX'. "
    f"Generated project features use '{GENERATED_FEATURE_PREFIX}XXX'. "
    "These namespaces must never be mixed."
)


# ---------------------------------------------------------------------------
# CLAUDE.md managed section markers (PRD §17)
# ---------------------------------------------------------------------------

MANAGED_SECTION_START_TPL = (
    "<!-- EPIC-CLAUDE-MANAGED-START | version:{version} | "
    "synced:{synced_at} | hash:{content_hash} -->"
)
MANAGED_SECTION_END = "<!-- EPIC-CLAUDE-MANAGED-END -->"


# ---------------------------------------------------------------------------
# Performance targets (PRD §18 — used in tests)
# ---------------------------------------------------------------------------

class PerfTarget:
    MCP_INITIALIZE_MS        = 200
    CLARIFY_ANSWER_MS        = 3_000
    STACK_DECIDE_MS          = 5_000
    ARCHITECT_GENERATE_MS    = 90_000
    GATE2_VALIDATION_MS      = 2_000
    MEMORY_RECALL_MS         = 100
    CONTEXT_SYNC_MS          = 1_000
    STATUS_COMMAND_MS        = 300
