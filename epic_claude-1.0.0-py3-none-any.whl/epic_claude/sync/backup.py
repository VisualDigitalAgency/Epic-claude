"""
CLAUDE.md backup management — EC-F006.

PRD §13 EC-F006:
  - Always backup to claude_md_backups/CLAUDE.md.<timestamp> before write
  - Backup retention: 30 days default (configurable)
  - Restore from most recent backup on --rollback

PRD §11 filesystem layout:
  ~/.epic-claude/projects/<id>/claude_md_backups/
    CLAUDE.md.2026-03-22T10:34:00Z
    CLAUDE.md.2026-03-22T09:15:00Z
"""

from __future__ import annotations

import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path

from epic_claude.exceptions import SyncBackupError, SyncRestoreError
from epic_claude.server.logging import get_logger

logger = get_logger(__name__)

BACKUP_FILENAME_PREFIX = "CLAUDE.md."


def create_backup(
    claude_md_path: Path,
    backup_dir: Path,
) -> Path:
    """
    Create a timestamped backup of CLAUDE.md before writing.

    Args:
        claude_md_path: Path to CLAUDE.md (may not exist — that's fine).
        backup_dir:     Directory for backups (claude_md_backups/).

    Returns:
        Path to the created backup file.

    Raises:
        SyncBackupError: if backup creation fails.
    """
    backup_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    backup_path = backup_dir / f"{BACKUP_FILENAME_PREFIX}{timestamp}"

    try:
        if claude_md_path.exists():
            shutil.copy2(str(claude_md_path), str(backup_path))
            logger.info("Backup created: %s (%d bytes)", backup_path.name, backup_path.stat().st_size)
        else:
            # Create an empty backup marker — CLAUDE.md didn't exist yet
            backup_path.write_text("", encoding="utf-8")
            logger.info("Empty backup marker created (CLAUDE.md did not exist): %s", backup_path.name)
    except OSError as exc:
        raise SyncBackupError(
            f"Failed to create backup: {exc}",
            detail={"claude_md_path": str(claude_md_path), "backup_path": str(backup_path)},
        ) from exc

    return backup_path


def restore_from_backup(
    claude_md_path: Path,
    backup_path: Path,
) -> None:
    """
    Restore CLAUDE.md from a backup file.

    PRD §7: called in RESTORING state.

    Raises:
        SyncRestoreError: if restore fails.
    """
    if not backup_path.exists():
        raise SyncRestoreError(
            f"Backup file not found: {backup_path}",
            detail={"backup_path": str(backup_path)},
        )

    try:
        content = backup_path.read_text(encoding="utf-8")
        if content == "":
            # Empty marker → CLAUDE.md shouldn't exist
            if claude_md_path.exists():
                claude_md_path.unlink()
            logger.info("Restored: CLAUDE.md removed (was not present before sync)")
        else:
            claude_md_path.parent.mkdir(parents=True, exist_ok=True)
            claude_md_path.write_text(content, encoding="utf-8")
            logger.info("Restored CLAUDE.md from backup: %s", backup_path.name)
    except OSError as exc:
        raise SyncRestoreError(
            f"Restore failed: {exc}",
            detail={
                "claude_md_path": str(claude_md_path),
                "backup_path": str(backup_path),
            },
        ) from exc


def get_latest_backup(backup_dir: Path) -> Path | None:
    """Return the most recent backup file, or None if none exist."""
    if not backup_dir.exists():
        return None
    backups = sorted(
        backup_dir.glob(f"{BACKUP_FILENAME_PREFIX}*"),
        key=lambda p: p.name,
        reverse=True,
    )
    return backups[0] if backups else None


def cleanup_old_backups(backup_dir: Path, retention_days: int = 30) -> int:
    """
    Delete backup files older than retention_days.

    PRD §13 EC-F006: 30 days default retention.

    Returns:
        Number of backup files deleted.
    """
    if not backup_dir.exists():
        return 0

    cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
    deleted = 0

    for backup_file in backup_dir.glob(f"{BACKUP_FILENAME_PREFIX}*"):
        try:
            # Parse timestamp from filename
            ts_str = backup_file.name[len(BACKUP_FILENAME_PREFIX):]
            # Handle both ISO format variants
            ts_str = ts_str.replace("Z", "+00:00")
            file_dt = datetime.fromisoformat(ts_str)
            if file_dt.tzinfo is None:
                from datetime import timezone as _tz
                file_dt = file_dt.replace(tzinfo=_tz.utc)

            if file_dt < cutoff:
                backup_file.unlink()
                deleted += 1
                logger.debug("Deleted old backup: %s", backup_file.name)
        except (ValueError, OSError) as exc:
            logger.warning("Could not process backup file %s: %s", backup_file.name, exc)

    if deleted:
        logger.info("Cleanup: deleted %d backup(s) older than %d days", deleted, retention_days)

    return deleted


def list_backups(backup_dir: Path) -> list[Path]:
    """Return all backup files sorted newest-first."""
    if not backup_dir.exists():
        return []
    return sorted(
        backup_dir.glob(f"{BACKUP_FILENAME_PREFIX}*"),
        key=lambda p: p.name,
        reverse=True,
    )
