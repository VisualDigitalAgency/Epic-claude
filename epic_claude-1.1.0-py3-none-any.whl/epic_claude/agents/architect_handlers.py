"""
EC-F004 — Architect Agent MCP tool handlers.

Wires 4 tools into the global dispatch table:
  - architect_generate
  - architect_regenerate
  - artifact_get
  - artifact_list

Called once at server startup via register_architect_handlers().
"""

from __future__ import annotations

from typing import Any

import epic_claude.registry as reg_mod
from epic_claude.agents.architect import generate_architecture, get_artifact, list_artifacts
from epic_claude.exceptions import (
    Gate1ValidationError,
    Gate2ValidationError,
    StackNotConfirmedError,
)
from epic_claude.memory.database import bootstrap_memory_db
from epic_claude.server.logging import get_logger
from epic_claude.server.tools import register_handler

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# architect_generate
# ---------------------------------------------------------------------------

async def _handle_architect_generate(params: dict[str, Any]) -> dict[str, Any]:
    """
    Run Gate 1 checklist, generate all 5 artifacts, validate, write atomically.
    Blocked until stack_confirmed=True.

    Required: project_id
    """
    project_id = _require(params, "project_id")

    registry_db = reg_mod.REGISTRY_DB_PATH
    memory_db   = reg_mod.PROJECTS_DIR / project_id / "memory.db"
    bootstrap_memory_db(memory_db)

    try:
        result = await generate_architecture(
            project_id=project_id,
            registry_db_path=registry_db,
            memory_db_path=memory_db,
            projects_dir=reg_mod.PROJECTS_DIR,
        )
        return {"success": True, **result}

    except StackNotConfirmedError as exc:
        return {"success": False, "error": "stack_not_confirmed", "message": exc.message}
    except Gate1ValidationError as exc:
        return {"success": False, "error": "gate1_failed", "message": exc.message, "details": exc.errors}
    except Gate2ValidationError as exc:
        return {"success": False, "error": "gate2_failed", "message": exc.message, "details": exc.errors}


# ---------------------------------------------------------------------------
# architect_regenerate
# ---------------------------------------------------------------------------

async def _handle_architect_regenerate(params: dict[str, Any]) -> dict[str, Any]:
    """
    Regenerate all or a specific artifact type.

    Required: project_id
    Optional: scope (prd | api_spec | db_schema | tech_stack | boundaries)
    """
    project_id = _require(params, "project_id")
    scope      = params.get("scope")  # None = all 5

    registry_db = reg_mod.REGISTRY_DB_PATH
    memory_db   = reg_mod.PROJECTS_DIR / project_id / "memory.db"

    try:
        result = await generate_architecture(
            project_id=project_id,
            registry_db_path=registry_db,
            memory_db_path=memory_db,
            projects_dir=reg_mod.PROJECTS_DIR,
            scope=scope,
        )
        return {"success": True, "regenerated": True, **result}

    except (StackNotConfirmedError, Gate1ValidationError, Gate2ValidationError) as exc:
        return {"success": False, "error": type(exc).__name__, "message": exc.message}


# ---------------------------------------------------------------------------
# artifact_get
# ---------------------------------------------------------------------------

async def _handle_artifact_get(params: dict[str, Any]) -> dict[str, Any]:
    """
    Get a specific artifact by type.

    Required: project_id, type
    """
    project_id    = _require(params, "project_id")
    artifact_type = _require(params, "type")

    memory_db = reg_mod.PROJECTS_DIR / project_id / "memory.db"

    artifact = get_artifact(project_id, artifact_type, memory_db)
    if artifact is None:
        return {
            "success": False,
            "error": f"Artifact '{artifact_type}' not found for project {project_id}. "
                     "Run architect_generate first.",
        }

    return {"success": True, "artifact": artifact}


# ---------------------------------------------------------------------------
# artifact_list
# ---------------------------------------------------------------------------

async def _handle_artifact_list(params: dict[str, Any]) -> dict[str, Any]:
    """
    List all current artifacts for a project with validation status.

    Required: project_id
    """
    project_id = _require(params, "project_id")
    memory_db  = reg_mod.PROJECTS_DIR / project_id / "memory.db"

    artifacts = list_artifacts(project_id, memory_db)
    return {
        "success": True,
        "artifacts": artifacts,
        "count": len(artifacts),
    }


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register_architect_handlers() -> None:
    """
    Wire all EC-F004 tool handlers into the global MCP tool registry.
    Called once at server startup.
    """
    register_handler("architect_generate",   _handle_architect_generate)
    register_handler("architect_regenerate", _handle_architect_regenerate)
    register_handler("artifact_get",         _handle_artifact_get)
    register_handler("artifact_list",        _handle_artifact_list)
    logger.info("EC-F004 Architect Agent handlers registered (4 tools)")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _require(params: dict[str, Any], key: str) -> Any:
    val = params.get(key)
    if val is None:
        raise TypeError(f"Required parameter missing: '{key}'")
    return val
