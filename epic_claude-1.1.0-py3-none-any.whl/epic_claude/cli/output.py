"""
CLI output helpers — EC-F007.

Shared Rich console, JSON output mode, and the active project banner.

PRD §13 EC-F007:
  - Every command shows active project banner (suppressed only with --quiet --json)
  - --json outputs raw JSON, no Rich formatting
  - --quiet suppresses decorative output, keeps essential lines
"""

from __future__ import annotations

import json
import sys
from typing import Any

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    console     = Console()
    err_console = Console(stderr=True)
except ImportError:
    # Fallback when rich not installed (sandbox / CI without deps)
    class _FallbackConsole:
        def print(self, *args, **kwargs):
            import re
            text = " ".join(str(a) for a in args)
            text = re.sub(r"[[][^]]*[]]", "", text)  # strip Rich markup
            print(text)
    console     = _FallbackConsole()
    err_console = _FallbackConsole()

# JSON-mode flag — set by --json global option
_json_mode  = False
_quiet_mode = False


def set_json_mode(enabled: bool) -> None:
    global _json_mode
    _json_mode = enabled


def set_quiet_mode(enabled: bool) -> None:
    global _quiet_mode
    _quiet_mode = enabled


def is_json_mode() -> bool:
    return _json_mode


def is_quiet_mode() -> bool:
    return _quiet_mode


# ---------------------------------------------------------------------------
# Output primitives
# ---------------------------------------------------------------------------

def print_json(data: Any) -> None:
    """Print data as formatted JSON to stdout."""
    print(json.dumps(data, indent=2, default=str))


def print_success(message: str, data: Any = None) -> None:
    """Print a success message (Rich or JSON depending on mode)."""
    if _json_mode:
        print_json({"success": True, "message": message, **(data or {})})
    elif not _quiet_mode:
        console.print(f"[green]✓[/green] {message}")


def print_error(message: str, data: Any = None) -> None:
    """Print an error message."""
    if _json_mode:
        print_json({"success": False, "error": message, **(data or {})})
    else:
        err_console.print(f"[red]✗[/red] {message}")


def print_warning(message: str) -> None:
    if _json_mode:
        return
    if not _quiet_mode:
        console.print(f"[yellow]⚠[/yellow] {message}")


def print_info(message: str) -> None:
    if _json_mode or _quiet_mode:
        return
    console.print(f"[dim]{message}[/dim]")


# ---------------------------------------------------------------------------
# Active project banner (PRD §5)
# ---------------------------------------------------------------------------

def print_project_banner(
    name: str,
    root_path: str,
    stack_status: str,
    arch_status: str,
    sync_ago: str,
) -> None:
    """
    Print the active project banner.

    PRD §5 format:
    ┌─────────────────────────────────────────────────────────┐
    │  ● SaaS Invoicing App                                   │
    │    /Users/dev/projects/invoicing-app                    │
    │    Stack: confirmed  ·  Arch: generated  ·  Sync: 4m ago│
    └─────────────────────────────────────────────────────────┘

    Suppressed when --quiet --json both set.
    """
    if _json_mode and _quiet_mode:
        return
    if _json_mode:
        return  # never print banner in JSON mode

    content = (
        f"  [bold green]●[/bold green] {name}\n"
        f"    [dim]{root_path}[/dim]\n"
        f"    Stack: [cyan]{stack_status}[/cyan]  ·  "
        f"Arch: [cyan]{arch_status}[/cyan]  ·  "
        f"Sync: [cyan]{sync_ago}[/cyan]"
    )
    console.print(Panel(content, border_style="dim blue", padding=(0, 1)))


def maybe_print_banner(project_id: str | None) -> None:
    """
    Attempt to load and print the active project banner.
    Silently skips if project not found or registry not initialised.
    """
    if _json_mode and _quiet_mode:
        return
    if _json_mode:
        return
    if project_id is None:
        return

    try:
        import epic_claude.registry as reg_mod
        from epic_claude.memory.registry_store import RegistryStore
        from epic_claude.memory.database import db_exists

        registry_db = reg_mod.REGISTRY_DB_PATH
        if not db_exists(registry_db):
            return

        rs = RegistryStore(registry_db)
        rs.open()
        try:
            project = rs.get_by_id(project_id)
            if not project:
                return
        finally:
            rs.close()

        stack_status = "confirmed" if project.stack_confirmed else "pending"
        arch_status  = "generated" if project.architect_generated else "pending"

        from epic_claude.sync.state_machine import get_last_sync
        from epic_claude.memory.database import bootstrap_memory_db
        memory_db = reg_mod.PROJECTS_DIR / project_id / "memory.db"
        if not db_exists(memory_db):
            sync_ago = "never"
        else:
            last = get_last_sync(project_id, memory_db)
            sync_ago = _format_time_ago(last["synced_at"]) if last else "never"

        print_project_banner(
            name=project.name,
            root_path=project.root_path,
            stack_status=stack_status,
            arch_status=arch_status,
            sync_ago=sync_ago,
        )
    except Exception:
        pass  # Never let banner failure crash a command


def _format_time_ago(iso_timestamp: str) -> str:
    """Format an ISO 8601 timestamp as a human-friendly 'Xm ago' string."""
    try:
        from datetime import datetime, timezone
        dt = datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        delta = datetime.now(timezone.utc) - dt
        seconds = int(delta.total_seconds())
        if seconds < 60:   return f"{seconds}s ago"
        if seconds < 3600: return f"{seconds // 60}m ago"
        if seconds < 86400:return f"{seconds // 3600}h ago"
        return f"{seconds // 86400}d ago"
    except Exception:
        return "unknown"


# ---------------------------------------------------------------------------
# No-project-found guidance (P0 fix — strict detection UX)
# ---------------------------------------------------------------------------

NO_PROJECT_MESSAGE = """[bold yellow]No EPIC-Claude project found in this directory.[/bold yellow]

Start here:
  [cyan]epic-claude init[/cyan]           → initialise global registry
  [cyan]epic-claude plan "<desc>"[/cyan]  → start a new project

Or switch to an existing project:
  [cyan]epic-claude projects list[/cyan]
  [cyan]epic-claude projects switch[/cyan]
"""


def print_no_project_found(cwd: str | None = None) -> None:
    """
    Print a clear, actionable message when no project is detected.
    Called by any CLI command that requires an active project.
    """
    if _json_mode:
        print_json({
            "error": "no_project_found",
            "cwd": cwd,
            "message": "No EPIC-Claude project found. Run epic-claude init then epic-claude plan.",
            "next_steps": ["epic-claude init", 'epic-claude plan "<description>"'],
        })
        return

    if not _quiet_mode:
        import re as _re
        msg = NO_PROJECT_MESSAGE
        if cwd:
            msg = f"[dim]Directory: {cwd}[/dim]\n\n" + msg
        console.print(msg)
