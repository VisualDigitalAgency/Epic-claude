# Contributing to EPIC-Claude

Thank you for contributing. Please read this guide before opening a PR.

---

## Non-Negotiable Rules

### 1. Namespace Rule (PRD §21 — Blocking PR failure)

| Namespace | Scope | Example |
|---|---|---|
| `EC-F001` | EPIC-Claude platform features | This codebase |
| `F001` | Features in a **user's** generated project PRD | Output only |

**These two namespaces must never be mixed** in code, documentation, CLI output, or GitHub issues. Mixing them is a **blocking PR review failure** with no exceptions.

### 2. Validate Before Write

Every artifact write path must pass through all three validation gates. No bypasses.

### 3. No Silent Failures

Every error must be logged to `server.log` and returned as a structured JSON-RPC 2.0 error. Never swallow exceptions silently.

### 4. No Credentials in Config

`config.json` must never contain API keys, secrets, or tokens. API keys come from environment variables only. This is enforced by a Pydantic validator — do not remove it.

---

## Branch Naming

```
feature/EC-FXXX-short-description
fix/EC-FXXX-short-description
docs/EC-FXXX-short-description
test/EC-FXXX-short-description
```

Examples:
```
feature/EC-F001-mcp-server-core
feature/EC-F002-clarification-agent
fix/EC-F005-memory-fts-index
```

---

## PR Requirements

Every PR must include:
1. Implementation
2. Tests (unit + integration where appropriate)
3. Updated docstrings
4. PR title references the `EC-F` feature ID

---

## Development Setup

```bash
# Clone
git clone https://github.com/epic-claude/epic-claude
cd epic-claude

# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# Install all dependencies including dev
uv sync --all-extras

# Set API key for integration tests
export ANTHROPIC_API_KEY=your-key-here

# Run tests
uv run pytest

# Lint
uv run ruff check epic_claude tests

# Format
uv run ruff format epic_claude tests

# Type check
uv run mypy epic_claude
```

---

## Versioning

| Bump | Trigger |
|---|---|
| MAJOR | Breaking MCP tool signature change |
| MINOR | New MCP tool, new CLI command, new project type |
| PATCH | Bug fix, dependency update, doc correction |

---

## Supported Platforms

- macOS 13+
- Ubuntu 22.04+
- Windows 11 WSL2

---

## Questions

Open an issue tagged with the relevant `EC-F` ID.
