"""
Gate 1 — Pre-Generation Checklist.

Runs before the Architect Agent generates anything.
Six checkpoints must be satisfied (or assumed with confidence=low).
If Checkpoint 1 (project_type) is unknown → hard block.
All others can be assumed.

PRD §8 — Architect Agent Pre-Generation Checklist.
PRD §6 — Gate 1.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from epic_claude.constants import Confidence, ProjectType, SUPPORTED_PROJECT_TYPES
from epic_claude.exceptions import Gate1ValidationError
from epic_claude.memory.database import open_db, transaction
from epic_claude.server.logging import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Checkpoint result
# ---------------------------------------------------------------------------

@dataclass
class CheckpointResult:
    number: int
    name: str
    value: Any
    confidence: str          # high | medium | low | unknown
    assumption_text: str | None = None
    satisfied: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "number": self.number,
            "name": self.name,
            "value": self.value,
            "confidence": self.confidence,
            "assumption_text": self.assumption_text,
            "satisfied": self.satisfied,
        }


@dataclass
class ChecklistResult:
    project_id: str
    all_passed: bool
    blocked_reason: str | None
    checkpoints: list[CheckpointResult] = field(default_factory=list)
    assumptions_made: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "project_id": self.project_id,
            "all_passed": self.all_passed,
            "blocked_reason": self.blocked_reason,
            "checkpoints": [c.to_dict() for c in self.checkpoints],
            "assumptions_made": self.assumptions_made,
        }


# ---------------------------------------------------------------------------
# Gate 1 runner
# ---------------------------------------------------------------------------

def run_gate1(
    project_id: str,
    project_type: str | None,
    answers: dict[str, Any],
    assumptions: list[dict[str, Any]],
    stack: dict[str, Any],
    memory_db_path: Path,
) -> ChecklistResult:
    """
    Run the 6 pre-generation checkpoints.

    PRD §8 checkpoints:
      1. Project type confirmed (BLOCK if unknown)
      2. Deployment target (assume if unknown)
      3. Auth model (infer from type if unknown)
      4. Scale assumptions (assume if unknown)
      5. Multi-tenancy required (infer from SaaS type)
      6. Data ownership rules (infer from type + stack)

    Args:
        project_id:    Project UUID.
        project_type:  From registry (backend_saas / rest_api / fullstack_web).
        answers:       Clarification answers dict.
        assumptions:   Low-confidence assumptions from clarification.
        stack:         Confirmed tech stack dict.
        memory_db_path: Path to memory.db for persistence.

    Returns:
        ChecklistResult — if all_passed=False, raise Gate1ValidationError.

    Raises:
        Gate1ValidationError: if Checkpoint 1 fails (unknown project type).
    """
    checkpoints: list[CheckpointResult] = []
    new_assumptions: list[dict[str, Any]] = []

    # ------------------------------------------------------------------
    # Checkpoint 1: Project type (HARD BLOCK if unknown/unsupported)
    # ------------------------------------------------------------------
    pt = project_type or answers.get("project_type")
    if not pt or pt not in SUPPORTED_PROJECT_TYPES:
        cp1 = CheckpointResult(
            number=1,
            name="project_type",
            value=pt,
            confidence=Confidence.UNKNOWN,
            satisfied=False,
        )
        checkpoints.append(cp1)
        result = ChecklistResult(
            project_id=project_id,
            all_passed=False,
            blocked_reason=(
                f"Project type unknown or unsupported: {pt!r}. "
                f"Must be one of: {sorted(SUPPORTED_PROJECT_TYPES)}"
            ),
            checkpoints=checkpoints,
        )
        _persist(result, memory_db_path)
        raise Gate1ValidationError(
            message=result.blocked_reason,
            artifact_type="checklist",
            errors=[result.blocked_reason],
        )

    checkpoints.append(CheckpointResult(1, "project_type", pt, Confidence.HIGH))

    # ------------------------------------------------------------------
    # Checkpoint 2: Deployment target
    # ------------------------------------------------------------------
    deployment = (
        answers.get("deployment")
        or _stack_value(stack, "deployment")
        or _find_assumption(assumptions, "deployment")
    )
    if not deployment:
        deployment = _default_deployment(pt)
        new_assumptions.append(_make_assumption(
            "deployment", deployment,
            "Assumed: Railway (low-cost default) — revise if different",
            "Affects infrastructure section of each feature",
        ))
        checkpoints.append(CheckpointResult(2, "deployment_target", deployment, Confidence.LOW,
                                            assumption_text=f"Assumed: {deployment}"))
    else:
        checkpoints.append(CheckpointResult(2, "deployment_target", deployment, Confidence.HIGH))

    # ------------------------------------------------------------------
    # Checkpoint 3: Auth model
    # ------------------------------------------------------------------
    auth = (
        answers.get("auth")
        or _stack_value(stack, "auth")
        or _find_assumption(assumptions, "auth")
        or _infer_auth(pt)
    )
    conf = Confidence.HIGH if answers.get("auth") or _stack_value(stack, "auth") else Confidence.LOW
    if conf == Confidence.LOW:
        new_assumptions.append(_make_assumption(
            "auth", auth,
            f"Assumed: {auth} (inferred from project type)",
            "Affects auth feature design and API security",
        ))
    checkpoints.append(CheckpointResult(3, "auth_model", auth, conf,
                                        assumption_text=f"Assumed: {auth}" if conf == Confidence.LOW else None))

    # ------------------------------------------------------------------
    # Checkpoint 4: Scale assumptions
    # ------------------------------------------------------------------
    scale = answers.get("scale") or _find_assumption(assumptions, "scale")
    if not scale:
        scale = "< 10k users at launch"
        new_assumptions.append(_make_assumption(
            "scale", scale,
            "Assumed: < 10k users at launch — revise if scale is higher",
            "Affects DB indexing and caching decisions",
        ))
        checkpoints.append(CheckpointResult(4, "scale_assumptions", scale, Confidence.LOW,
                                            assumption_text="Assumed: < 10k users"))
    else:
        checkpoints.append(CheckpointResult(4, "scale_assumptions", scale, Confidence.HIGH))

    # ------------------------------------------------------------------
    # Checkpoint 5: Multi-tenancy
    # ------------------------------------------------------------------
    multi_tenancy_raw = answers.get("multi_tenancy") or answers.get("multi_tenancy_required")
    if multi_tenancy_raw is None:
        # Infer from project type
        multi_tenancy = pt == ProjectType.BACKEND_SAAS
        new_assumptions.append(_make_assumption(
            "multi_tenancy",
            str(multi_tenancy),
            f"Assumed: multi_tenancy={multi_tenancy} (inferred from {pt})",
            "Affects tenant_id FK on all user-owned tables",
        ))
        checkpoints.append(CheckpointResult(5, "multi_tenancy", multi_tenancy, Confidence.LOW,
                                            assumption_text=f"Inferred from {pt}"))
    else:
        multi_tenancy = bool(multi_tenancy_raw)
        checkpoints.append(CheckpointResult(5, "multi_tenancy", multi_tenancy, Confidence.HIGH))

    # ------------------------------------------------------------------
    # Checkpoint 6: Data ownership rules
    # ------------------------------------------------------------------
    data_ownership = _infer_data_ownership(pt, multi_tenancy, stack)
    checkpoints.append(CheckpointResult(6, "data_ownership_rules", data_ownership, Confidence.LOW,
                                        assumption_text="Inferred from project type and stack"))
    new_assumptions.append(_make_assumption(
        "data_ownership", data_ownership,
        f"Inferred: {data_ownership}",
        "Affects service boundary design",
    ))

    # ------------------------------------------------------------------
    # All checkpoints done — build result
    # ------------------------------------------------------------------
    result = ChecklistResult(
        project_id=project_id,
        all_passed=True,
        blocked_reason=None,
        checkpoints=checkpoints,
        assumptions_made=new_assumptions,
    )
    _persist(result, memory_db_path)

    logger.info(
        "Gate 1 PASSED | project=%s | assumptions=%d",
        project_id, len(new_assumptions),
    )
    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _stack_value(stack: dict[str, Any], category: str) -> str | None:
    entry = stack.get(category, {})
    return entry.get("name") if isinstance(entry, dict) else None


def _find_assumption(assumptions: list[dict], key: str) -> str | None:
    for a in assumptions:
        if a.get("key") == key:
            return a.get("assumed_value")
    return None


def _default_deployment(project_type: str) -> str:
    return "Railway"


def _infer_auth(project_type: str) -> str:
    return {
        ProjectType.BACKEND_SAAS:  "JWT + bcrypt",
        ProjectType.REST_API:      "API key or JWT",
        ProjectType.FULLSTACK_WEB: "JWT + bcrypt",
    }.get(project_type, "JWT")


def _infer_data_ownership(
    project_type: str,
    multi_tenancy: bool,
    stack: dict[str, Any],
) -> str:
    if multi_tenancy:
        return "tenant_id FK on all user-owned tables; each tenant owns their data"
    return "single-tenant; user-scoped data via user_id FK"


def _make_assumption(
    key: str,
    value: str,
    text: str,
    impact: str,
) -> dict[str, Any]:
    return {
        "key": key,
        "assumed_value": value,
        "confidence": Confidence.LOW,
        "assumption_text": text,
        "impact": impact,
    }


def _persist(result: ChecklistResult, db_path: Path) -> None:
    """Write checklist result to checklist_results table."""
    try:
        conn = open_db(db_path)
        now = datetime.now(timezone.utc).isoformat()
        cp = result.checkpoints
        # index checkpoints by name for storage
        cp_map = {c.name: c for c in cp}

        with transaction(conn, str(db_path)):
            conn.execute(
                """
                INSERT INTO checklist_results (
                    id, project_id, run_at,
                    project_type, deployment_target, auth_model,
                    scale_assumption, multi_tenancy, data_ownership,
                    assumptions_made, all_passed, blocked_reason
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    str(uuid.uuid4()),
                    result.project_id,
                    now,
                    cp_map.get("project_type", CheckpointResult(1,"",None,Confidence.UNKNOWN)).value,
                    cp_map.get("deployment_target", CheckpointResult(2,"",None,Confidence.UNKNOWN)).value,
                    cp_map.get("auth_model", CheckpointResult(3,"",None,Confidence.UNKNOWN)).value,
                    cp_map.get("scale_assumptions", CheckpointResult(4,"",None,Confidence.UNKNOWN)).value,
                    1 if cp_map.get("multi_tenancy", CheckpointResult(5,"",False,Confidence.UNKNOWN)).value else 0,
                    str(cp_map.get("data_ownership_rules", CheckpointResult(6,"",None,Confidence.UNKNOWN)).value),
                    json.dumps(result.assumptions_made),
                    1 if result.all_passed else 0,
                    result.blocked_reason,
                ),
            )
        conn.close()
    except Exception as exc:
        logger.error("Failed to persist checklist result: %s", exc)
