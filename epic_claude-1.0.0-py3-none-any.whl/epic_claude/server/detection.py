"""
Project Detection Protocol — EC-F001.

High-trust operation: detecting the wrong project means writing architecture
into the wrong codebase. The algorithm is explicit, validated, and never silent.

PRD §5 — Detection Algorithm:
  1. Receive CWD
  2. Walk up directory tree looking for .epic-claude/project.json OR registry match
  3. Validate found project (5 checks)
  4. Detect ambiguity triggers
  5. Always prompt user to confirm — never proceed silently
  6. Block on cancel or not-found — no silent fallback

PRD §5 — Ambiguity triggers:
  - CWD is a symlink
  - CWD is a Git worktree
  - Nested project.json at multiple levels
  - Stale registry entry (path moved)
  - --project-id override flag
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any

from epic_claude.server.logging import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Detection result types
# ---------------------------------------------------------------------------

class DetectionStatus(StrEnum):
    FOUND          = "found"        # Clean match, ready to confirm
    FOUND_AMBIGUOUS = "found_ambiguous"  # Match but ambiguity triggers present
    NOT_FOUND      = "not_found"    # No project in CWD or any parent


@dataclass
class DetectedProject:
    """Result of a successful project detection walk."""
    project_id: str
    name: str
    root_path: Path
    status: DetectionStatus
    ambiguity_reasons: list[str]      # Human-readable reasons for ambiguity
    project_json: dict[str, Any]      # Raw project.json contents


@dataclass
class DetectionResult:
    """
    Full result of the Project Detection Protocol.
    Always returned — caller decides how to handle each status.
    """
    status: DetectionStatus
    project: DetectedProject | None   # None when NOT_FOUND
    cwd: Path
    override_project_id: str | None   # Set when --project-id flag used


# ---------------------------------------------------------------------------
# Validation result
# ---------------------------------------------------------------------------

@dataclass
class ProjectValidation:
    is_valid: bool
    failures: list[str]  # Human-readable failure descriptions


# ---------------------------------------------------------------------------
# Core detection logic
# ---------------------------------------------------------------------------

def detect_project(
    cwd: Path,
    registry_projects_dir: Path,
    override_project_id: str | None = None,
) -> DetectionResult:
    """
    Run the full Project Detection Protocol for a given working directory.

    Args:
        cwd:                    The directory to detect from (usually Claude Code CWD)
        registry_projects_dir:  ~/.epic-claude/projects/
        override_project_id:    Explicit --project-id override (always flagged as ambiguous)

    Returns:
        DetectionResult — caller must inspect status and act accordingly.
        This function never raises — all errors are captured in the result.
    """
    logger.info("Project detection started | cwd=%s | override=%s", cwd, override_project_id)

    # ------------------------------------------------------------------
    # Override path — load directly, flag as ambiguous (always shown)
    # ------------------------------------------------------------------
    if override_project_id:
        project = _load_project_by_id(override_project_id, registry_projects_dir)
        if project is None:
            logger.warning("Override project_id not found: %s", override_project_id)
            return DetectionResult(
                status=DetectionStatus.NOT_FOUND,
                project=None,
                cwd=cwd,
                override_project_id=override_project_id,
            )
        project.ambiguity_reasons.append(
            f"--project-id override used ({override_project_id})"
        )
        project.status = DetectionStatus.FOUND_AMBIGUOUS
        logger.info("Override project loaded: %s", override_project_id)
        return DetectionResult(
            status=DetectionStatus.FOUND_AMBIGUOUS,
            project=project,
            cwd=cwd,
            override_project_id=override_project_id,
        )

    # ------------------------------------------------------------------
    # Walk up from CWD looking for project.json
    # ------------------------------------------------------------------
    found_path = _walk_to_find_project_json(cwd)

    if found_path is None:
        # Fall back to registry scan by root_path
        found_path = _find_project_by_registry_scan(cwd, registry_projects_dir)

    if found_path is None:
        logger.info("No project found for cwd=%s", cwd)
        return DetectionResult(
            status=DetectionStatus.NOT_FOUND,
            project=None,
            cwd=cwd,
            override_project_id=None,
        )

    # ------------------------------------------------------------------
    # Load + validate the found project
    # ------------------------------------------------------------------
    project_json_path = found_path / ".epic-claude" / "project.json"

    try:
        project_data = json.loads(project_json_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        logger.error("Failed to read project.json at %s: %s", project_json_path, exc)
        return DetectionResult(
            status=DetectionStatus.NOT_FOUND,
            project=None,
            cwd=cwd,
            override_project_id=None,
        )

    project_id = project_data.get("id", "")
    name       = project_data.get("name", "Unknown Project")
    root_path  = Path(project_data.get("root_path", str(found_path)))

    # ------------------------------------------------------------------
    # Validate the project (5 checks from PRD §5)
    # ------------------------------------------------------------------
    validation = validate_project(
        project_id=project_id,
        root_path=root_path,
        registry_projects_dir=registry_projects_dir,
    )

    if not validation.is_valid:
        logger.warning(
            "Project validation failed for %s: %s",
            project_id, validation.failures,
        )
        return DetectionResult(
            status=DetectionStatus.NOT_FOUND,
            project=None,
            cwd=cwd,
            override_project_id=None,
        )

    # ------------------------------------------------------------------
    # Detect ambiguity triggers (PRD §5)
    # ------------------------------------------------------------------
    ambiguity_reasons = _detect_ambiguity(cwd, root_path, registry_projects_dir)

    status = (
        DetectionStatus.FOUND_AMBIGUOUS
        if ambiguity_reasons
        else DetectionStatus.FOUND
    )

    project = DetectedProject(
        project_id=project_id,
        name=name,
        root_path=root_path,
        status=status,
        ambiguity_reasons=ambiguity_reasons,
        project_json=project_data,
    )

    logger.info(
        "Project detected: %s | status=%s | ambiguity=%s",
        project_id, status, ambiguity_reasons,
    )

    return DetectionResult(
        status=status,
        project=project,
        cwd=cwd,
        override_project_id=None,
    )


# ---------------------------------------------------------------------------
# Validation (PRD §5 — 5 checks)
# ---------------------------------------------------------------------------

def validate_project(
    project_id: str,
    root_path: Path,
    registry_projects_dir: Path,
) -> ProjectValidation:
    """
    Validate a detected project against 5 PRD §5 criteria.

    1. root_path exists on disk
    2. memory.db accessible
    3. project.json readable
    4. No symlink ambiguity on root_path itself
    5. No nested project conflict
    """
    failures: list[str] = []

    # 1. root_path must exist
    if not root_path.exists():
        failures.append(f"root_path does not exist on disk: {root_path}")

    # 2. memory.db must be accessible
    memory_db = registry_projects_dir / project_id / "memory.db"
    if not memory_db.parent.exists():
        failures.append(f"Project directory missing in registry: {memory_db.parent}")

    # 3. project.json must be readable (already loaded by caller, but double-check)
    project_json = registry_projects_dir / project_id / "project.json"
    if not project_json.exists():
        failures.append(f"project.json missing from registry: {project_json}")

    # 4. Symlink check — root_path itself should not be a symlink
    # (symlinks are flagged as ambiguous but not invalid — only fail if broken)
    if root_path.is_symlink() and not root_path.exists():
        failures.append(f"root_path is a broken symlink: {root_path}")

    # 5. Nested conflict — check if any parent of root_path is ALSO a project root
    #    (detected by presence of another .epic-claude/project.json higher up)
    if root_path.exists():
        parent = root_path.parent
        while parent != parent.parent:  # stop at filesystem root
            candidate = parent / ".epic-claude" / "project.json"
            if candidate.exists():
                failures.append(
                    f"Nested project conflict: parent directory {parent} "
                    f"also contains a project.json"
                )
                break
            parent = parent.parent

    return ProjectValidation(is_valid=len(failures) == 0, failures=failures)


# ---------------------------------------------------------------------------
# Ambiguity detection (PRD §5)
# ---------------------------------------------------------------------------

def _detect_ambiguity(
    cwd: Path,
    root_path: Path,
    registry_projects_dir: Path,
) -> list[str]:
    """
    Return a list of human-readable ambiguity reasons.
    Empty list = clean match, no ambiguity.
    """
    reasons: list[str] = []

    # CWD is a symlink
    if cwd.is_symlink():
        reasons.append(
            f"CWD is a symlink ({cwd} → {os.readlink(cwd)}). "
            "Real path may differ from registry path."
        )

    # root_path is a symlink
    if root_path.is_symlink():
        reasons.append(
            f"Project root is a symlink ({root_path}). "
            "Real path may differ from registry path."
        )

    # Git worktree detection
    git_dir = root_path / ".git"
    if git_dir.is_file():  # .git as a file = worktree
        try:
            content = git_dir.read_text(encoding="utf-8")
            if "gitdir:" in content:
                reasons.append(
                    "CWD appears to be a Git worktree (.git is a file, not a directory). "
                    "Different worktrees share a repo but are distinct contexts."
                )
        except OSError:
            pass

    # Multiple project.json at different levels
    nested_count = _count_project_json_in_ancestors(cwd)
    if nested_count > 1:
        reasons.append(
            f"Multiple project.json files found in ancestor directories ({nested_count}). "
            "Two registered projects may overlap."
        )

    return reasons


def _count_project_json_in_ancestors(cwd: Path) -> int:
    """Count how many .epic-claude/project.json files exist in cwd and its parents."""
    count = 0
    current = cwd
    while current != current.parent:
        if (current / ".epic-claude" / "project.json").exists():
            count += 1
        current = current.parent
    return count


# ---------------------------------------------------------------------------
# Tree walk helpers
# ---------------------------------------------------------------------------

def _walk_to_find_project_json(cwd: Path) -> Path | None:
    """
    Walk up from cwd looking for a directory that contains .epic-claude/project.json.
    Returns the directory path (project root), or None.
    """
    current = cwd.resolve()
    while current != current.parent:
        candidate = current / ".epic-claude" / "project.json"
        if candidate.is_file():
            logger.debug("Found project.json at: %s", candidate)
            return current
        current = current.parent
    return None


def _find_project_by_registry_scan(
    cwd: Path,
    registry_projects_dir: Path,
) -> Path | None:
    """
    Fallback: scan registry for a project whose root_path is a prefix of cwd.
    Used when project.json hasn't been written to the project root yet.
    """
    if not registry_projects_dir.exists():
        return None

    cwd_resolved = cwd.resolve()

    for project_dir in registry_projects_dir.iterdir():
        project_json_path = project_dir / "project.json"
        if not project_json_path.is_file():
            continue
        try:
            data = json.loads(project_json_path.read_text(encoding="utf-8"))
            root_path = Path(data.get("root_path", "")).resolve()
            if root_path and (
                cwd_resolved == root_path
                or str(cwd_resolved).startswith(str(root_path) + os.sep)
            ):
                logger.debug(
                    "Found project via registry scan: %s (root_path=%s)",
                    project_dir.name, root_path,
                )
                return root_path
        except (OSError, json.JSONDecodeError):
            continue

    return None


def _load_project_by_id(
    project_id: str,
    registry_projects_dir: Path,
) -> DetectedProject | None:
    """Load a project directly by its ID from the registry."""
    project_json_path = registry_projects_dir / project_id / "project.json"
    if not project_json_path.is_file():
        return None
    try:
        data = json.loads(project_json_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        logger.error("Failed to read project.json for %s: %s", project_id, exc)
        return None

    return DetectedProject(
        project_id=project_id,
        name=data.get("name", "Unknown Project"),
        root_path=Path(data.get("root_path", "")),
        status=DetectionStatus.FOUND,
        ambiguity_reasons=[],
        project_json=data,
    )


# ---------------------------------------------------------------------------
# Banner formatting (PRD §5 — Active Project Banner)
# ---------------------------------------------------------------------------

def format_project_banner(project: DetectedProject, sync_ago: str = "never") -> str:
    """
    Return the active project banner string (Rich markup).

    PRD §5 exact format:
    ┌─────────────────────────────────────────────────────────┐
    │  ● SaaS Invoicing App                                   │
    │    /Users/dev/projects/invoicing-app                    │
    │    Stack: confirmed  ·  Arch: generated  ·  Sync: 4m ago│
    └─────────────────────────────────────────────────────────┘
    """
    pj = project.project_json
    stack_status = "confirmed" if pj.get("stack_confirmed") else "pending"
    arch_status  = "generated" if pj.get("architect_generated") else "pending"

    name_line  = f"  [bold green]●[/bold green] {project.name}"
    path_line  = f"    [dim]{project.root_path}[/dim]"
    state_line = (
        f"    Stack: [cyan]{stack_status}[/cyan]  ·  "
        f"Arch: [cyan]{arch_status}[/cyan]  ·  "
        f"Sync: [cyan]{sync_ago}[/cyan]"
    )

    return f"{name_line}\n{path_line}\n{state_line}"
