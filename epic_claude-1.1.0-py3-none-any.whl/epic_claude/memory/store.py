"""
EC-F005 — Memory Bank store.

All read/write operations against memory.db.
This is the product moat: every architectural decision, constraint,
assumption, and reasoning is persisted here and survives across sessions.

PRD §13 EC-F005 acceptance criteria:
  ✓ memory_write  — stores entry with confidence level
  ✓ memory_recall — FTS5 full-text search + composable filters
  ✓ memory_list   — paginated listing with filters
  ✓ memory_supersede — marks entry superseded, never deletes
  ✓ FTS5 across title, content, tags
  ✓ tag + text + type + importance + confidence filters composable
  ✓ Session ID auto-attached when active session exists
  ✓ All writes inside SQLite transactions
  ✓ Superseded entries preserved for audit trail
  ✓ memory_recall < 100ms (PRD §18 perf target)
"""

from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from epic_claude.constants import (
    Confidence,
    Importance,
    MemoryEntryType,
)
from epic_claude.exceptions import MemoryEntryNotFoundError
from epic_claude.memory.database import (
    bootstrap_memory_db,
    db_exists,
    open_db,
    read_only,
    transaction,
)
from epic_claude.server.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Data transfer objects
# ---------------------------------------------------------------------------

@dataclass
class MemoryEntry:
    """A single memory entry as returned from the store."""
    id: str
    project_id: str
    entry_type: str
    title: str
    content: str
    tags: list[str]
    importance: str
    confidence: str
    source: str
    is_superseded: bool
    superseded_by: str | None
    superseded_at: str | None
    supersede_reason: str | None
    session_id: str | None
    feature_id: str | None
    created_at: str
    updated_at: str

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> "MemoryEntry":
        tags_raw = row["tags"]
        tags = json.loads(tags_raw) if tags_raw else []
        return cls(
            id=row["id"],
            project_id=row["project_id"],
            entry_type=row["entry_type"],
            title=row["title"],
            content=row["content"],
            tags=tags,
            importance=row["importance"],
            confidence=row["confidence"],
            source=row["source"],
            is_superseded=bool(row["is_superseded"]),
            superseded_by=row["superseded_by"],
            superseded_at=row["superseded_at"],
            supersede_reason=row["supersede_reason"],
            session_id=row["session_id"],
            feature_id=row["feature_id"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "project_id": self.project_id,
            "entry_type": self.entry_type,
            "title": self.title,
            "content": self.content,
            "tags": self.tags,
            "importance": self.importance,
            "confidence": self.confidence,
            "source": self.source,
            "is_superseded": self.is_superseded,
            "superseded_by": self.superseded_by,
            "superseded_at": self.superseded_at,
            "supersede_reason": self.supersede_reason,
            "session_id": self.session_id,
            "feature_id": self.feature_id,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


@dataclass
class WriteRequest:
    """Input for memory_write."""
    project_id: str
    entry_type: str
    title: str
    content: str
    tags: list[str] = field(default_factory=list)
    importance: str = Importance.NORMAL
    confidence: str = Confidence.HIGH
    source: str = "agent"
    session_id: str | None = None
    feature_id: str | None = None


@dataclass
class RecallRequest:
    """Input for memory_recall — all filters optional."""
    project_id: str
    query: str | None = None           # FTS full-text query
    tags: list[str] = field(default_factory=list)  # OR logic
    entry_type: str | None = None
    importance: str | None = None
    confidence: str | None = None
    include_superseded: bool = False
    limit: int = 20


@dataclass
class ListRequest:
    """Input for memory_list."""
    project_id: str
    entry_type: str | None = None
    limit: int = 50
    offset: int = 0
    include_superseded: bool = False


# ---------------------------------------------------------------------------
# Memory Bank Store
# ---------------------------------------------------------------------------

class MemoryStore:
    """
    All Memory Bank read/write operations for a single project's memory.db.

    Thread safety:
        - Reads use WAL concurrent reads (no lock)
        - Writes use the per-db application-level lock via transaction()
    """

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self._conn: sqlite3.Connection | None = None

    # -----------------------------------------------------------------------
    # Connection lifecycle
    # -----------------------------------------------------------------------

    def open(self) -> None:
        """Open DB connection, bootstrapping schema if needed."""
        if not db_exists(self.db_path):
            logger.info("Bootstrapping memory.db: %s", self.db_path)
            bootstrap_memory_db(self.db_path)
        self._conn = open_db(self.db_path)
        logger.debug("MemoryStore opened: %s", self.db_path)

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("MemoryStore not opened. Call open() first.")
        return self._conn

    # -----------------------------------------------------------------------
    # memory_write — PRD §13 EC-F005
    # -----------------------------------------------------------------------

    def write(self, req: WriteRequest) -> MemoryEntry:
        """
        Store a new memory entry inside a transaction.

        PRD AC:
          - stores entry with confidence level
          - session_id auto-attached when provided
          - all writes inside SQLite transactions
        """
        _validate_write_request(req)

        entry_id = str(uuid.uuid4())
        now = _utcnow()
        tags_json = json.dumps(req.tags) if req.tags else None

        with transaction(self.conn, str(self.db_path)):
            self.conn.execute(
                """
                INSERT INTO memory_entries (
                    id, project_id, feature_id, session_id,
                    entry_type, title, content, tags,
                    importance, confidence, source,
                    is_superseded, created_at, updated_at
                ) VALUES (
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?,
                    0, ?, ?
                )
                """,
                (
                    entry_id, req.project_id, req.feature_id, req.session_id,
                    req.entry_type, req.title, req.content, tags_json,
                    req.importance, req.confidence, req.source,
                    now, now,
                ),
            )

            # Increment session entries_written counter if session_id provided
            if req.session_id:
                self.conn.execute(
                    "UPDATE sessions SET entries_written = entries_written + 1 WHERE id = ?",
                    (req.session_id,),
                )

        logger.info(
            "memory_write: %s | type=%s | id=%s",
            req.title[:60], req.entry_type, entry_id,
        )

        return self.get_by_id(entry_id)

    # -----------------------------------------------------------------------
    # memory_recall — FTS5 + composable filters — PRD §13 EC-F005
    # -----------------------------------------------------------------------

    def recall(self, req: RecallRequest) -> list[MemoryEntry]:
        """
        Query memory using FTS5 full-text search and/or column filters.
        All filters are composable. FTS search uses SQLite FTS5 MATCH.

        PRD AC:
          - FTS5 across title, content, tags
          - tag + text + type + importance + confidence composable
          - memory_recall < 100ms (PRD §18)
        """
        with read_only(self.conn):
            if req.query:
                rows = self._recall_with_fts(req)
            else:
                rows = self._recall_without_fts(req)

        entries = [MemoryEntry.from_row(r) for r in rows]
        logger.debug(
            "memory_recall: project=%s query=%r → %d results",
            req.project_id, req.query, len(entries),
        )
        return entries

    def _recall_with_fts(self, req: RecallRequest) -> list[sqlite3.Row]:
        """FTS5 MATCH query joined with column filters."""
        conditions = [
            "m.project_id = ?",
            "fts.memory_fts MATCH ?",
        ]
        params: list[Any] = [req.project_id, req.query]

        conditions, params = _apply_filters(conditions, params, req)

        sql = f"""
            SELECT m.*
            FROM memory_entries m
            JOIN memory_fts fts ON fts.rowid = m.rowid
            WHERE {' AND '.join(conditions)}
            ORDER BY rank
            LIMIT ?
        """
        params.append(req.limit)
        return self.conn.execute(sql, params).fetchall()

    def _recall_without_fts(self, req: RecallRequest) -> list[sqlite3.Row]:
        """Column-filter only query (no FTS — query is None)."""
        conditions = ["project_id = ?"]
        params: list[Any] = [req.project_id]

        conditions, params = _apply_filters(conditions, params, req)

        sql = f"""
            SELECT * FROM memory_entries
            WHERE {' AND '.join(conditions)}
            ORDER BY created_at DESC
            LIMIT ?
        """
        params.append(req.limit)
        return self.conn.execute(sql, params).fetchall()

    # -----------------------------------------------------------------------
    # memory_list — paginated — PRD §13 EC-F005
    # -----------------------------------------------------------------------

    def list_entries(self, req: ListRequest) -> list[MemoryEntry]:
        """
        Paginated list of memory entries with optional type filter.
        """
        conditions = ["project_id = ?"]
        params: list[Any] = [req.project_id]

        if req.entry_type:
            conditions.append("entry_type = ?")
            params.append(req.entry_type)

        if not req.include_superseded:
            conditions.append("is_superseded = 0")

        sql = f"""
            SELECT * FROM memory_entries
            WHERE {' AND '.join(conditions)}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        """
        params.extend([req.limit, req.offset])

        with read_only(self.conn):
            rows = self.conn.execute(sql, params).fetchall()

        return [MemoryEntry.from_row(r) for r in rows]

    # -----------------------------------------------------------------------
    # memory_supersede — PRD §13 EC-F005
    # -----------------------------------------------------------------------

    def supersede(
        self,
        project_id: str,
        entry_id: str,
        reason: str,
        replacement_content: str | None = None,
    ) -> MemoryEntry:
        """
        Mark an entry as superseded. Never deletes — preserves full audit trail.

        PRD AC:
          - superseded entries never deleted
          - links replacement entry if replacement_content provided
          - all writes inside transactions
        """
        existing = self.get_by_id(entry_id)
        if existing is None:
            raise MemoryEntryNotFoundError(
                f"Memory entry not found: {entry_id}",
                detail={"entry_id": entry_id, "project_id": project_id},
            )
        if existing.project_id != project_id:
            raise MemoryEntryNotFoundError(
                f"Entry {entry_id} does not belong to project {project_id}"
            )

        now = _utcnow()
        replacement_id: str | None = None

        with transaction(self.conn, str(self.db_path)):
            # Write replacement entry first (if provided)
            if replacement_content:
                replacement_id = str(uuid.uuid4())
                self.conn.execute(
                    """
                    INSERT INTO memory_entries (
                        id, project_id, feature_id, session_id,
                        entry_type, title, content, tags,
                        importance, confidence, source,
                        is_superseded, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
                    """,
                    (
                        replacement_id, project_id,
                        existing.feature_id, existing.session_id,
                        existing.entry_type,
                        f"[Updated] {existing.title}",
                        replacement_content,
                        json.dumps(existing.tags) if existing.tags else None,
                        existing.importance, existing.confidence,
                        "agent", now, now,
                    ),
                )

            # Mark original as superseded
            self.conn.execute(
                """
                UPDATE memory_entries
                SET is_superseded = 1,
                    superseded_by = ?,
                    superseded_at = ?,
                    supersede_reason = ?,
                    updated_at = ?
                WHERE id = ?
                """,
                (replacement_id, now, reason, now, entry_id),
            )

        logger.info(
            "memory_supersede: %s | reason=%s | replacement=%s",
            entry_id, reason[:60], replacement_id,
        )

        return self.get_by_id(entry_id)

    # -----------------------------------------------------------------------
    # get_by_id
    # -----------------------------------------------------------------------

    def get_by_id(self, entry_id: str) -> MemoryEntry | None:
        """Retrieve a single entry by UUID. Returns None if not found."""
        with read_only(self.conn):
            row = self.conn.execute(
                "SELECT * FROM memory_entries WHERE id = ?", (entry_id,)
            ).fetchone()
        return MemoryEntry.from_row(row) if row else None

    # -----------------------------------------------------------------------
    # Session management helpers (used by Phase 3 agents)
    # -----------------------------------------------------------------------

    def start_session(self, project_id: str, task_description: str | None = None) -> str:
        """Create a new session and return its ID."""
        session_id = str(uuid.uuid4())
        now = _utcnow()
        with transaction(self.conn, str(self.db_path)):
            self.conn.execute(
                """
                INSERT INTO sessions (id, project_id, task_description, status, started_at)
                VALUES (?, ?, ?, 'active', ?)
                """,
                (session_id, project_id, task_description, now),
            )
        logger.info("Session started: %s | project=%s", session_id, project_id)
        return session_id

    def end_session(self, session_id: str, reason: str = "completed") -> None:
        """Mark a session as completed/abandoned."""
        now = _utcnow()
        with transaction(self.conn, str(self.db_path)):
            self.conn.execute(
                """
                UPDATE sessions
                SET status = ?, ended_at = ?, ended_reason = ?
                WHERE id = ?
                """,
                (reason, now, reason, session_id),
            )
        logger.info("Session ended: %s | reason=%s", session_id, reason)

    def count_entries(self, project_id: str, include_superseded: bool = False) -> int:
        """Return total entry count for a project."""
        sql = "SELECT COUNT(*) FROM memory_entries WHERE project_id = ?"
        params: list[Any] = [project_id]
        if not include_superseded:
            sql += " AND is_superseded = 0"
        with read_only(self.conn):
            return self.conn.execute(sql, params).fetchone()[0]


# ---------------------------------------------------------------------------
# Global store registry — one store per project_id
# ---------------------------------------------------------------------------

_stores: dict[str, MemoryStore] = {}
_stores_lock = threading.Lock()


def get_store(project_id: str, db_path: Path) -> MemoryStore:
    """
    Return (or create + open) the MemoryStore for a project.
    Stores are cached per project_id.
    """
    with _stores_lock:
        if project_id not in _stores:
            store = MemoryStore(db_path)
            store.open()
            _stores[project_id] = store
        return _stores[project_id]


def close_all_stores() -> None:
    """Close all open stores. Called on server shutdown."""
    with _stores_lock:
        for store in _stores.values():
            store.close()
        _stores.clear()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _validate_write_request(req: WriteRequest) -> None:
    valid_types = {e.value for e in MemoryEntryType}
    if req.entry_type not in valid_types:
        raise ValueError(
            f"Invalid entry_type: {req.entry_type!r}. "
            f"Must be one of: {sorted(valid_types)}"
        )
    valid_importance = {e.value for e in Importance}
    if req.importance not in valid_importance:
        raise ValueError(f"Invalid importance: {req.importance!r}")
    valid_confidence = {e.value for e in Confidence}
    if req.confidence not in valid_confidence:
        raise ValueError(f"Invalid confidence: {req.confidence!r}")
    if not req.title.strip():
        raise ValueError("title must not be empty")
    if not req.content.strip():
        raise ValueError("content must not be empty")


def _apply_filters(
    conditions: list[str],
    params: list[Any],
    req: RecallRequest,
) -> tuple[list[str], list[Any]]:
    """Apply optional column filters to a recall query."""
    prefix = "m." if any("fts" in c for c in conditions) else ""

    if not req.include_superseded:
        conditions.append(f"{prefix}is_superseded = 0")

    if req.entry_type:
        conditions.append(f"{prefix}entry_type = ?")
        params.append(req.entry_type)

    if req.importance:
        conditions.append(f"{prefix}importance = ?")
        params.append(req.importance)

    if req.confidence:
        conditions.append(f"{prefix}confidence = ?")
        params.append(req.confidence)

    if req.tags:
        # Tag filtering: entry must contain ANY of the requested tags (OR logic)
        # Tags stored as JSON array — use LIKE for SQLite compatibility
        tag_conditions = [f"{prefix}tags LIKE ?" for _ in req.tags]
        conditions.append(f"({' OR '.join(tag_conditions)})")
        for tag in req.tags:
            params.append(f'%"{tag}"%')

    return conditions, params


def _utcnow() -> str:
    """Return current UTC time as ISO 8601 string."""
    return datetime.now(timezone.utc).isoformat()
