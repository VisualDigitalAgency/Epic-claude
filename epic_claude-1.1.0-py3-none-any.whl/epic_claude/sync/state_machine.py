"""
Sync State Machine — EC-F006.

Every context_sync operation follows this strict state machine.
No silent failures. Every transition logged. Every failure triggers restore.

PRD §7 — Sync State Machine:

  READY → BACKING_UP → WRITING → VERIFYING → LOGGING → DONE
                    ↘ ABORTED   ↘ RESTORING → RESTORED
                                            ↘ FAILED (critical)

State transition rules (PRD §7):
  READY      → BACKING_UP  : sync triggered
  BACKING_UP → WRITING     : backup written + verified
  BACKING_UP → ABORTED     : backup failed
  WRITING    → VERIFYING   : write complete
  WRITING    → RESTORING   : write failed mid-stream
  VERIFYING  → LOGGING     : checksum matches
  VERIFYING  → RESTORING   : checksum mismatch
  LOGGING    → DONE        : sync_log written (non-fatal if log fails)
  RESTORING  → RESTORED    : restore from backup succeeded
  RESTORING  → FAILED      : restore also failed (critical)
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from epic_claude.constants import SyncState, SyncTrigger, SYNC_FAILURE_MESSAGES
from epic_claude.exceptions import (
    SyncBackupError,
    SyncRestoreError,
    SyncVerifyError,
    SyncWriteError,
)
from epic_claude.memory.database import open_db, transaction
from epic_claude.server.logging import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Sync operation context
# ---------------------------------------------------------------------------

@dataclass
class SyncContext:
    """Mutable context object that travels through every state transition."""
    project_id: str
    claude_md_path: Path
    triggered_by: str = SyncTrigger.MANUAL
    task: str | None = None

    # Populated during transitions
    state: str = SyncState.READY
    backup_path: Path | None = None
    section_start_line: int | None = None
    section_end_line: int | None = None
    content_hash: str | None = None
    error_detail: str | None = None
    artifact_ids: list[str] = field(default_factory=list)
    memory_entry_ids: list[str] = field(default_factory=list)

    # Timing
    started_at: float = field(default_factory=time.monotonic)

    @property
    def duration_ms(self) -> int:
        return int((time.monotonic() - self.started_at) * 1000)


# ---------------------------------------------------------------------------
# State machine runner
# ---------------------------------------------------------------------------

class SyncStateMachine:
    """
    Executes the sync state machine for a single context_sync operation.
    Each step is isolated — failure in any step triggers the correct fallback.
    """

    def __init__(self, memory_db_path: Path) -> None:
        self.memory_db_path = memory_db_path

    def run(
        self,
        ctx: SyncContext,
        write_fn,       # Callable[[SyncContext], tuple[int,int,str]] → (start, end, hash)
        backup_fn,      # Callable[[SyncContext], Path] → backup_path
        restore_fn,     # Callable[[SyncContext], None]
        verify_fn,      # Callable[[SyncContext], None] — raises SyncVerifyError on mismatch
    ) -> SyncContext:
        """
        Run the full state machine synchronously.

        Args:
            ctx:        Sync context (mutated in place).
            write_fn:   Writes the managed section; returns (start_line, end_line, hash).
            backup_fn:  Creates backup; returns backup_path.
            restore_fn: Restores from backup_path.
            verify_fn:  Verifies written content matches expected hash.

        Returns:
            Mutated ctx with final state (DONE / ABORTED / RESTORED / FAILED).
        """
        # ── READY → BACKING_UP ──────────────────────────────────────
        ctx.state = SyncState.BACKING_UP
        logger.info("Sync BACKING_UP | project=%s | path=%s", ctx.project_id, ctx.claude_md_path)

        try:
            ctx.backup_path = backup_fn(ctx)
            logger.info("Backup created: %s", ctx.backup_path)
        except Exception as exc:
            ctx.state = SyncState.ABORTED
            ctx.error_detail = str(exc)
            logger.error("Sync ABORTED (backup failed): %s", exc)
            self._log(ctx)
            return ctx

        # ── BACKING_UP → WRITING ─────────────────────────────────────
        ctx.state = SyncState.WRITING
        logger.info("Sync WRITING | project=%s", ctx.project_id)

        try:
            start, end, content_hash = write_fn(ctx)
            ctx.section_start_line = start
            ctx.section_end_line   = end
            ctx.content_hash       = content_hash
        except Exception as exc:
            ctx.state = SyncState.RESTORING
            ctx.error_detail = str(exc)
            logger.error("Sync write failed — RESTORING: %s", exc)
            ctx = self._restore(ctx, restore_fn)
            self._log(ctx)
            return ctx

        # ── WRITING → VERIFYING ──────────────────────────────────────
        ctx.state = SyncState.VERIFYING
        logger.info("Sync VERIFYING | hash=%s", ctx.content_hash[:12] if ctx.content_hash else "?")

        try:
            verify_fn(ctx)
        except SyncVerifyError as exc:
            ctx.state = SyncState.RESTORING
            ctx.error_detail = str(exc)
            logger.error("Sync verify failed — RESTORING: %s", exc)
            ctx = self._restore(ctx, restore_fn)
            self._log(ctx)
            return ctx

        # ── VERIFYING → LOGGING → DONE ───────────────────────────────
        ctx.state = SyncState.DONE  # set DONE before logging so log captures final state
        logger.info("Sync LOGGING → DONE | project=%s", ctx.project_id)

        try:
            self._log(ctx)
        except Exception as exc:
            # Log failure is non-fatal — still DONE
            logger.warning("Sync log write failed (non-fatal): %s", exc)
        logger.info(
            "Sync DONE | project=%s | duration=%dms | lines=%s-%s",
            ctx.project_id, ctx.duration_ms,
            ctx.section_start_line, ctx.section_end_line,
        )
        return ctx

    def _restore(self, ctx: SyncContext, restore_fn) -> SyncContext:
        """Attempt restore from backup. → RESTORED or FAILED."""
        try:
            restore_fn(ctx)
            ctx.state = SyncState.RESTORED
            logger.info("Sync RESTORED from backup: %s", ctx.backup_path)
        except SyncRestoreError as exc:
            ctx.state = SyncState.FAILED
            ctx.error_detail = f"{ctx.error_detail} | restore also failed: {exc}"
            logger.critical(
                "Sync FAILED — restore also failed! Manual recovery needed. "
                "Backup at: %s", ctx.backup_path,
            )
        return ctx

    def _log(self, ctx: SyncContext) -> None:
        """Write one sync_log record to memory.db."""
        try:
            conn = open_db(self.memory_db_path)
            now = datetime.now(timezone.utc).isoformat()
            with transaction(conn, str(self.memory_db_path)):
                conn.execute(
                    """
                    INSERT INTO sync_log (
                        id, project_id, sync_state, claude_md_path,
                        artifact_ids, memory_entry_ids,
                        section_start_line, section_end_line,
                        content_hash, backup_path,
                        triggered_by, duration_ms, error_detail, synced_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        str(uuid.uuid4()),
                        ctx.project_id,
                        ctx.state,
                        str(ctx.claude_md_path),
                        json.dumps(ctx.artifact_ids),
                        json.dumps(ctx.memory_entry_ids),
                        ctx.section_start_line,
                        ctx.section_end_line,
                        ctx.content_hash,
                        str(ctx.backup_path) if ctx.backup_path else None,
                        ctx.triggered_by,
                        ctx.duration_ms,
                        ctx.error_detail,
                        now,
                    ),
                )
            conn.close()
        except Exception as exc:
            logger.warning("Failed to write sync_log: %s", exc)


def user_message_for_state(ctx: SyncContext) -> str:
    """Return the user-facing message for the final sync state (PRD §7)."""
    template = SYNC_FAILURE_MESSAGES.get(ctx.state, "")
    backup_path = str(ctx.backup_path) if ctx.backup_path else "unknown"
    return template.format(backup_path=backup_path)


def get_last_sync(project_id: str, memory_db_path: Path) -> dict[str, Any] | None:
    """Return the most recent sync_log entry for a project."""
    try:
        conn = open_db(memory_db_path)
        row = conn.execute(
            "SELECT * FROM sync_log WHERE project_id=? ORDER BY synced_at DESC LIMIT 1",
            (project_id,),
        ).fetchone()
        conn.close()
        return dict(row) if row else None
    except Exception:
        return None
