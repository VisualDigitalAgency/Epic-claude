"""
CLI: epic project — project management.

  epic project list     → list all registered projects
  epic project switch   → switch active project

Replaces the old 'epic projects' group with cleaner singular naming.
"""

from __future__ import annotations

from typing import Optional

try:
    import typer
except ImportError:
    typer = None  # type: ignore

try:
    from rich.table import Table
    from rich.panel import Panel
except ImportError:
    Table = Panel = None  # type: ignore

from epic_claude.cli.output import console, print_error, print_success, print_json, is_json_mode

project_app = typer.Typer(
    help="Manage projects: list, switch.",
    no_args_is_help=True,
) if typer else None


if project_app and typer:

    @project_app.command("list")
    def project_list() -> None:
        """List all registered projects."""
        try:
            import epic_claude.registry as reg_mod
            from epic_claude.memory.registry_store import RegistryStore
            from epic_claude.memory.database import bootstrap_registry_db

            db = reg_mod.REGISTRY_DB_PATH
            if not db.exists():
                bootstrap_registry_db(db)

            rs = RegistryStore(db); rs.open()
            try:
                projects = rs.list_active()
            finally:
                rs.close()

            if is_json_mode():
                print_json([p.to_dict() for p in projects])
                return

            if not projects:
                console.print(
                    "[dim]No projects registered.[/dim]\n"
                    "  Start one: [cyan]epic plan \"describe your project\"[/cyan]"
                )
                return

            table = Table(
                title=f"Projects ({len(projects)})",
                show_header=True, header_style="bold cyan",
            )
            table.add_column("ID",       style="dim", width=10)
            table.add_column("Name",     style="bold")
            table.add_column("Type",     width=14)
            table.add_column("Stack",    width=8)
            table.add_column("Arch",     width=8)
            table.add_column("Path",     style="dim")

            for p in projects:
                table.add_row(
                    p.id[:8] + "..",
                    p.name,
                    p.project_type or "—",
                    "[green]✓[/green]" if p.stack_confirmed    else "[dim]—[/dim]",
                    "[green]✓[/green]" if p.architect_generated else "[dim]—[/dim]",
                    p.root_path,
                )
            console.print(table)

        except Exception as exc:
            print_error(f"Failed to list projects: {exc}")
            raise typer.Exit(code=1)


    @project_app.command("switch")
    def project_switch(
        project: str = typer.Argument(None, help="Project ID (prefix) or root path."),
    ) -> None:
        """Switch active project (interactive picker if no argument given)."""
        try:
            import epic_claude.registry as reg_mod
            from epic_claude.memory.registry_store import RegistryStore

            rs = RegistryStore(reg_mod.REGISTRY_DB_PATH); rs.open()
            try:
                all_projects = rs.list_active()
            finally:
                rs.close()

            if not all_projects:
                print_error("No projects registered.")
                raise typer.Exit(code=1)

            if project:
                matched = [
                    p for p in all_projects
                    if p.id.startswith(project) or p.root_path == project
                ]
                if not matched:
                    print_error(f"No project matching: {project!r}")
                    raise typer.Exit(code=1)
                selected = matched[0]
            else:
                console.print("\n[bold]Available projects:[/bold]")
                for i, p in enumerate(all_projects, 1):
                    status = "[green]✓ arch[/green]" if p.architect_generated else (
                        "[cyan]stack ✓[/cyan]" if p.stack_confirmed else "[dim]pending[/dim]"
                    )
                    console.print(f"  [{i}] {p.name}  {status}  [dim]{p.root_path}[/dim]")
                console.print()
                choice = typer.prompt("Select project", default="1")
                try:
                    selected = all_projects[int(choice) - 1]
                except (ValueError, IndexError):
                    print_error("Invalid selection.")
                    raise typer.Exit(code=1)

            if is_json_mode():
                print_json({"switched_to": selected.to_dict()})
            else:
                console.print(f"\n[green]✓[/green] Active project: [bold]{selected.name}[/bold]")
                console.print(f"  ID:   [dim]{selected.id}[/dim]")
                console.print(f"  Path: [dim]{selected.root_path}[/dim]")

        except typer.Exit:
            raise
        except Exception as exc:
            print_error(f"Switch failed: {exc}")
            raise typer.Exit(code=1)
