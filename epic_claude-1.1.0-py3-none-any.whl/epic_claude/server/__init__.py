"""
EC-F001 — MCP Server Core.

Public API for the server package:
  - EpicClaudeServer: the async stdio MCP server
  - run_server(): synchronous entry point used by CLI
  - TOOL_REGISTRY: global tool definition registry
  - register_handler(): used by each feature module to wire up handlers
"""

from epic_claude.server.server import EpicClaudeServer, run_server
from epic_claude.server.tools import TOOL_REGISTRY, register_handler
from epic_claude.server.protocol import (
    JsonRpcRequest,
    JsonRpcResponse,
    JsonRpcErrorResponse,
    McpToolDefinition,
)
from epic_claude.server.detection import (
    detect_project,
    validate_project,
    format_project_banner,
    DetectionResult,
    DetectionStatus,
)
from epic_claude.server.logging import get_logger, setup_server_logging

__all__ = [
    "EpicClaudeServer",
    "run_server",
    "TOOL_REGISTRY",
    "register_handler",
    "JsonRpcRequest",
    "JsonRpcResponse",
    "JsonRpcErrorResponse",
    "McpToolDefinition",
    "detect_project",
    "validate_project",
    "format_project_banner",
    "DetectionResult",
    "DetectionStatus",
    "get_logger",
    "setup_server_logging",
]
