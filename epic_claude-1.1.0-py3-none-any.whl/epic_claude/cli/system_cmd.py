"""
CLI: epic system — system-level operations.

  epic system serve     → start the MCP server
  epic system migrate   → run DB schema migrations
  epic system doctor    → health check

Groups technical operations the user rarely needs day-to-day.
Keeps the top-level 'epic' surface clean (plan/generate/sync/status).
"""

from __future__ import annotations

try:
    import typer
except ImportError:
    typer = None  # type: ignore

try:
    from rich.table import Table
    from rich.panel import Panel
except ImportError:
    Table = Panel = None  # type: ignore

from epic_claude.cli.output import console, print_error, print_success, print_json, is_json_mode

system_app = typer.Typer(
    help="System operations: serve, migrate, doctor.",
    no_args_is_help=True,
) if typer else None


if system_app and typer:

    @system_app.command("serve")
    def system_serve(
        dry_run: bool = typer.Option(False, "--dry-run",
            help="Validate config and exit without starting server."),
    ) -> None:
        """Start the MCP server (stdio transport for Claude Code)."""
        try:
            from epic_claude.cli.serve import _run_serve
            _run_serve(dry_run=dry_run)
        except Exception as exc:
            print_error(f"Server failed: {exc}")
            raise typer.Exit(code=1)


    @system_app.command("migrate")
    def system_migrate(
        check: bool = typer.Option(False, "--check",
            help="Check for pending migrations without applying them."),
    ) -> None:
        """Run pending DB schema migrations after upgrading epic."""
        try:
            from epic_claude.cli.migrate_cmd import _run_migrate
            exit_code = _run_migrate(check_only=check)
            if exit_code != 0:
                raise typer.Exit(code=exit_code)
        except typer.Exit:
            raise
        except Exception as exc:
            print_error(f"Migration failed: {exc}")
            raise typer.Exit(code=1)


    @system_app.command("doctor")
    def system_doctor() -> None:
        """Health check: Python, home dir, API key, schema versions."""
        # Delegate to the top-level doctor command implementation
        try:
            import sys
            from epic_claude.main import doctor
            doctor()
        except Exception as exc:
            print_error(f"Doctor failed: {exc}")
            raise typer.Exit(code=1)
