"""
LLM prompt templates for EC-F002 (Clarification Agent) and EC-F003 (Tech Stack Decider).

All prompts are pure functions — no side effects.
They take structured inputs and return formatted strings.

Design principles (PRD §1):
  - Never ask what can be inferred from the description
  - One follow-up per unknown answer maximum
  - Always ask before deciding
  - Numbered options for bounded-choice questions
"""

from __future__ import annotations

from typing import Any


# ---------------------------------------------------------------------------
# EC-F002 — Clarification Agent prompts
# ---------------------------------------------------------------------------

CLARIFICATION_SYSTEM = """\
You are EPIC-Claude, an expert AI Solutions Architect.
Your job is to gather precise requirements for a software project so you can generate
a complete, production-grade architecture.

Rules you MUST follow:
1. Never ask about something already stated in the project description.
2. Infer obvious answers — e.g. if the user says "Python SaaS", language=Python.
3. For each question, provide numbered options where applicable.
4. Be concise and targeted — no fluff, no preamble.
5. Return ONLY valid JSON — no markdown, no explanation outside the JSON.

Supported project types (v1): backend_saas, rest_api, fullstack_web.
If the type is unsupported, set project_type to "unsupported" and explain why.
"""

CLARIFICATION_QUESTIONS_PROMPT = """\
Project description: "{description}"

Generate a targeted clarification questionnaire for this project.
Do NOT ask about anything already clearly stated in the description.
Infer what you can confidently determine.

Return JSON with this exact structure:
{{
  "inferred": {{
    "project_type": "<backend_saas|rest_api|fullstack_web|unsupported|unknown>",
    "language": "<language or null>",
    "framework": "<framework or null>"
  }},
  "questions": [
    {{
      "key": "<snake_case_key>",
      "question": "<Clear question text>",
      "options": ["Option 1", "Option 2", "Option 3", "I'm not sure"],
      "required": true
    }}
  ]
}}

Include questions for any of these that are NOT already clear from the description:
- project_type (if not obvious)
- scale (expected users at launch)
- database (preferred DB technology)
- auth (authentication approach)
- deployment (target platform)
- multi_tenancy (required for SaaS?)
- constraints (budget, timeline, existing tech)

Each "options" array must end with "I'm not sure" for unknown answers.
Omit any question whose answer is already stated in the description.
"""


def build_clarification_prompt(description: str) -> str:
    return CLARIFICATION_QUESTIONS_PROMPT.format(description=description)


FOLLOWUP_PROMPT = """\
The user answered "I'm not sure" or gave an unknown answer to this question:

Question key: "{key}"
Question:     "{question}"

Generate exactly ONE targeted follow-up question that might resolve this.
Keep it very short and specific.

Return JSON:
{{
  "followup_key": "{key}_followup",
  "followup_question": "<one sentence follow-up>",
  "options": ["Option A", "Option B", "Option C", "Unknown — make a reasonable assumption"]
}}
"""


def build_followup_prompt(key: str, question: str) -> str:
    return FOLLOWUP_PROMPT.format(key=key, question=question)


ASSUMPTION_PROMPT = """\
The user could not answer this question even after a follow-up:

Question key: "{key}"
Question:     "{question}"
Project type: "{project_type}"
Description:  "{description}"

Make the most reasonable assumption for a {project_type} project.
Document it clearly so the user can review and correct it.

Return JSON:
{{
  "assumed_value": "<your assumption>",
  "confidence": "low",
  "assumption_text": "Assumed: <value> — revise if wrong",
  "impact": "<one sentence describing what this affects>"
}}
"""


def build_assumption_prompt(
    key: str,
    question: str,
    project_type: str,
    description: str,
) -> str:
    return ASSUMPTION_PROMPT.format(
        key=key,
        question=question,
        project_type=project_type,
        description=description,
    )


SUFFICIENCY_PROMPT = """\
Review these clarification answers for a {project_type} project:

{answers_summary}

Is this sufficient context to propose a tech stack and generate architecture?

Return JSON:
{{
  "ready": true or false,
  "missing": ["list of still-unknown critical items"],
  "can_proceed_with_assumptions": true or false,
  "reason": "one sentence explanation"
}}

Set ready=true if:
- project_type is known and supported
- We have at least a partial answer for scale, database, auth, deployment
- Any unknowns can be reasonably assumed

Set ready=false only if project_type is completely unknown or unsupported.
"""


def build_sufficiency_prompt(project_type: str, answers_summary: str) -> str:
    return SUFFICIENCY_PROMPT.format(
        project_type=project_type,
        answers_summary=answers_summary,
    )


# ---------------------------------------------------------------------------
# EC-F003 — Tech Stack Decider prompts
# ---------------------------------------------------------------------------

STACK_SYSTEM = """\
You are EPIC-Claude, an expert AI Solutions Architect specialising in tech stack selection.
Your job is to propose the optimal technology stack for a specific project based on
confirmed requirements.

Rules:
1. Every decision must include rationale and alternatives considered.
2. Be opinionated but practical — choose what works reliably, not what's trendy.
3. Consider the project type, scale, team size, and constraints.
4. Return ONLY valid JSON — no markdown, no explanation outside the JSON.
"""

STACK_PROPOSE_PROMPT = """\
Project: "{name}"
Type: {project_type}
Description: {description}

Confirmed clarification answers:
{answers_summary}

Propose the optimal tech stack. For each category, provide:
- name: technology name
- version: version constraint (e.g. "3.11+", "0.100+", "latest")
- rationale: why this choice for THIS project
- alternatives: array of rejected alternatives with brief reasons

Return JSON with this exact structure:
{{
  "stack": {{
    "language":   {{"name": "", "version": "", "rationale": "", "alternatives": []}},
    "framework":  {{"name": "", "version": "", "rationale": "", "alternatives": []}},
    "database":   {{"name": "", "version": "", "rationale": "", "alternatives": []}},
    "auth":       {{"name": "", "version": "", "rationale": "", "alternatives": []}},
    "deployment": {{"name": "", "version": "", "rationale": "", "alternatives": []}},
    "testing":    {{"name": "", "version": "", "rationale": "", "alternatives": []}},
    "cicd":       {{"name": "", "version": "", "rationale": "", "alternatives": []}}
  }},
  "summary": "One sentence summary of the stack",
  "assumptions": ["Any assumptions made due to missing info"]
}}

Include "cache" category only if the project clearly needs caching.
"""


def build_stack_propose_prompt(
    name: str,
    project_type: str,
    description: str,
    answers_summary: str,
) -> str:
    return STACK_PROPOSE_PROMPT.format(
        name=name,
        project_type=project_type,
        description=description,
        answers_summary=answers_summary,
    )


# ---------------------------------------------------------------------------
# Answer summary formatter (shared by clarification + stack prompts)
# ---------------------------------------------------------------------------

def format_answers_summary(answers: dict[str, Any], assumptions: list[dict]) -> str:
    """Format answers dict and assumptions list into a readable summary for LLM prompts."""
    lines = []
    for key, value in answers.items():
        if value and str(value).strip().lower() not in ("i'm not sure", "unknown", ""):
            lines.append(f"  {key}: {value}")

    if assumptions:
        lines.append("\nAssumptions (confidence=low):")
        for a in assumptions:
            lines.append(f"  {a.get('key', '?')}: {a.get('assumed_value', '?')} — {a.get('assumption_text', '')}")

    return "\n".join(lines) if lines else "  (no answers yet)"
