"""
EC-F007 — CLI Interface.

All epic-claude subcommands. Each module exports a Typer app
registered in epic_claude/main.py.

Commands:
  serve       → cli/serve.py
  projects    → cli/projects.py
  stack       → cli/stack_cmd.py
  memory      → cli/memory_cmd.py
  sync        → cli/sync_cmd.py
  status      → cli/status_cmd.py
"""

from epic_claude.cli.output import (
    console, err_console,
    set_json_mode, set_quiet_mode,
    is_json_mode, is_quiet_mode,
    print_json, print_success, print_error, print_warning, print_info,
    print_project_banner, maybe_print_banner,
)

__all__ = [
    "console", "err_console",
    "set_json_mode", "set_quiet_mode",
    "is_json_mode", "is_quiet_mode",
    "print_json", "print_success", "print_error",
    "print_warning", "print_info",
    "print_project_banner", "maybe_print_banner",
]
