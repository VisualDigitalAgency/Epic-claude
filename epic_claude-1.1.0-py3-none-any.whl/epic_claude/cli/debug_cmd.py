"""
CLI: epic debug — debug and introspection tools.

  epic debug memory list    → list memory entries
  epic debug memory search  → full-text search
  epic debug memory show    → show full entry
  epic debug artifacts      → list generated artifacts

Groups internal/power-user commands away from the core workflow surface.
"""

from __future__ import annotations

from typing import Optional

try:
    import typer
except ImportError:
    typer = None  # type: ignore

try:
    from rich.table import Table
    from rich.markdown import Markdown
except ImportError:
    Table = Markdown = None  # type: ignore

from epic_claude.cli.output import console, print_error, print_json, print_no_project_found, is_json_mode

debug_app  = typer.Typer(help="Debug and introspection tools.", no_args_is_help=True) if typer else None
memory_sub = typer.Typer(help="Inspect the Memory Bank.", no_args_is_help=True)       if typer else None

if debug_app and memory_sub:
    debug_app.add_typer(memory_sub, name="memory")


def _get_store(project_id: str | None):
    import os
    from pathlib import Path
    import epic_claude.registry as reg_mod
    from epic_claude.memory.store import get_store
    from epic_claude.server.detection import detect_project, DetectionStatus

    if project_id is None:
        cwd = Path(os.getcwd())
        detection = detect_project(cwd=cwd, registry_projects_dir=reg_mod.PROJECTS_DIR)
        if detection.status == DetectionStatus.NOT_FOUND or detection.project is None:
            print_no_project_found(str(cwd))
            raise typer.Exit(code=1)
        project_id = detection.project.project_id

    memory_db = reg_mod.PROJECTS_DIR / project_id / "memory.db"
    return get_store(project_id, memory_db), project_id


if memory_sub and typer:

    @memory_sub.command("list")
    def memory_list(
        type_filter: Optional[str] = typer.Option(None, "--type", "-t",
            help="Filter by type: decision|constraint|assumption|context"),
        limit: int = typer.Option(50, "--limit", "-n"),
        project_id: Optional[str] = typer.Option(None, "--project-id"),
    ) -> None:
        """List memory entries."""
        try:
            store, pid = _get_store(project_id)
            from epic_claude.memory.store import ListRequest
            result = store.list_entries(ListRequest(pid, entry_type=type_filter, limit=limit))

            if is_json_mode():
                print_json([e.to_dict() for e in result])
                return

            if not result:
                console.print("[dim]No memory entries found.[/dim]")
                return

            table = Table(show_header=True, header_style="bold cyan",
                          title=f"Memory Entries ({len(result)})")
            table.add_column("ID",         style="dim", width=10)
            table.add_column("Type",       width=14)
            table.add_column("Title",      style="bold")
            table.add_column("Confidence", width=10)
            table.add_column("Created",    style="dim", width=12)
            for e in result:
                table.add_row(e.id[:8], e.entry_type, e.title[:55],
                              e.confidence, e.created_at[:10] if e.created_at else "—")
            console.print(table)

        except Exception as exc:
            print_error(f"Memory list failed: {exc}")
            raise typer.Exit(code=1)


    @memory_sub.command("search")
    def memory_search(
        query: str = typer.Argument(..., help="Full-text search query."),
        limit: int = typer.Option(20, "--limit", "-n"),
        project_id: Optional[str] = typer.Option(None, "--project-id"),
    ) -> None:
        """Full-text search across memory entries."""
        try:
            store, pid = _get_store(project_id)
            from epic_claude.memory.store import RecallRequest
            result = store.recall(RecallRequest(pid, query=query, limit=limit))

            if is_json_mode():
                print_json([e.to_dict() for e in result])
                return

            if not result:
                console.print(f"[dim]No results for: {query!r}[/dim]")
                return

            console.print(f"\n[bold]Results for:[/bold] [cyan]{query}[/cyan]\n")
            for e in result:
                console.print(f"  [bold]{e.entry_type}[/bold] [{e.id[:8]}] {e.title}")
                preview = e.content[:100].replace("\n", " ")
                console.print(f"  [dim]{preview}...[/dim]\n")

        except Exception as exc:
            print_error(f"Memory search failed: {exc}")
            raise typer.Exit(code=1)


    @memory_sub.command("show")
    def memory_show(
        entry_id: str = typer.Argument(..., help="Memory entry ID or prefix."),
        project_id: Optional[str] = typer.Option(None, "--project-id"),
    ) -> None:
        """Show full details of a memory entry."""
        try:
            store, pid = _get_store(project_id)
            entry = store.get_by_id(entry_id)

            if entry is None:
                print_error(f"Entry not found: {entry_id}")
                raise typer.Exit(code=1)

            if is_json_mode():
                print_json(entry.to_dict())
                return

            console.print(f"\n[bold]Memory Entry: {entry.id}[/bold]")
            console.print(f"Type:       {entry.entry_type}")
            console.print(f"Title:      {entry.title}")
            console.print(f"Importance: {entry.importance}")
            console.print(f"Confidence: {entry.confidence}")
            console.print(f"Tags:       {', '.join(entry.tags) or '—'}")
            console.print(f"Superseded: {'yes' if entry.is_superseded else 'no'}")
            console.print(f"Created:    {entry.created_at}")
            console.print(f"\n[bold]Content:[/bold]")
            console.print(Markdown(entry.content) if Markdown else entry.content)

        except typer.Exit:
            raise
        except Exception as exc:
            print_error(f"Memory show failed: {exc}")
            raise typer.Exit(code=1)


if debug_app and typer:

    @debug_app.command("artifacts")
    def debug_artifacts(
        project_id: Optional[str] = typer.Option(None, "--project-id"),
    ) -> None:
        """List generated architecture artifacts."""
        try:
            import os
            from pathlib import Path
            import epic_claude.registry as reg_mod
            from epic_claude.server.detection import detect_project, DetectionStatus
            from epic_claude.agents.architect import list_artifacts

            if project_id is None:
                cwd = Path(os.getcwd())
                d = detect_project(cwd=cwd, registry_projects_dir=reg_mod.PROJECTS_DIR)
                if d.status == DetectionStatus.NOT_FOUND or d.project is None:
                    print_no_project_found(str(cwd))
                    raise typer.Exit(code=1)
                project_id = d.project.project_id

            memory_db = reg_mod.PROJECTS_DIR / project_id / "memory.db"
            arts = list_artifacts(project_id, memory_db)

            if is_json_mode():
                print_json(arts)
                return

            if not arts:
                console.print("[dim]No artifacts generated yet. Run: epic generate[/dim]")
                return

            table = Table(show_header=True, header_style="bold cyan", title="Artifacts")
            table.add_column("Type",       width=14)
            table.add_column("File",       style="dim")
            table.add_column("Validated",  width=10)
            table.add_column("Checksum",   style="dim", width=14)
            for a in arts:
                validated = "[green]✓[/green]" if a.get("validation_passed") else "[red]✗[/red]"
                checksum  = a.get("checksum", "")[:10] + ".." if a.get("checksum") else "—"
                table.add_row(a.get("artifact_type","?"), a.get("file_path","?"),
                              validated, checksum)
            console.print(table)

        except typer.Exit:
            raise
        except Exception as exc:
            print_error(f"Failed: {exc}")
            raise typer.Exit(code=1)
