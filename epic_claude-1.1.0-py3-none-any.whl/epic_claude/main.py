"""
epic — AI Architecture Control Plane for Claude Code.

Entrypoint registered as 'epic' in pyproject.toml.
Legacy alias 'epic-claude' kept for backward compatibility.

Workflow commands (top-level — the 5 users need daily):
  epic init        → initialise project
  epic plan        → define requirements + clarify + stack
  epic generate    → create architecture artifacts
  epic sync        → sync to CLAUDE.md
  epic status      → project health dashboard

Grouped commands (power users):
  epic project list/switch   → manage projects
  epic tech show/confirm/adjust → tech stack
  epic system serve/migrate/doctor → system ops
  epic debug memory/artifacts → introspection
"""

from __future__ import annotations
import sys

try:
    import typer
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    from rich.table import Table
    _RICH = True
except ImportError:
    typer = None   # type: ignore
    _RICH = False
    class Console:  # type: ignore
        def print(self, *a, **kw):
            import re; s = str(a[0]) if a else ""; print(re.sub(r"[[][^]]*[]]", "", s))
    class Panel:  # type: ignore
        def __init__(self, *a, **kw): pass
    class Text:  # type: ignore
        def __init__(self, t="", **kw): self.t = t
    class Table:  # type: ignore
        def __init__(self, *a, **kw): pass
        def add_column(self, *a, **kw): pass
        def add_row(self, *a, **kw): pass

from epic_claude import __version__

# ---------------------------------------------------------------------------
# Lazy helpers
# ---------------------------------------------------------------------------

def _bootstrap_home() -> None:
    from epic_claude.registry import bootstrap_home; bootstrap_home()

def _home_is_initialised() -> bool:
    from epic_claude.registry import home_is_initialised; return home_is_initialised()

def _get_home_path() -> str:
    from epic_claude.registry import EPIC_CLAUDE_HOME; return str(EPIC_CLAUDE_HOME)

def _load_config():
    from epic_claude.config import load_config; return load_config()

# ---------------------------------------------------------------------------
# Guard: typer is required
# ---------------------------------------------------------------------------

if typer is None:
    raise ImportError(
        "typer is required. Install with: pipx install epic"
    )

# ---------------------------------------------------------------------------
# Top-level app
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="epic",
    help="AI Architecture Control Plane for Claude Code.",
    add_completion=True,
    rich_markup_mode="rich" if _RICH else None,
    no_args_is_help=False,
)

console     = Console()
err_console = Console()

# ---------------------------------------------------------------------------
# Subcommands — new hierarchy
# ---------------------------------------------------------------------------

try:
    # Core workflow (top-level)
    from epic_claude.cli.generate_cmd import generate_app
    from epic_claude.cli.sync_cmd     import sync_app
    from epic_claude.cli.status_cmd   import status_app

    # Grouped
    from epic_claude.cli.project_cmd  import project_app
    from epic_claude.cli.stack_cmd    import tech_app
    from epic_claude.cli.system_cmd   import system_app
    from epic_claude.cli.debug_cmd    import debug_app

    # Plan command
    from epic_claude.cli.plan_cmd     import plan_app

    # Legacy flat commands (kept for users coming from epic-claude)
    from epic_claude.cli.serve        import serve_app
    from epic_claude.cli.migrate_cmd  import migrate_app

    # Register — workflow first
    if plan_app:     app.add_typer(plan_app,     name="plan",     no_args_is_help=False)
    if generate_app: app.add_typer(generate_app, name="generate", no_args_is_help=False)
    if sync_app:     app.add_typer(sync_app,     name="sync",     no_args_is_help=False)
    if status_app:   app.add_typer(status_app,   name="status",   no_args_is_help=False)

    # Groups
    if project_app:  app.add_typer(project_app,  name="project",  no_args_is_help=True)
    if tech_app:     app.add_typer(tech_app,      name="tech",     no_args_is_help=True)
    if system_app:   app.add_typer(system_app,    name="system",   no_args_is_help=True)
    if debug_app:    app.add_typer(debug_app,     name="debug",    no_args_is_help=True)

    # Legacy flat — still work but not in onboarding
    if serve_app:    app.add_typer(serve_app,    name="serve",    no_args_is_help=False)
    if migrate_app:  app.add_typer(migrate_app,  name="migrate",  no_args_is_help=False)

except Exception as _import_err:
    pass  # Partial imports — core commands still available


# ---------------------------------------------------------------------------
# Core commands
# ---------------------------------------------------------------------------

@app.command()
def version() -> None:
    """Show version, Python, and platform info."""
    import platform
    if _RICH:
        console.print(Panel(
            f"[bold cyan]epic v{__version__}[/bold cyan]\n"
            f"[dim]Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
            f" · {platform.system()} {platform.machine()}[/dim]\n"
            f"[dim]State: {_get_home_path()}[/dim]",
            subtitle="[dim]AI Architecture Control Plane[/dim]",
            border_style="cyan",
        ))
    else:
        print(f"epic v{__version__}")
        print(f"Python {sys.version_info.major}.{sys.version_info.minor}")


@app.command()
def init() -> None:
    """Initialise the global registry (~/.epic/). Safe to run multiple times."""
    _bootstrap_home()
    try:
        cfg = _load_config(); model = cfg.llm_model; db_eng = cfg.db_engine
    except Exception:
        model = "claude-sonnet-4-20250514"; db_eng = "sqlite"

    home = _get_home_path()
    if _RICH:
        console.print(Panel(
            f"[green]✓[/green] epic home initialised\n"
            f"[dim]Path:[/dim]      {home}\n"
            f"[dim]Model:[/dim]     {model}\n"
            f"[dim]DB engine:[/dim] {db_eng}\n\n"
            "[bold]Next steps:[/bold]\n"
            "  1. [cyan]export ANTHROPIC_API_KEY=your-key[/cyan]\n"
            "  2. [cyan]epic plan \"describe your project\"[/cyan]",
            title="[bold]epic init[/bold]",
            border_style="green",
        ))
    else:
        print(f"✓ Initialised: {home}")
        print("Next: export ANTHROPIC_API_KEY=your-key")
        print("Then: epic plan \"describe your project\"")


@app.command()
def plan(
    description: str = typer.Argument(None, help="Project description."),
) -> None:
    """
    Start a new project: clarify requirements, decide stack, generate architecture.

    This is the main entry point for every new project.
    """
    from pathlib import Path
    import os

    if not _home_is_initialised():
        _bootstrap_home()

    # Check API key
    if not os.environ.get("ANTHROPIC_API_KEY"):
        if _RICH:
            console.print("[bold red]✗[/bold red] ANTHROPIC_API_KEY is not set.\n")
            console.print("  Set it with: [cyan]export ANTHROPIC_API_KEY=your-key[/cyan]")
        else:
            print("✗ ANTHROPIC_API_KEY is not set. export ANTHROPIC_API_KEY=your-key")
        raise typer.Exit(code=1)

    if description is None:
        if _RICH:
            console.print("[bold]What do you want to build?[/bold]")
            console.print("[dim]Example: a multi-tenant SaaS invoicing app in Python[/dim]\n")
        description = typer.prompt("Project description")

    if _RICH:
        console.print(f"\n[bold]Starting:[/bold] {description}\n")
        console.print("[dim]This will:[/dim]")
        console.print("  1. Clarify your requirements (interactive Q&A)")
        console.print("  2. Propose a tech stack for your approval")
        console.print("  3. Generate architecture artifacts (PRD, API spec, schema, boundaries)")
        console.print("  4. Sync architecture context to CLAUDE.md\n")
        console.print("[dim]Running via MCP tool: project_start → clarify → stack → generate → sync[/dim]\n")
    else:
        print(f"Starting: {description}")

    # For CLI usage: run the MCP tool handlers directly
    import asyncio
    from epic_claude.memory.database import bootstrap_registry_db, bootstrap_memory_db
    import epic_claude.registry as reg_mod

    if not reg_mod.REGISTRY_DB_PATH.exists():
        bootstrap_registry_db(reg_mod.REGISTRY_DB_PATH)

    cwd = Path(os.getcwd())

    # Invoke the full flow through MCP handlers
    # In MCP mode, Claude Code drives this loop.
    # In CLI mode, we run project_start + prompt user for answers
    async def _run_plan():
        from epic_claude.agents.handlers import _handle_project_start

        # Step 1: Start project and get clarification questions
        result = await _handle_project_start({"description": description, "cwd": str(cwd)})

        if not result.get("success"):
            if result.get("error") == "unsupported_project_type":
                if _RICH:
                    console.print(f"\n[red]✗[/red] {result['message']}")
                    console.print(f"\n  Supported types: {', '.join(result.get('supported_types', []))}")
                else:
                    print(f"✗ {result['message']}")
                return False

            if _RICH:
                console.print(f"\n[red]✗[/red] Failed: {result.get('message','Unknown error')}")
            return False

        project_id = result["project_id"]
        session_id = result["session_id"]
        questions  = result.get("questions", [])
        inferred   = result.get("inferred", {})

        if _RICH:
            console.print(f"[green]✓[/green] Project: [bold]{result['project_name']}[/bold]  [dim]ID: {project_id[:8]}[/dim]")
            if inferred:
                inferred_str = "  ".join(f"{k}={v}" for k, v in inferred.items() if v)
                console.print(f"[dim]  Inferred: {inferred_str}[/dim]")
            console.print()
        else:
            print(f"✓ Project: {result['project_name']} ({project_id[:8]})")

        # Step 2: Ask clarification questions
        answers = {}
        if questions:
            if _RICH:
                console.print("[bold]Clarification questions:[/bold]\n")
            for q in questions:
                if _RICH:
                    console.print(f"[cyan]{q['question']}[/cyan]")
                    for i, opt in enumerate(q.get("options", []), 1):
                        console.print(f"  [{i}] {opt}")
                    raw = typer.prompt("  Answer (number or text)", default="1")
                else:
                    raw = typer.prompt(q["question"])

                # Resolve numbered option
                opts = q.get("options", [])
                try:
                    idx = int(raw) - 1
                    answers[q["key"]] = opts[idx] if 0 <= idx < len(opts) else raw
                except (ValueError, IndexError):
                    answers[q["key"]] = raw

                if _RICH: console.print()

        # Submit answers
        from epic_claude.agents.handlers import _handle_clarify_answer
        ans_result = await _handle_clarify_answer({
            "session_id": session_id,
            "answers": answers,
        })

        if _RICH:
            console.print("[green]✓[/green] Requirements captured\n")
        else:
            print("✓ Requirements captured")

        # Step 3: Propose + confirm stack
        from epic_claude.agents.handlers import _handle_stack_decide, _handle_stack_confirm
        stack_result = await _handle_stack_decide({"project_id": project_id})

        if stack_result.get("success"):
            stack = stack_result.get("stack", {})
            if _RICH:
                console.print("[bold]Proposed tech stack:[/bold]")
                for cat, entry in stack.items():
                    if isinstance(entry, dict):
                        console.print(f"  {cat:<12} [cyan]{entry.get('name','?')}[/cyan] {entry.get('version','')}")
                console.print()
                typer.confirm("Confirm this stack?", default=True, abort=True)
            else:
                for cat, entry in stack.items():
                    if isinstance(entry, dict):
                        print(f"  {cat}: {entry.get('name','?')}")

            await _handle_stack_confirm({"project_id": project_id})
            if _RICH:
                console.print("[green]✓[/green] Stack confirmed\n")

        # Step 4: Generate architecture
        if _RICH:
            console.print("[bold]Generating architecture...[/bold]")
            console.print("[dim](PRD · API spec · DB schema · Tech stack · Service boundaries)[/dim]\n")

        from epic_claude.agents.architect_handlers import _handle_architect_generate
        gen_result = await _handle_architect_generate({"project_id": project_id})

        if not gen_result.get("success"):
            if _RICH:
                console.print(f"[red]✗[/red] Generation failed: {gen_result.get('message','?')}")
            return False

        if _RICH:
            console.print(f"[green]✓[/green] Architecture generated")
            console.print(f"  Artifacts: {len(gen_result.get('artifacts',[]))}")
            console.print(f"  Output:    {gen_result.get('arch_dir','?')}\n")

        # Step 5: Sync to CLAUDE.md
        from epic_claude.sync.handlers import _handle_context_sync
        sync_result = await _handle_context_sync({
            "project_id": project_id,
            "triggered_by": "plan",
        })
        if sync_result.get("success") and _RICH:
            console.print("[green]✓[/green] CLAUDE.md synced\n")

        if _RICH:
            console.print(Panel(
                f"[bold green]✓ Project ready: {result['project_name']}[/bold green]\n\n"
                f"Architecture is in: [dim]{gen_result.get('arch_dir','?')}[/dim]\n"
                f"Context synced to:  [dim]{str(cwd)}/CLAUDE.md[/dim]\n\n"
                "[bold]Next:[/bold] Open Claude Code in this directory — it will see your architecture.",
                border_style="green",
            ))
        else:
            print(f"✓ Done. Open Claude Code in {cwd}")

        return True

    try:
        asyncio.run(_run_plan())
    except typer.Abort:
        console.print("\n[dim]Cancelled.[/dim]")
    except Exception as exc:
        if _RICH:
            console.print(f"\n[red]✗[/red] plan failed: {exc}")
        else:
            print(f"✗ plan failed: {exc}")
        raise typer.Exit(code=1)


@app.command()
def doctor() -> None:
    """Health check: Python, home dir, API key, schema versions."""
    import os
    from pathlib import Path

    checks = []
    py_ver = sys.version_info
    py_ok  = py_ver >= (3, 11)
    checks.append(("Python version", py_ok,
                    f"{py_ver.major}.{py_ver.minor}.{py_ver.micro}",
                    "" if py_ok else "(3.11+ required — upgrade Python)"))

    home_ok = _home_is_initialised()
    checks.append(("Home directory", home_ok, _get_home_path(),
                    "" if home_ok else "Run: epic init"))

    cfg_path = Path(_get_home_path()) / "config.json"
    checks.append(("config.json", cfg_path.exists(), str(cfg_path),
                    "" if cfg_path.exists() else "Run: epic init"))

    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    api_ok  = bool(api_key)
    checks.append(("ANTHROPIC_API_KEY", api_ok,
                    f"sk-...{api_key[-4:]}" if api_ok else "Not set",
                    "" if api_ok else "export ANTHROPIC_API_KEY=your-key"))

    # PATH hint — most common first-run issue after pipx install
    import shutil
    epic_in_path = bool(shutil.which("epic"))
    _path_hint = (
        ""
        if epic_in_path
        else "Run: pipx ensurepath  then: source ~/.bashrc  (or restart terminal)"
    )
    checks.append(("epic in PATH", epic_in_path,
                    shutil.which("epic") or "not found",
                    _path_hint))

    try:
        from epic_claude.migrations.runner import needs_migration, CURRENT_REGISTRY_SCHEMA
        from epic_claude.registry import REGISTRY_DB_PATH
        mig = REGISTRY_DB_PATH.exists() and needs_migration(REGISTRY_DB_PATH, CURRENT_REGISTRY_SCHEMA)
        checks.append(("Schema versions", not mig,
                        f"v{CURRENT_REGISTRY_SCHEMA}",
                        "Run: epic system migrate" if mig else ""))
    except Exception:
        pass

    if _RICH:
        table = Table(title="epic health check", show_header=True, header_style="bold")
        table.add_column("Check",  style="dim")
        table.add_column("Status")
        table.add_column("Detail")
        for label, ok, detail, hint in checks:
            colour = "green" if ok else ("yellow" if hint else "red")
            status = "[green]✓ OK[/green]" if ok else f"[{colour}]⚠  {hint or 'FAIL'}[/{colour}]"
            table.add_row(label, status, detail)
        console.print(table)
    else:
        for label, ok, detail, hint in checks:
            print(f"  {'OK' if ok else 'FAIL'}  {label}: {detail}  {hint}")

    if not py_ok:
        err_console.print("Python 3.11+ is required.")
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# Callback — global flags + first-run UX
# ---------------------------------------------------------------------------

@app.callback(invoke_without_command=True)
def _callback(
    ctx:        typer.Context,
    quiet:      bool = typer.Option(False, "--quiet",      "-q",  help="Suppress decorative output."),
    json_out:   bool = typer.Option(False, "--json",               help="Raw JSON output."),
    project_id: str  = typer.Option(None,  "--project-id",         help="Override project detection."),
) -> None:
    """epic — AI Architecture Control Plane for Claude Code."""
    try:
        from epic_claude.cli.output import set_json_mode, set_quiet_mode
        set_json_mode(json_out)
        set_quiet_mode(quiet)
    except Exception:
        pass

    if not _home_is_initialised():
        _bootstrap_home()

    if ctx.invoked_subcommand is None:
        _show_onboarding()


def _show_onboarding() -> None:
    """Guided entry point — shown on bare 'epic' invocation."""
    initialised = _home_is_initialised()
    import os
    has_key     = bool(os.environ.get("ANTHROPIC_API_KEY"))

    if _RICH:
        if not initialised:
            console.print(Panel(
                f"[bold]EPIC — AI Architecture Control Plane[/bold]  [dim]v{__version__}[/dim]\n\n"
                "[bold]Get started in 3 steps:[/bold]\n\n"
                "  [bold cyan]1.[/bold cyan]  epic init\n"
                "  [bold cyan]2.[/bold cyan]  export ANTHROPIC_API_KEY=your-key\n"
                "  [bold cyan]3.[/bold cyan]  epic plan \"describe your project\"\n\n"
                "[dim]epic --help  →  full command reference[/dim]",
                border_style="cyan",
            ))
        else:
            steps = []
            if not has_key:
                steps.append("  [yellow]⚠[/yellow]  export ANTHROPIC_API_KEY=your-key")
            steps.append("  [cyan]epic plan \"describe your project\"[/cyan]   → start a new project")
            steps.append("  [cyan]epic status[/cyan]                          → check active project")
            steps.append("  [cyan]epic sync[/cyan]                            → sync to CLAUDE.md")
            steps.append("  [cyan]epic --help[/cyan]                          → all commands")

            console.print(Panel(
                f"[bold]EPIC[/bold]  [dim]v{__version__} — ready[/dim]\n\n"
                + "\n".join(steps)
                + f"\n\n[dim]State: {_get_home_path()}[/dim]",
                border_style="cyan",
            ))
    else:
        print(f"epic v{__version__}")
        if not initialised:
            print("Run: epic init  then  epic plan \"your project\"")
        elif not has_key:
            print("Set: export ANTHROPIC_API_KEY=your-key")
            print("Then: epic plan \"your project\"")
        else:
            print("Run: epic plan \"your project\"  or  epic --help")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    app()

if __name__ == "__main__":
    main()
