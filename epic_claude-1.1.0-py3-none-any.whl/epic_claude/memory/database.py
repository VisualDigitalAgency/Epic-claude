"""
EPIC-Claude SQLite connection management.

Handles both databases:
  - registry.db  — global project index  (Tier 4)
  - memory.db    — per-project decisions  (Tier 1)

PRD §10 / §18 database requirements:
  - WAL mode:            PRAGMA journal_mode=WAL
  - Sync safety:         PRAGMA synchronous=NORMAL
  - FK enforcement:      PRAGMA foreign_keys=ON
  - All writes inside transactions (enforced by callers)
  - check_same_thread=False with application-level write lock
  - mode 600 on both db files (owner read/write only)

PRD §18 performance:
  - memory_recall (FTS query) < 100ms
"""

from __future__ import annotations

import sqlite3
import stat
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

from epic_claude.server.logging import get_logger

logger = get_logger(__name__)

# Application-level write lock — one writer at a time per db file (PRD §18)
_write_locks: dict[str, threading.Lock] = {}
_lock_registry = threading.Lock()


def _get_write_lock(db_path: str) -> threading.Lock:
    with _lock_registry:
        if db_path not in _write_locks:
            _write_locks[db_path] = threading.Lock()
        return _write_locks[db_path]


# ---------------------------------------------------------------------------
# Connection factory
# ---------------------------------------------------------------------------

def open_db(db_path: Path, *, create: bool = False) -> sqlite3.Connection:
    """
    Open a SQLite connection with all required PRAGMAs applied.

    Args:
        db_path: Absolute path to the .db file.
        create:  If True, create parent directories (used for new DBs).

    Returns:
        sqlite3.Connection with WAL, foreign_keys, and synchronous set.

    Raises:
        FileNotFoundError: if db_path doesn't exist and create=False.
        sqlite3.Error: on any database-level failure.
    """
    if create:
        db_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    elif not db_path.exists():
        raise FileNotFoundError(f"Database not found: {db_path}")

    conn = sqlite3.connect(
        str(db_path),
        check_same_thread=False,   # guarded by application-level write lock
        isolation_level=None,      # autocommit off — we control transactions
        detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES,
    )
    conn.row_factory = sqlite3.Row  # dict-like rows

    # Apply required PRAGMAs (PRD §10, §18)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA foreign_keys=ON")

    # Enforce mode 600 on the db file (PRD §18 Security)
    _enforce_db_permissions(db_path)

    logger.debug("Opened db: %s", db_path)
    return conn


@contextmanager
def transaction(conn: sqlite3.Connection, db_path: str) -> Generator[sqlite3.Connection, None, None]:
    """
    Context manager for a serialised write transaction.

    - Acquires the per-db application-level write lock
    - Opens a SQLite transaction (BEGIN)
    - Commits on clean exit, rolls back on any exception
    - PRD invariant: all writes inside transactions — partial writes impossible

    Usage:
        with transaction(conn, str(db_path)) as conn:
            conn.execute("INSERT INTO ...")
    """
    lock = _get_write_lock(db_path)
    with lock:
        conn.execute("BEGIN")
        try:
            yield conn
            conn.execute("COMMIT")
        except Exception:
            conn.execute("ROLLBACK")
            raise


@contextmanager
def read_only(conn: sqlite3.Connection) -> Generator[sqlite3.Connection, None, None]:
    """
    Context manager for a read-only query (no lock needed, WAL allows concurrent reads).
    """
    yield conn


# ---------------------------------------------------------------------------
# Schema bootstrap
# ---------------------------------------------------------------------------

def bootstrap_registry_db(db_path: Path) -> None:
    """
    Create registry.db and apply the registry table schema.
    Safe to call multiple times (IF NOT EXISTS).
    """
    stmts = _load_section("registry.db")
    conn = open_db(db_path, create=True)
    try:
        with transaction(conn, str(db_path)):
            for stmt in stmts:
                conn.execute(stmt)
        logger.info("Registry DB bootstrapped: %s", db_path)
    finally:
        conn.close()


def bootstrap_memory_db(db_path: Path) -> None:
    """
    Create memory.db for a project and apply all per-project table schemas.
    Safe to call multiple times (IF NOT EXISTS).
    """
    stmts = _load_section("memory.db")
    conn = open_db(db_path, create=True)
    try:
        with transaction(conn, str(db_path)):
            for stmt in stmts:
                conn.execute(stmt)
        logger.info("Memory DB bootstrapped: %s", db_path)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Schema introspection helpers
# ---------------------------------------------------------------------------

def get_tables(conn: sqlite3.Connection) -> list[str]:
    """Return list of all user-created table names in the database."""
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchall()
    return [r["name"] for r in rows]


def get_triggers(conn: sqlite3.Connection) -> list[str]:
    """Return list of all trigger names in the database."""
    rows = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='trigger'"
    ).fetchall()
    return [r["name"] for r in rows]


def db_exists(db_path: Path) -> bool:
    return db_path.exists() and db_path.stat().st_size > 0


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _load_section(db_name: str) -> list[str]:
    """
    Load and parse SQL statements for a specific database section from schema.sql.

    The schema.sql file has two sections separated by header comments:
      -- registry.db — GLOBAL ...
      -- memory.db — PER-PROJECT ...

    We collect all lines after our section header and before the next
    section header, then split on statement boundaries respecting
    BEGIN...END trigger blocks.

    Args:
        db_name: "registry.db" or "memory.db"
    """
    import re as _re

    schema_path = Path(__file__).parent / "schema.sql"
    lines = schema_path.read_text(encoding="utf-8").splitlines()

    # Find section start: a comment line containing our db_name AND "GLOBAL" or "PER-PROJECT"
    section_keywords = {"registry.db": "GLOBAL", "memory.db": "PER-PROJECT"}
    keyword = section_keywords[db_name]

    section_lines: list[str] = []
    in_section = False

    for line in lines:
        if not in_section:
            # Start capturing when we see our section header
            if db_name in line and keyword in line:
                in_section = True
            continue

        # Stop when we hit the OTHER section's header
        other = "memory.db" if db_name == "registry.db" else "registry.db"
        other_kw = section_keywords[other]
        if other in line and other_kw in line:
            break

        section_lines.append(line)

    return _split_statements("\n".join(section_lines))


def _split_statements(sql: str) -> list[str]:
    """
    Split SQL text into individual executable statements.

    Handles CREATE TRIGGER bodies which contain semicolons inside BEGIN...END.
    Uses word-boundary regex to count BEGIN/END tokens per line, tracking
    depth so internal semicolons don't prematurely end a statement.
    """
    import re as _re

    statements: list[str] = []
    current: list[str] = []
    begin_depth: int = 0

    for line in sql.splitlines():
        raw = line.strip()

        # Skip blank lines and comments between statements (not inside one)
        if not current and (not raw or raw.startswith("--")):
            continue

        current.append(line)
        upper = raw.upper()

        # Count BEGIN and END word tokens on this line
        begin_depth += len(_re.findall(r'\bBEGIN\b', upper))
        begin_depth -= len(_re.findall(r'\bEND\b', upper))
        begin_depth = max(0, begin_depth)

        # Statement boundary: ends with ";" and not inside a trigger body
        if raw.endswith(";") and begin_depth == 0:
            stmt = "\n".join(current).strip()
            if stmt:
                statements.append(stmt)
            current = []

    # Flush any final statement without trailing semicolon
    if current:
        stmt = "\n".join(current).strip()
        if stmt:
            statements.append(stmt)

    return statements


def _enforce_db_permissions(db_path: Path) -> None:
    """Enforce mode 600 on db file and WAL sidecar files."""
    for suffix in ["", "-wal", "-shm"]:
        p = Path(str(db_path) + suffix)
        if p.exists():
            current = stat.S_IMODE(p.stat().st_mode)
            if current != 0o600:
                try:
                    p.chmod(0o600)
                except OSError:
                    pass  # Windows or permission issue — non-fatal
