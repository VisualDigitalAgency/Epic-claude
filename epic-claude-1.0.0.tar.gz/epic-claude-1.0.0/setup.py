from setuptools import setup, find_packages
setup(
    name="epic-claude",
    version="1.0.0",
    packages=find_packages(),
    entry_points={"console_scripts": ["epic-claude=epic_claude.main:app"]},
    python_requires=">=3.11",
    install_requires=[
        "typer[all]>=0.12.0",
        "rich>=13.0.0",
        "pydantic>=2.0.0",
        "pydantic-settings>=2.0.0",
        "httpx>=0.27.0",
        "anthropic>=0.25.0",
        "sqlglot>=23.0.0",
        "openapi-spec-validator>=0.7.0",
        "jinja2>=3.1.0",
        "aiosqlite>=0.19.0",
        "alembic>=1.13.0",
        "mcp>=1.0.0",
    ],
)
