-- ============================================================
-- EPIC-Claude — Canonical Database Schema
-- PRD §12 — Two Databases
--
-- registry.db  → Tier 4: project identity index
-- memory.db    → Tier 1: all decisions, artifacts, memory
--
-- Both use SQLite WAL mode. All PKs are UUID TEXT.
-- All timestamps UTC ISO 8601.
-- ============================================================

-- ============================================================
-- registry.db — GLOBAL (one file at ~/.epic-claude/registry.db)
-- ============================================================

CREATE TABLE IF NOT EXISTS registry (
    id                      TEXT        PRIMARY KEY,
    name                    TEXT        NOT NULL,
    root_path               TEXT        NOT NULL UNIQUE,
    description             TEXT,
    project_type            TEXT,
    clarification_complete  INTEGER     NOT NULL DEFAULT 0,
    clarification_rounds    INTEGER     NOT NULL DEFAULT 0,
    stack_confirmed         INTEGER     NOT NULL DEFAULT 0,
    stack_confirmed_at      DATETIME,
    checklist_passed        INTEGER     NOT NULL DEFAULT 0,
    architect_generated     INTEGER     NOT NULL DEFAULT 0,
    architect_generated_at  DATETIME,
    generated_feature_count INTEGER     NOT NULL DEFAULT 0,
    last_sync_at            DATETIME,
    last_sync_state         TEXT,
    claude_md_path          TEXT,
    is_active               INTEGER     NOT NULL DEFAULT 1,
    created_at              DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    updated_at              DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE INDEX IF NOT EXISTS idx_registry_root_path      ON registry(root_path);
CREATE INDEX IF NOT EXISTS idx_registry_is_active      ON registry(is_active);
CREATE INDEX IF NOT EXISTS idx_registry_project_type   ON registry(project_type);
CREATE INDEX IF NOT EXISTS idx_registry_stack_confirmed ON registry(stack_confirmed);

-- Schema version tracking (used by migration runner)
CREATE TABLE IF NOT EXISTS schema_version (
    version         INTEGER     NOT NULL,
    applied_at      DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    description     TEXT
);

-- ============================================================
-- memory.db — PER-PROJECT (one per ~/.epic-claude/projects/<id>/)
-- ============================================================

CREATE TABLE IF NOT EXISTS clarification_sessions (
    id              TEXT        PRIMARY KEY,
    project_id      TEXT        NOT NULL,
    round           INTEGER     NOT NULL DEFAULT 1,
    status          TEXT        NOT NULL DEFAULT 'active',
    questions       TEXT        NOT NULL,
    answers         TEXT,
    confidence      TEXT,
    followup_asked  TEXT,
    followup_answers TEXT,
    assumptions     TEXT,
    is_sufficient   INTEGER     NOT NULL DEFAULT 0,
    started_at      DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    completed_at    DATETIME,
    UNIQUE(project_id, round)
);

CREATE INDEX IF NOT EXISTS idx_clarification_project_id ON clarification_sessions(project_id);
CREATE INDEX IF NOT EXISTS idx_clarification_status     ON clarification_sessions(status);

-- ----

CREATE TABLE IF NOT EXISTS tech_stack (
    id              TEXT        PRIMARY KEY,
    project_id      TEXT        NOT NULL,
    category        TEXT        NOT NULL,
    name            TEXT        NOT NULL,
    version         TEXT,
    rationale       TEXT        NOT NULL,
    alternatives    TEXT,
    confirmed       INTEGER     NOT NULL DEFAULT 0,
    confirmed_at    DATETIME,
    adjusted        INTEGER     NOT NULL DEFAULT 0,
    adjusted_from   TEXT,
    created_at      DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    updated_at      DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    UNIQUE(project_id, category)
);

CREATE INDEX IF NOT EXISTS idx_tech_stack_project_id ON tech_stack(project_id);
CREATE INDEX IF NOT EXISTS idx_tech_stack_category   ON tech_stack(category);
CREATE INDEX IF NOT EXISTS idx_tech_stack_confirmed  ON tech_stack(confirmed);

-- ----

CREATE TABLE IF NOT EXISTS checklist_results (
    id              TEXT        PRIMARY KEY,
    project_id      TEXT        NOT NULL,
    run_at          DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    project_type    TEXT        NOT NULL,
    deployment_target TEXT,
    auth_model      TEXT,
    scale_assumption TEXT,
    multi_tenancy   INTEGER,
    data_ownership  TEXT,
    assumptions_made TEXT,
    all_passed      INTEGER     NOT NULL DEFAULT 0,
    blocked_reason  TEXT
);

CREATE INDEX IF NOT EXISTS idx_checklist_project_id ON checklist_results(project_id);
CREATE INDEX IF NOT EXISTS idx_checklist_all_passed ON checklist_results(all_passed);

-- ----

CREATE TABLE IF NOT EXISTS features (
    id                  TEXT        PRIMARY KEY,
    project_id          TEXT        NOT NULL,
    feature_id          TEXT        NOT NULL,
    title               TEXT        NOT NULL,
    description         TEXT        NOT NULL,
    status              TEXT        NOT NULL DEFAULT 'planned',
    priority            TEXT        NOT NULL DEFAULT 'medium',
    depends_on          TEXT,
    acceptance_criteria TEXT,
    api_endpoints       TEXT,
    db_tables           TEXT,
    assumptions         TEXT,
    created_at          DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    updated_at          DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    UNIQUE(project_id, feature_id)
);

CREATE INDEX IF NOT EXISTS idx_features_project_id ON features(project_id);
CREATE INDEX IF NOT EXISTS idx_features_feature_id ON features(feature_id);
CREATE INDEX IF NOT EXISTS idx_features_status     ON features(status);
CREATE INDEX IF NOT EXISTS idx_features_priority   ON features(priority);

-- ----

CREATE TABLE IF NOT EXISTS artifacts (
    id              TEXT        PRIMARY KEY,
    project_id      TEXT        NOT NULL,
    feature_id      TEXT        REFERENCES features(id) ON DELETE SET NULL,
    artifact_type   TEXT        NOT NULL,
    title           TEXT        NOT NULL,
    content         TEXT        NOT NULL,
    content_format  TEXT        NOT NULL DEFAULT 'markdown',
    version         INTEGER     NOT NULL DEFAULT 1,
    is_current      INTEGER     NOT NULL DEFAULT 1,
    file_path       TEXT,
    checksum        TEXT        NOT NULL,
    validation_passed INTEGER   NOT NULL DEFAULT 0,
    validation_errors TEXT,
    created_at      DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    updated_at      DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE INDEX IF NOT EXISTS idx_artifacts_project_id ON artifacts(project_id);
CREATE INDEX IF NOT EXISTS idx_artifacts_type       ON artifacts(artifact_type);
CREATE INDEX IF NOT EXISTS idx_artifacts_is_current ON artifacts(is_current);
CREATE INDEX IF NOT EXISTS idx_artifacts_checksum   ON artifacts(checksum);
CREATE INDEX IF NOT EXISTS idx_artifacts_validation ON artifacts(validation_passed);

-- ----

CREATE TABLE IF NOT EXISTS sessions (
    id                  TEXT        PRIMARY KEY,
    project_id          TEXT        NOT NULL,
    task_description    TEXT,
    entries_written     INTEGER     NOT NULL DEFAULT 0,
    status              TEXT        NOT NULL DEFAULT 'active',
    started_at          DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    ended_at            DATETIME,
    ended_reason        TEXT
);

CREATE INDEX IF NOT EXISTS idx_sessions_project_id ON sessions(project_id);
CREATE INDEX IF NOT EXISTS idx_sessions_status     ON sessions(status);
CREATE INDEX IF NOT EXISTS idx_sessions_started_at ON sessions(started_at);

-- ----

CREATE TABLE IF NOT EXISTS memory_entries (
    id              TEXT        PRIMARY KEY,
    project_id      TEXT        NOT NULL,
    feature_id      TEXT        REFERENCES features(id) ON DELETE SET NULL,
    session_id      TEXT        REFERENCES sessions(id) ON DELETE SET NULL,
    entry_type      TEXT        NOT NULL,
    title           TEXT        NOT NULL,
    content         TEXT        NOT NULL,
    tags            TEXT,
    importance      TEXT        NOT NULL DEFAULT 'normal',
    confidence      TEXT        NOT NULL DEFAULT 'high',
    source          TEXT        NOT NULL DEFAULT 'agent',
    is_superseded   INTEGER     NOT NULL DEFAULT 0,
    superseded_by   TEXT        REFERENCES memory_entries(id),
    superseded_at   DATETIME,
    supersede_reason TEXT,
    created_at      DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    updated_at      DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE INDEX IF NOT EXISTS idx_memory_project_id    ON memory_entries(project_id);
CREATE INDEX IF NOT EXISTS idx_memory_entry_type    ON memory_entries(entry_type);
CREATE INDEX IF NOT EXISTS idx_memory_importance    ON memory_entries(importance);
CREATE INDEX IF NOT EXISTS idx_memory_confidence    ON memory_entries(confidence);
CREATE INDEX IF NOT EXISTS idx_memory_is_superseded ON memory_entries(is_superseded);
CREATE INDEX IF NOT EXISTS idx_memory_session_id    ON memory_entries(session_id);

-- FTS5 virtual table — PRD §13 EC-F005
-- content= makes this a content table (reads from memory_entries)
-- content_rowid= links FTS rowid to memory_entries rowid
CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
    title,
    content,
    tags,
    content='memory_entries',
    content_rowid='rowid'
);

-- Triggers to keep memory_fts in sync with memory_entries
CREATE TRIGGER IF NOT EXISTS memory_entries_ai
    AFTER INSERT ON memory_entries BEGIN
        INSERT INTO memory_fts(rowid, title, content, tags)
        VALUES (new.rowid, new.title, new.content, new.tags);
    END;

CREATE TRIGGER IF NOT EXISTS memory_entries_ad
    AFTER DELETE ON memory_entries BEGIN
        INSERT INTO memory_fts(memory_fts, rowid, title, content, tags)
        VALUES ('delete', old.rowid, old.title, old.content, old.tags);
    END;

CREATE TRIGGER IF NOT EXISTS memory_entries_au
    AFTER UPDATE ON memory_entries BEGIN
        INSERT INTO memory_fts(memory_fts, rowid, title, content, tags)
        VALUES ('delete', old.rowid, old.title, old.content, old.tags);
        INSERT INTO memory_fts(rowid, title, content, tags)
        VALUES (new.rowid, new.title, new.content, new.tags);
    END;

-- ----

CREATE TABLE IF NOT EXISTS sync_log (
    id                  TEXT        PRIMARY KEY,
    project_id          TEXT        NOT NULL,
    sync_state          TEXT        NOT NULL,
    claude_md_path      TEXT        NOT NULL,
    artifact_ids        TEXT        NOT NULL,
    memory_entry_ids    TEXT,
    section_start_line  INTEGER,
    section_end_line    INTEGER,
    content_hash        TEXT,
    backup_path         TEXT,
    triggered_by        TEXT        NOT NULL DEFAULT 'manual',
    duration_ms         INTEGER,
    error_detail        TEXT,
    synced_at           DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

CREATE INDEX IF NOT EXISTS idx_sync_log_project_id ON sync_log(project_id);
CREATE INDEX IF NOT EXISTS idx_sync_log_sync_state ON sync_log(sync_state);
CREATE INDEX IF NOT EXISTS idx_sync_log_synced_at  ON sync_log(synced_at);

-- Schema version tracking (used by migration runner)
CREATE TABLE IF NOT EXISTS schema_version (
    version         INTEGER     NOT NULL,
    applied_at      DATETIME    NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    description     TEXT
);
