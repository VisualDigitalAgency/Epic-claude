"""
EPIC-Claude exception hierarchy.

Every subsystem raises a specific subclass so callers can handle errors precisely.
All exceptions carry a user-facing message and a structured detail dict
for JSON-RPC error responses.
PRD §13 EC-F001 — error codes -32600 to -32603.
"""

from __future__ import annotations

from typing import Any


# ---------------------------------------------------------------------------
# Base
# ---------------------------------------------------------------------------

class EpicClaudeError(Exception):
    """Base class for all EPIC-Claude errors."""

    def __init__(self, message: str, detail: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.detail: dict[str, Any] = detail or {}

    def to_dict(self) -> dict[str, Any]:
        return {"message": self.message, "detail": self.detail}


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

class ConfigError(EpicClaudeError):
    """Raised when config.json is invalid or a credential is found in it."""


class EnvironmentError(EpicClaudeError):  # noqa: A001
    """Raised when a required environment variable (e.g. ANTHROPIC_API_KEY) is missing."""


# ---------------------------------------------------------------------------
# Registry / Project Detection
# ---------------------------------------------------------------------------

class RegistryError(EpicClaudeError):
    """Raised when registry.db operations fail."""


class ProjectNotFoundError(EpicClaudeError):
    """Raised when no project can be detected for the current working directory."""


class AmbiguousProjectError(EpicClaudeError):
    """Raised when project detection finds ambiguity (symlinks, nested, worktrees)."""


class ProjectAlreadyExistsError(EpicClaudeError):
    """Raised when trying to create a project that already exists in the registry."""


# ---------------------------------------------------------------------------
# Clarification Agent
# ---------------------------------------------------------------------------

class ClarificationError(EpicClaudeError):
    """Raised when clarification session encounters an unrecoverable problem."""


class ClarificationSessionNotFoundError(ClarificationError):
    """Raised when a session_id does not match any active clarification session."""


class ClarificationNotCompleteError(ClarificationError):
    """Raised when an operation requires clarification_complete=True but it is not."""


# ---------------------------------------------------------------------------
# Tech Stack Decider
# ---------------------------------------------------------------------------

class StackError(EpicClaudeError):
    """Raised when tech stack operations fail."""


class StackNotConfirmedError(StackError):
    """Raised when architect_generate is called before stack_confirmed=True."""


class StackAlreadyConfirmedError(StackError):
    """Raised when trying to adjust a locked stack without explicit override."""


# ---------------------------------------------------------------------------
# Architect Agent
# ---------------------------------------------------------------------------

class ArchitectError(EpicClaudeError):
    """Raised when the Architect Agent encounters a generation failure."""


class UnsupportedProjectTypeError(ArchitectError):
    """
    Raised when project type is not in SUPPORTED_PROJECT_TYPES.
    Agent declines gracefully — never a hard crash.
    """


class ChecklistFailedError(ArchitectError):
    """Raised when Gate 1 pre-generation checklist fails."""


# ---------------------------------------------------------------------------
# Validation Gates
# ---------------------------------------------------------------------------

class ValidationError(EpicClaudeError):
    """Base class for all validation gate failures."""

    def __init__(
        self,
        message: str,
        artifact_type: str,
        errors: list[str],
        detail: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, detail)
        self.artifact_type = artifact_type
        self.errors = errors

    def to_dict(self) -> dict[str, Any]:
        return {
            **super().to_dict(),
            "artifact_type": self.artifact_type,
            "errors": self.errors,
        }


class Gate1ValidationError(ValidationError):
    """Pre-generation checklist failed."""


class Gate2ValidationError(ValidationError):
    """Per-artifact validation failed."""


class Gate3ValidationError(ValidationError):
    """Post-write checksum mismatch."""


class NamespaceViolationError(EpicClaudeError):
    """
    Raised when EC-F and F prefixes are mixed.
    PRD §21 — this is a blocking violation.
    """


# ---------------------------------------------------------------------------
# Memory Bank
# ---------------------------------------------------------------------------

class MemoryError(EpicClaudeError):  # noqa: A001
    """Raised when memory.db operations fail."""


class MemoryEntryNotFoundError(MemoryError):
    """Raised when an entry_id does not exist in memory_entries."""


# ---------------------------------------------------------------------------
# Context Syncer
# ---------------------------------------------------------------------------

class SyncError(EpicClaudeError):
    """Raised when context_sync encounters a failure."""


class SyncBackupError(SyncError):
    """Raised when the backup step fails — triggers ABORTED state."""


class SyncWriteError(SyncError):
    """Raised when the write step fails — triggers RESTORING state."""


class SyncVerifyError(SyncError):
    """Raised when post-write checksum mismatch — triggers RESTORING state."""


class SyncRestoreError(SyncError):
    """
    Raised when the restore-from-backup step ALSO fails.
    Triggers FAILED state — requires manual intervention.
    """


# ---------------------------------------------------------------------------
# File I/O
# ---------------------------------------------------------------------------

class AtomicWriteError(EpicClaudeError):
    """Raised when atomic tmpfile → rename write fails."""


# ---------------------------------------------------------------------------
# LLM API
# ---------------------------------------------------------------------------

class LLMError(EpicClaudeError):
    """Raised when an LLM API call fails or times out."""


class LLMTimeoutError(LLMError):
    """Raised when LLM API call exceeds timeout threshold."""
