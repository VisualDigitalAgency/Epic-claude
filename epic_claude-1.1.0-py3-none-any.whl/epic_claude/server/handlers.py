"""
MCP protocol method handlers.

Handles the three MCP methods EPIC-Claude supports:
  - initialize          → MCP handshake, returns server info + capabilities
  - tools/list          → returns all registered tool definitions
  - tools/call          → dispatches to tool handler via Project Detection

Every handler receives a JsonRpcRequest and returns a JsonRpcResponse
or JsonRpcErrorResponse. All logic is synchronous at this layer;
tool handlers themselves are async (awaited by the server loop).

PRD §13 EC-F001 acceptance criteria:
  ✓ MCP initialize handshake
  ✓ tools/list returns full input schemas
  ✓ tools/call routes via Project Detection Protocol
  ✓ id field always included in responses
  ✓ Error codes -32600 to -32603
"""

from __future__ import annotations

import asyncio
from typing import Any

from epic_claude.server.logging import get_logger
from epic_claude.server.protocol import (
    JsonRpcErrorResponse,
    JsonRpcRequest,
    JsonRpcResponse,
    McpCapabilities,
    McpServerInfo,
    MCP_PROTOCOL_VERSION,
    internal_error,
    invalid_params,
    method_not_found,
)
from epic_claude.server.tools import TOOL_REGISTRY, dispatch

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Initialize handshake
# ---------------------------------------------------------------------------

async def handle_initialize(req: JsonRpcRequest) -> JsonRpcResponse | JsonRpcErrorResponse:
    """
    MCP initialize handshake.
    PRD §18 perf target: < 200ms (no LLM call).
    """
    logger.info("MCP initialize | client_params=%s", req.params)

    result = {
        "protocolVersion": MCP_PROTOCOL_VERSION,
        "serverInfo": McpServerInfo().to_dict(),
        "capabilities": McpCapabilities().to_dict(),
    }
    return JsonRpcResponse(id=req.id, result=result)


async def handle_initialized(req: JsonRpcRequest) -> JsonRpcResponse | JsonRpcErrorResponse:
    """MCP initialized notification — no response required (notification)."""
    logger.info("MCP initialized notification received")
    # Notifications have no id — we don't send a response but return a placeholder
    return JsonRpcResponse(id=req.id, result=None)


# ---------------------------------------------------------------------------
# tools/list
# ---------------------------------------------------------------------------

async def handle_tools_list(req: JsonRpcRequest) -> JsonRpcResponse | JsonRpcErrorResponse:
    """
    Return all registered MCP tool definitions.
    PRD §13 EC-F001: tools/list returns all registered tools with full input schemas.
    """
    logger.debug("tools/list called | tool_count=%d", len(TOOL_REGISTRY))
    return JsonRpcResponse(
        id=req.id,
        result={"tools": TOOL_REGISTRY.list_all()},
    )


# ---------------------------------------------------------------------------
# tools/call
# ---------------------------------------------------------------------------

async def handle_tools_call(req: JsonRpcRequest) -> JsonRpcResponse | JsonRpcErrorResponse:
    """
    Route a tools/call request to the correct tool handler.

    PRD §13 EC-F001:
      - Routes via Project Detection Protocol
      - Returns structured error if tool not found or params invalid
    """
    params = req.params or {}
    tool_name = params.get("name")
    tool_args  = params.get("arguments") or {}

    if not tool_name or not isinstance(tool_name, str):
        return invalid_params(req.id, "Missing required field: 'name'")

    if tool_name not in TOOL_REGISTRY:
        logger.warning("tools/call: unknown tool requested: %s", tool_name)
        return method_not_found(req.id, tool_name)

    logger.info("tools/call: %s | args=%s", tool_name, list(tool_args.keys()))

    try:
        result = await dispatch(tool_name, tool_args)
        return JsonRpcResponse(id=req.id, result=result)

    except KeyError as exc:
        # No handler registered yet (feature not yet built)
        logger.warning("tools/call: no handler for %s: %s", tool_name, exc)
        return internal_error(
            req.id,
            f"Tool '{tool_name}' is registered but has no handler. "
            "This feature may not be built yet.",
        )
    except TypeError as exc:
        logger.warning("tools/call: invalid params for %s: %s", tool_name, exc)
        return invalid_params(req.id, str(exc))
    except Exception as exc:  # noqa: BLE001
        logger.exception("tools/call: unhandled error in %s: %s", tool_name, exc)
        return internal_error(req.id, f"Unhandled error: {type(exc).__name__}: {exc}")


# ---------------------------------------------------------------------------
# ping (useful for health checks)
# ---------------------------------------------------------------------------

async def handle_ping(req: JsonRpcRequest) -> JsonRpcResponse | JsonRpcErrorResponse:
    return JsonRpcResponse(id=req.id, result={"pong": True})


# ---------------------------------------------------------------------------
# Method dispatch table
# ---------------------------------------------------------------------------

METHOD_HANDLERS: dict[
    str,
    Any,  # Callable[[JsonRpcRequest], Awaitable[JsonRpcResponse | JsonRpcErrorResponse]]
] = {
    "initialize":       handle_initialize,
    "notifications/initialized": handle_initialized,
    "tools/list":       handle_tools_list,
    "tools/call":       handle_tools_call,
    "ping":             handle_ping,
}


async def dispatch_method(
    req: JsonRpcRequest,
) -> JsonRpcResponse | JsonRpcErrorResponse | None:
    """
    Dispatch a JSON-RPC request to the correct handler.

    Returns:
        Response object, or None if the request is a notification
        that should not be responded to.
    """
    # Notifications (no id) — handle side-effects but NEVER send a response.
    # JSON-RPC 2.0 spec: absent id = notification, server MUST NOT reply.
    if req.is_notification:
        logger.debug("Notification received (no response): %s", req.method)
        handler = METHOD_HANDLERS.get(req.method)
        if handler:
            await handler(req)
        return None

    handler = METHOD_HANDLERS.get(req.method)
    if handler is None:
        logger.warning("Method not found: %s", req.method)
        return method_not_found(req.id, req.method)

    return await handler(req)
