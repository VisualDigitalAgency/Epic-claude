"""
CLAUDE.md managed section operations — EC-F006.

Handles reading, writing, and detecting the EPIC-Claude managed section
inside a project's CLAUDE.md file.

PRD §17 rules (non-negotiable):
  - Write ONLY to the managed section — never touch anything outside it
  - If CLAUDE.md doesn't exist → create with managed section only
  - If exists, no section → append to end
  - If exists, has section → replace ONLY that section
  - Content outside section: never read, never modified, never deleted
  - Manual edit detection via SHA256 hash comparison

Managed section markers (PRD §17):
  <!-- EPIC-CLAUDE-MANAGED-START | version:4 | synced:<iso> | hash:<sha256> -->
  ...content...
  <!-- EPIC-CLAUDE-MANAGED-END -->
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from epic_claude.server.logging import get_logger

logger = get_logger(__name__)

# Marker templates — must match PRD §17 exactly
MANAGED_START_PREFIX = "<!-- EPIC-CLAUDE-MANAGED-START"
MANAGED_END_MARKER   = "<!-- EPIC-CLAUDE-MANAGED-END -->"

START_PATTERN = re.compile(
    r"<!-- EPIC-CLAUDE-MANAGED-START[^>]*-->",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class ManagedSection:
    """Represents a parsed managed section from CLAUDE.md."""
    start_line: int       # 1-indexed line number of the START marker
    end_line: int         # 1-indexed line number of the END marker
    content: str          # Full section content including markers
    inner_content: str    # Content between markers (excluding marker lines)
    content_hash: str     # SHA256 of inner_content
    synced_at: str | None
    version: str | None


@dataclass
class SectionWriteResult:
    start_line: int
    end_line: int
    content_hash: str
    created_new: bool     # True if CLAUDE.md was newly created
    appended: bool        # True if section was appended (no prior section)
    replaced: bool        # True if existing section was replaced


# ---------------------------------------------------------------------------
# Parse managed section from CLAUDE.md
# ---------------------------------------------------------------------------

def find_managed_section(content: str) -> ManagedSection | None:
    """
    Find and parse the managed section in CLAUDE.md content.
    Returns None if no managed section found.
    """
    lines = content.splitlines(keepends=True)

    start_idx: int | None = None
    end_idx: int | None = None

    for i, line in enumerate(lines):
        if MANAGED_START_PREFIX in line:
            start_idx = i
        elif MANAGED_END_MARKER in line and start_idx is not None:
            end_idx = i
            break

    if start_idx is None or end_idx is None:
        return None

    # Extract inner content (between markers, exclusive)
    inner_lines = lines[start_idx + 1 : end_idx]
    inner_content = "".join(inner_lines)
    full_section  = "".join(lines[start_idx : end_idx + 1])

    # Parse metadata from start marker
    start_line_text = lines[start_idx]
    synced_at = _parse_marker_field(start_line_text, "synced")
    version   = _parse_marker_field(start_line_text, "version")

    return ManagedSection(
        start_line=start_idx + 1,      # 1-indexed
        end_line=end_idx + 1,          # 1-indexed
        content=full_section,
        inner_content=inner_content,
        content_hash=sha256(inner_content),
        synced_at=synced_at,
        version=version,
    )


def detect_manual_edit(
    current_content: str,
    last_logged_hash: str | None,
) -> bool:
    """
    Returns True if the managed section has been manually edited since last sync.
    Compares SHA256 of current inner content against last logged hash.
    """
    if last_logged_hash is None:
        return False

    section = find_managed_section(current_content)
    if section is None:
        return False

    return section.content_hash != last_logged_hash


# ---------------------------------------------------------------------------
# Write managed section
# ---------------------------------------------------------------------------

def write_managed_section(
    claude_md_path: Path,
    section_content: str,
) -> SectionWriteResult:
    """
    Write the managed section to CLAUDE.md.

    PRD §17 rules:
      - CLAUDE.md doesn't exist   → create with section only
      - exists, no section        → append to end
      - exists, has section       → replace ONLY that section

    Args:
        claude_md_path: Full path to CLAUDE.md.
        section_content: The full managed section text (including markers).

    Returns:
        SectionWriteResult with line numbers and hash.
    """
    created_new = False
    appended    = False
    replaced    = False

    if not claude_md_path.exists():
        # Create new file with section only
        claude_md_path.parent.mkdir(parents=True, exist_ok=True)
        claude_md_path.write_text(section_content + "\n", encoding="utf-8")
        created_new = True
        start, end = _find_section_lines(section_content, section_content + "\n")
    else:
        existing = claude_md_path.read_text(encoding="utf-8")
        existing_section = find_managed_section(existing)

        if existing_section is None:
            # Append to end — ensure newline separation
            separator = "\n" if existing.endswith("\n") else "\n\n"
            new_content = existing + separator + section_content + "\n"
            claude_md_path.write_text(new_content, encoding="utf-8")
            appended = True
            start, end = _find_section_lines(section_content, new_content)
        else:
            # Replace ONLY the managed section
            lines = existing.splitlines(keepends=True)
            before = lines[:existing_section.start_line - 1]
            after  = lines[existing_section.end_line:]
            new_lines = before + [section_content + "\n"] + after
            new_content = "".join(new_lines)
            claude_md_path.write_text(new_content, encoding="utf-8")
            replaced = True
            start, end = _find_section_lines(section_content, new_content)

    # Compute hash of inner content (between markers)
    inner = _extract_inner_content(section_content)
    content_hash = sha256(inner)

    logger.debug(
        "Managed section written | created=%s appended=%s replaced=%s | lines=%d-%d",
        created_new, appended, replaced, start, end,
    )

    return SectionWriteResult(
        start_line=start,
        end_line=end,
        content_hash=content_hash,
        created_new=created_new,
        appended=appended,
        replaced=replaced,
    )


def read_managed_section(claude_md_path: Path) -> ManagedSection | None:
    """Read and parse the managed section from CLAUDE.md. Returns None if not found."""
    if not claude_md_path.exists():
        return None
    return find_managed_section(claude_md_path.read_text(encoding="utf-8"))


def build_managed_section(inner_content: str) -> str:
    """
    Build the full managed section string including start/end markers.

    PRD §17 format:
        <!-- EPIC-CLAUDE-MANAGED-START | version:4 | synced:<iso> | hash:<sha256> -->
        <inner_content>
        <!-- EPIC-CLAUDE-MANAGED-END -->
    """
    now = datetime.now(timezone.utc).isoformat()
    content_hash = sha256(inner_content)
    start_marker = (
        f"<!-- EPIC-CLAUDE-MANAGED-START | version:4 | "
        f"synced:{now} | hash:{content_hash[:8]} -->"
    )
    return f"{start_marker}\n{inner_content}\n{MANAGED_END_MARKER}"


# ---------------------------------------------------------------------------
# Verify written content (Gate 3 equivalent for sync)
# ---------------------------------------------------------------------------

def verify_section_written(
    claude_md_path: Path,
    expected_hash: str,
) -> None:
    """
    Re-read CLAUDE.md and verify the managed section hash matches expected.
    Raises SyncVerifyError on mismatch.
    """
    from epic_claude.exceptions import SyncVerifyError

    if not claude_md_path.exists():
        raise SyncVerifyError(
            f"CLAUDE.md missing after write: {claude_md_path}",
            detail={"path": str(claude_md_path)},
        )

    content = claude_md_path.read_text(encoding="utf-8")
    section = find_managed_section(content)

    if section is None:
        raise SyncVerifyError(
            "Managed section not found in CLAUDE.md after write",
            detail={"path": str(claude_md_path)},
        )

    if section.content_hash != expected_hash:
        raise SyncVerifyError(
            f"Sync checksum mismatch: expected {expected_hash[:12]}, "
            f"got {section.content_hash[:12]}",
            detail={
                "expected": expected_hash,
                "actual": section.content_hash,
                "path": str(claude_md_path),
            },
        )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _parse_marker_field(marker_line: str, field: str) -> str | None:
    """Extract a field value from a start marker line."""
    pattern = re.compile(rf"{re.escape(field)}:([^\s|>]+)")
    match = pattern.search(marker_line)
    return match.group(1).strip() if match else None


def _find_section_lines(section_content: str, full_content: str) -> tuple[int, int]:
    """Find 1-indexed start and end line numbers of the section in the full file."""
    lines = full_content.splitlines()
    section_lines = section_content.splitlines()
    if not section_lines:
        return 1, 1

    first_line = section_lines[0].strip()
    last_line  = section_lines[-1].strip()

    start = end = 1
    for i, line in enumerate(lines):
        if line.strip() == first_line:
            start = i + 1
        if line.strip() == last_line and i + 1 >= start:
            end = i + 1
            break

    return start, end


def _extract_inner_content(section: str) -> str:
    """Extract the content between managed section markers."""
    lines = section.splitlines(keepends=True)
    inner: list[str] = []
    in_section = False
    for line in lines:
        if MANAGED_START_PREFIX in line:
            in_section = True
            continue
        if MANAGED_END_MARKER in line:
            break
        if in_section:
            inner.append(line)
    return "".join(inner)


def sha256(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()
