"""
EPIC-Claude template renderers.

  claude_md.render_managed_section()  — CLAUDE.md managed section inner content
  claude_md.render_recall_context()   — task-scoped context recall text
"""

from epic_claude.templates.claude_md import render_managed_section, render_recall_context

__all__ = ["render_managed_section", "render_recall_context"]
