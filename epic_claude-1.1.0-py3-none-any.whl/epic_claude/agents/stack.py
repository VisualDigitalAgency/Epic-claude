"""
EC-F003 — Tech Stack Decider.

After clarification completes, proposes the optimal tech stack.
Every decision includes rationale and alternatives considered.
User must explicitly confirm — architect_generate is blocked until then.

PRD §13 EC-F003 acceptance criteria:
  ✓ stack_decide blocked until clarification_complete=True
  ✓ Proposes: language, framework, database, auth, deployment, testing, CI/CD
  ✓ Each proposal: name, version, rationale, alternatives array
  ✓ stack_confirm locks all entries, sets confirmed=1 and confirmed_at
  ✓ stack_adjust changes one category, sets adjusted=1
  ✓ architect_generate blocked until stack_confirmed=True
  ✓ Stack written to tech_stack table in memory.db
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from epic_claude.agents.clarification import get_session_for_project
from epic_claude.agents.llm import LLMClient, get_llm_client
from epic_claude.agents.prompts import (
    STACK_SYSTEM,
    build_stack_propose_prompt,
    format_answers_summary,
)
from epic_claude.exceptions import (
    ClarificationNotCompleteError,
    StackAlreadyConfirmedError,
    StackNotConfirmedError,
)
from epic_claude.memory.database import open_db, transaction
from epic_claude.memory.registry_store import RegistryStore
from epic_claude.server.logging import get_logger

logger = get_logger(__name__)

# Required stack categories — all must be present for Gate 2 validation
REQUIRED_CATEGORIES = {"language", "framework", "database", "auth", "deployment", "testing"}
OPTIONAL_CATEGORIES = {"cache", "cicd"}
ALL_CATEGORIES = REQUIRED_CATEGORIES | OPTIONAL_CATEGORIES


# ---------------------------------------------------------------------------
# Core agent operations
# ---------------------------------------------------------------------------

async def propose_stack(
    project_id: str,
    project_name: str,
    description: str,
    registry_db_path: Path,
    memory_db_path: Path,
    llm: LLMClient | None = None,
) -> dict[str, Any]:
    """
    EC-F003: Generate tech stack proposal from clarification answers.

    PRD AC: blocked until clarification_complete=True.

    Returns:
        {stack, summary, assumptions, categories}
    """
    if llm is None:
        llm = get_llm_client()

    # Gate: clarification must be complete
    registry = RegistryStore(registry_db_path)
    registry.open()
    try:
        project = registry.require_by_id(project_id)
        if not project.clarification_complete:
            raise ClarificationNotCompleteError(
                "Cannot decide stack: clarification is not complete.",
                detail={"project_id": project_id},
            )
        project_type = project.project_type or "unknown"
    finally:
        registry.close()

    # Get answers from in-memory clarification state
    clarification_state = get_session_for_project(project_id)
    if clarification_state:
        answers = clarification_state.answers
        assumptions = clarification_state.assumptions
    else:
        # Reload from DB if not in memory
        answers, assumptions = _load_answers_from_db(project_id, memory_db_path)

    answers_summary = format_answers_summary(answers, assumptions)

    logger.info("Proposing stack | project=%s | type=%s", project_id, project_type)

    # Call LLM
    response = await llm.complete_json(
        system=STACK_SYSTEM,
        user=build_stack_propose_prompt(
            name=project_name,
            project_type=project_type,
            description=description,
            answers_summary=answers_summary,
        ),
    )

    stack = response.get("stack", {})
    summary = response.get("summary", "")
    stack_assumptions = response.get("assumptions", [])

    # Persist proposed stack to tech_stack table
    _persist_stack(
        project_id=project_id,
        stack=stack,
        memory_db_path=memory_db_path,
        confirmed=False,
    )

    logger.info(
        "Stack proposed | project=%s | categories=%s",
        project_id, list(stack.keys()),
    )

    return {
        "project_id": project_id,
        "stack": stack,
        "summary": summary,
        "assumptions": stack_assumptions,
        "categories": list(stack.keys()),
        "confirmed": False,
    }


def confirm_stack(
    project_id: str,
    registry_db_path: Path,
    memory_db_path: Path,
) -> dict[str, Any]:
    """
    EC-F003: Lock the proposed tech stack.
    Sets confirmed=1 and confirmed_at on all tech_stack entries.
    Updates registry: stack_confirmed=True.

    PRD AC: blocks architect_generate until called.
    """
    now = _utcnow()

    conn = open_db(memory_db_path)
    try:
        with transaction(conn, str(memory_db_path)):
            conn.execute(
                "UPDATE tech_stack SET confirmed=1, confirmed_at=?, updated_at=? WHERE project_id=?",
                (now, now, project_id),
            )
        rows = conn.execute(
            "SELECT * FROM tech_stack WHERE project_id=?", (project_id,)
        ).fetchall()
    finally:
        conn.close()

    # Update registry
    registry = RegistryStore(registry_db_path)
    registry.open()
    try:
        registry.update_fields(
            project_id,
            stack_confirmed=True,
            stack_confirmed_at=now,
        )
    finally:
        registry.close()

    stack = _rows_to_stack(rows)
    logger.info("Stack confirmed | project=%s | categories=%s", project_id, list(stack.keys()))

    return {
        "project_id": project_id,
        "confirmed": True,
        "confirmed_at": now,
        "stack": stack,
    }


def adjust_stack(
    project_id: str,
    category: str,
    name: str,
    rationale: str,
    memory_db_path: Path,
    version: str = "",
) -> dict[str, Any]:
    """
    EC-F003: Change one stack category. Sets adjusted=1.
    Does not require re-running clarification.
    """
    if category not in ALL_CATEGORIES:
        raise ValueError(
            f"Invalid category: {category!r}. "
            f"Must be one of: {sorted(ALL_CATEGORIES)}"
        )

    now = _utcnow()
    conn = open_db(memory_db_path)
    try:
        # Get existing entry
        existing = conn.execute(
            "SELECT * FROM tech_stack WHERE project_id=? AND category=?",
            (project_id, category),
        ).fetchone()

        adjusted_from = existing["name"] if existing else None

        with transaction(conn, str(memory_db_path)):
            # Preserve the existing confirmed status
            existing_confirmed = existing["confirmed"] if existing else 0
            conn.execute(
                """
                INSERT OR REPLACE INTO tech_stack (
                    id, project_id, category, name, version,
                    rationale, alternatives, confirmed, confirmed_at,
                    adjusted, adjusted_from, created_at, updated_at
                ) VALUES (
                    COALESCE((SELECT id FROM tech_stack WHERE project_id=? AND category=?), ?),
                    ?, ?, ?, ?,
                    ?, ?,
                    ?,
                    COALESCE((SELECT confirmed_at FROM tech_stack WHERE project_id=? AND category=?), NULL),
                    1, ?, ?, ?
                )
                """,
                (
                    project_id, category,     # for COALESCE id
                    str(uuid.uuid4()),         # new id if not exists
                    project_id, category, name, version,
                    rationale, "[]",
                    existing_confirmed,        # preserve confirmed=1 if already confirmed
                    project_id, category,     # for COALESCE confirmed_at
                    adjusted_from, now, now,
                ),
            )
        row = conn.execute(
            "SELECT * FROM tech_stack WHERE project_id=? AND category=?",
            (project_id, category),
        ).fetchone()
    finally:
        conn.close()

    logger.info(
        "Stack adjusted | project=%s | category=%s | %r → %r",
        project_id, category, adjusted_from, name,
    )

    return {
        "project_id": project_id,
        "category": category,
        "old_name": adjusted_from,
        "new_name": name,
        "rationale": rationale,
        "adjusted": True,
        "entry": dict(row) if row else None,
    }


def get_stack(
    project_id: str,
    memory_db_path: Path,
) -> dict[str, Any]:
    """EC-F003: Retrieve current stack (confirmed or proposed)."""
    conn = open_db(memory_db_path)
    try:
        rows = conn.execute(
            "SELECT * FROM tech_stack WHERE project_id=?", (project_id,)
        ).fetchall()
    finally:
        conn.close()

    stack = _rows_to_stack(rows)
    confirmed = all(bool(r["confirmed"]) for r in rows) if rows else False

    return {
        "project_id": project_id,
        "stack": stack,
        "confirmed": confirmed,
        "categories": list(stack.keys()),
        "missing_required": list(REQUIRED_CATEGORIES - set(stack.keys())),
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _persist_stack(
    project_id: str,
    stack: dict[str, Any],
    memory_db_path: Path,
    confirmed: bool,
) -> None:
    """Write all stack entries to tech_stack table."""
    now = _utcnow()
    conn = open_db(memory_db_path)
    try:
        with transaction(conn, str(memory_db_path)):
            for category, entry in stack.items():
                entry_id = str(uuid.uuid4())
                alternatives_json = json.dumps(entry.get("alternatives", []))
                conn.execute(
                    """
                    INSERT OR REPLACE INTO tech_stack (
                        id, project_id, category, name, version,
                        rationale, alternatives,
                        confirmed, confirmed_at,
                        adjusted, created_at, updated_at
                    ) VALUES (
                        COALESCE((SELECT id FROM tech_stack WHERE project_id=? AND category=?), ?),
                        ?, ?, ?, ?,
                        ?, ?,
                        ?, ?,
                        0, ?, ?
                    )
                    """,
                    (
                        project_id, category, entry_id,
                        project_id, category,
                        entry.get("name", ""),
                        entry.get("version", ""),
                        entry.get("rationale", ""),
                        alternatives_json,
                        1 if confirmed else 0,
                        now if confirmed else None,
                        now, now,
                    ),
                )
    finally:
        conn.close()


def _rows_to_stack(rows: list) -> dict[str, Any]:
    """Convert tech_stack DB rows to a structured dict."""
    result: dict[str, Any] = {}
    for row in rows:
        alternatives = json.loads(row["alternatives"]) if row["alternatives"] else []
        result[row["category"]] = {
            "name": row["name"],
            "version": row["version"] or "",
            "rationale": row["rationale"],
            "alternatives": alternatives,
            "confirmed": bool(row["confirmed"]),
            "adjusted": bool(row["adjusted"]),
        }
    return result


def _load_answers_from_db(
    project_id: str,
    memory_db_path: Path,
) -> tuple[dict, list]:
    """Load clarification answers from DB (fallback when not in memory)."""
    try:
        conn = open_db(memory_db_path)
        row = conn.execute(
            "SELECT answers, assumptions FROM clarification_sessions "
            "WHERE project_id=? ORDER BY started_at DESC LIMIT 1",
            (project_id,),
        ).fetchone()
        conn.close()
        if row:
            answers = json.loads(row["answers"]) if row["answers"] else {}
            assumptions = json.loads(row["assumptions"]) if row["assumptions"] else []
            return answers, assumptions
    except Exception as exc:
        logger.warning("Could not load answers from DB for %s: %s", project_id, exc)
    return {}, []


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()
