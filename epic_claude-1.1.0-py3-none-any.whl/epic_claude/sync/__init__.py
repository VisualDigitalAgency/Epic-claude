"""
EC-F006 — Context Syncer.

Public API:
  - register_sync_handlers(): wire 2 MCP tool handlers (call at startup)
  - context_sync():    run full sync state machine
  - context_recall():  get task-relevant context without writing
  - rollback_sync():   restore CLAUDE.md from most recent backup
"""

from epic_claude.sync.handlers import register_sync_handlers
from epic_claude.sync.syncer import context_sync, context_recall, rollback_sync
from epic_claude.sync.state_machine import SyncStateMachine, SyncContext, get_last_sync
from epic_claude.sync.claude_md import (
    find_managed_section,
    detect_manual_edit,
    write_managed_section,
    read_managed_section,
    build_managed_section,
    verify_section_written,
)
from epic_claude.sync.backup import (
    create_backup,
    restore_from_backup,
    get_latest_backup,
    cleanup_old_backups,
)

__all__ = [
    "register_sync_handlers",
    "context_sync", "context_recall", "rollback_sync",
    "SyncStateMachine", "SyncContext", "get_last_sync",
    "find_managed_section", "detect_manual_edit",
    "write_managed_section", "read_managed_section",
    "build_managed_section", "verify_section_written",
    "create_backup", "restore_from_backup",
    "get_latest_backup", "cleanup_old_backups",
]
