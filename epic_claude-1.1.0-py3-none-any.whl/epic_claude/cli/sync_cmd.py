"""
CLI: epic-claude sync — sync architecture to CLAUDE.md.

Commands:
  epic-claude sync
  epic-claude sync --task "implement payments"
  epic-claude sync --dry-run
  epic-claude sync --rollback
"""

from __future__ import annotations

from typing import Optional
try:
    import typer
except ImportError:
    typer = None  # type: ignore

from epic_claude.cli.output import console, print_error, print_success, print_json, is_json_mode
try:
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    from rich.markdown import Markdown
except ImportError:
    Table = Panel = Text = Markdown = None  # type: ignore


sync_app = typer.Typer(help="Sync architecture to project CLAUDE.md.")


@sync_app.callback(invoke_without_command=True)
def sync(
    task: Optional[str] = typer.Option(None, "--task", "-t",
        help="Scope context to a specific task."),
    dry_run: bool = typer.Option(False, "--dry-run",
        help="Show what would be written without writing."),
    rollback: bool = typer.Option(False, "--rollback",
        help="Restore CLAUDE.md from most recent backup."),
    force: bool = typer.Option(False, "--force",
        help="Overwrite even if manual edits detected."),
    project_id: Optional[str] = typer.Option(None, "--project-id"),
) -> None:
    """Sync architecture context into CLAUDE.md via the managed section."""
    try:
        import os
        from pathlib import Path
        import epic_claude.registry as reg_mod
        from epic_claude.memory.registry_store import RegistryStore
        from epic_claude.server.detection import detect_project, DetectionStatus

        # Resolve project
        if project_id is None:
            cwd = Path(os.getcwd())
            detection = detect_project(cwd=cwd, registry_projects_dir=reg_mod.PROJECTS_DIR)
            if detection.status == DetectionStatus.NOT_FOUND or detection.project is None:
                from epic_claude.cli.output import print_no_project_found
            print_no_project_found(str(cwd))
            raise typer.Exit(code=1)
            project_id = detection.project.project_id

        registry_db = reg_mod.REGISTRY_DB_PATH
        memory_db   = reg_mod.PROJECTS_DIR / project_id / "memory.db"

        rs = RegistryStore(registry_db); rs.open()
        try:
            project = rs.require_by_id(project_id)
        finally:
            rs.close()

        claude_md_path = (
            Path(project.claude_md_path)
            if project.claude_md_path
            else Path(project.root_path) / "CLAUDE.md"
        )

        # Rollback mode
        if rollback:
            from epic_claude.sync.syncer import rollback_sync
            result = rollback_sync(project_id, claude_md_path, reg_mod.PROJECTS_DIR)
            if is_json_mode():
                print_json(result)
            elif result["success"]:
                print_success(result["message"])
            else:
                print_error(result["message"])
                raise typer.Exit(code=1)
            return

        # Normal sync
        from epic_claude.sync.syncer import context_sync
        result = context_sync(
            project_id=project_id,
            claude_md_path=claude_md_path,
            registry_db_path=registry_db,
            memory_db_path=memory_db,
            projects_dir=reg_mod.PROJECTS_DIR,
            task=task,
            triggered_by="manual",
            dry_run=dry_run,
            force=force,
        )

        if is_json_mode():
            print_json(result)
            return

        state = result.get("state", "?")

        if dry_run:
            console.print("\n[bold]Dry run preview:[/bold]")
            console.print(result.get("preview", ""))
            console.print(f"\n[dim]Content hash: {result.get('content_hash','?')[:12]}...[/dim]")
            return

        if state == "DONE":
            print_success(
                f"CLAUDE.md synced — lines {result.get('section_start_line')}"
                f"–{result.get('section_end_line')} "
                f"({result.get('duration_ms', 0)}ms)"
            )
        elif state == "MANUAL_EDIT_DETECTED":
            console.print("\n[bold yellow]⚠  Manual edit detected inside EPIC-Claude managed section[/bold yellow]")
            console.print(f"   Last hash: [dim]{result.get('last_hash','unknown')[:12] if result.get('last_hash') else 'unknown'}...[/dim]")
            console.print("\n   Options:")
            console.print("     [cyan]epic-claude sync --force[/cyan]     → overwrite with current architecture [bold](recommended)[/bold]")
            console.print("     [cyan]epic-claude sync --rollback[/cyan]  → restore CLAUDE.md from last backup")
            console.print("\n   To keep your edits, move them outside the managed section markers.")
        else:
            print_error(result.get("message", f"Sync ended in state: {state}"))
            raise typer.Exit(code=1)

    except typer.Exit:
        raise
    except Exception as exc:
        print_error(f"Sync failed: {exc}")
        raise typer.Exit(code=1)
