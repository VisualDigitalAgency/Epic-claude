"""
CLI: epic plan — start a new project (full interactive flow).

  epic plan "multi-tenant SaaS invoicing app"   → interactive
  epic plan --config requirements.yaml           → CI/non-interactive
  epic plan --yes                                → skip confirmations

This module exists as a standalone file so it can be imported, tested,
and re-used independently. The top-level 'epic plan' in main.py delegates
to run_plan() from here.

Flow:
  project_start  → clarify (Q&A or config file)
  → stack_decide → stack_confirm
  → architect_generate
  → context_sync → CLAUDE.md written

CI config file format (YAML):
  description: "multi-tenant SaaS invoicing app in Python"
  answers:
    scale: "1k-10k users"
    database: "PostgreSQL"
    deployment: "Railway"
    auth: "JWT"
  confirm_stack: true
  generate: true
  sync: true
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any

try:
    import typer
except ImportError:
    typer = None  # type: ignore

try:
    from rich.console import Console
    from rich.panel import Panel
    _RICH = True
except ImportError:
    _RICH = False
    class Console:  # type: ignore
        def print(self, *a, **kw):
            import re; print(re.sub(r"[[][^]]*[]]","",str(a[0])) if a else "")
    class Panel:  # type: ignore
        def __init__(self, *a, **kw): pass

from epic_claude.cli.output import print_error, print_success, is_json_mode, print_json

console = Console()

plan_app = typer.Typer(
    help="Start a new project: clarify → stack → generate → sync.",
    no_args_is_help=False,
) if typer else None


# ---------------------------------------------------------------------------
# Core plan runner — called by both CLI and main.py plan command
# ---------------------------------------------------------------------------

async def run_plan(
    description: str | None = None,
    cwd: Path | None = None,
    config_file: Path | None = None,
    yes: bool = False,
    no_sync: bool = False,
) -> dict[str, Any]:
    """
    Execute the full plan flow. Returns a result dict.

    Args:
        description:  Project description string.
        cwd:          Working directory (default: os.getcwd()).
        config_file:  YAML config file for CI/non-interactive mode.
        yes:          Skip all confirmation prompts.
        no_sync:      Skip CLAUDE.md sync step.
    """
    cwd = cwd or Path(os.getcwd())

    # Load config file if provided (CI mode)
    ci_answers: dict[str, str] = {}
    if config_file:
        ci_answers, description = _load_config_file(config_file, description)
        yes = True  # --config implies --yes

    if not description:
        if yes:
            return {"success": False, "error": "description is required in --yes / --config mode"}
        if _RICH:
            console.print("[bold]What do you want to build?[/bold]")
            console.print("[dim]Example: a multi-tenant SaaS invoicing app in Python[/dim]\n")
        description = input("Project description: ").strip()
        if not description:
            return {"success": False, "error": "No description provided"}

    # Step 1: project_start → clarification questions
    from epic_claude.agents.handlers import _handle_project_start
    result = await _handle_project_start({"description": description, "cwd": str(cwd)})

    if not result.get("success"):
        return result

    project_id = result["project_id"]
    session_id = result["session_id"]
    questions  = result.get("questions", [])
    inferred   = result.get("inferred", {})

    if _RICH:
        console.print(f"[green]✓[/green] Project: [bold]{result['project_name']}[/bold]  "
                      f"[dim]ID: {project_id[:8]}[/dim]")
        if inferred:
            inf_str = "  ".join(f"{k}={v}" for k, v in inferred.items() if v)
            console.print(f"[dim]  Inferred: {inf_str}[/dim]")
        console.print()

    # Step 2: answer clarification questions
    answers: dict[str, str] = {}
    if questions:
        if ci_answers:
            # Non-interactive: merge CI answers with defaults
            for q in questions:
                key = q["key"]
                if key in ci_answers:
                    answers[key] = ci_answers[key]
                else:
                    # Use first non-"I'm not sure" option as default
                    opts = q.get("options", [])
                    answers[key] = next((o for o in opts if "not sure" not in o.lower()), opts[0] if opts else "")
        else:
            # Interactive
            if _RICH:
                console.print("[bold]Clarification questions:[/bold]\n")
            for q in questions:
                if _RICH:
                    console.print(f"[cyan]{q['question']}[/cyan]")
                    for i, opt in enumerate(q.get("options", []), 1):
                        console.print(f"  [{i}] {opt}")
                    raw = typer.prompt("  Answer (number or text)", default="1") if typer else input("  Answer: ")
                else:
                    raw = typer.prompt(q["question"]) if typer else input(f"{q['question']}: ")

                opts = q.get("options", [])
                try:
                    idx = int(raw) - 1
                    answers[q["key"]] = opts[idx] if 0 <= idx < len(opts) else raw
                except (ValueError, IndexError):
                    answers[q["key"]] = raw
                if _RICH: console.print()

    from epic_claude.agents.handlers import _handle_clarify_answer
    await _handle_clarify_answer({"session_id": session_id, "answers": answers})
    if _RICH:
        console.print("[green]✓[/green] Requirements captured\n")

    # Step 3: stack_decide + stack_confirm
    from epic_claude.agents.handlers import _handle_stack_decide, _handle_stack_confirm
    stack_result = await _handle_stack_decide({"project_id": project_id})

    if stack_result.get("success"):
        stack = stack_result.get("stack", {})
        if _RICH:
            console.print("[bold]Proposed tech stack:[/bold]")
            for cat, entry in stack.items():
                if isinstance(entry, dict):
                    console.print(f"  {cat:<12} [cyan]{entry.get('name','?')}[/cyan]  "
                                  f"[dim]{entry.get('version','')}[/dim]")
            console.print()

        if not yes and typer:
            typer.confirm("Confirm this stack?", default=True, abort=True)

        await _handle_stack_confirm({"project_id": project_id})
        if _RICH:
            console.print("[green]✓[/green] Stack confirmed\n")

    # Step 4: generate
    if _RICH:
        console.print("[bold]Generating architecture...[/bold]")
        console.print("[dim](PRD · API spec · DB schema · Tech stack · Service boundaries)[/dim]\n")

    from epic_claude.agents.architect_handlers import _handle_architect_generate
    gen_result = await _handle_architect_generate({"project_id": project_id})

    if not gen_result.get("success"):
        return {"success": False, "error": "generation_failed",
                "message": gen_result.get("message", "Generation failed")}

    if _RICH:
        console.print(f"[green]✓[/green] Architecture generated  "
                      f"[dim]({len(gen_result.get('artifacts',[]))} artifacts)[/dim]\n")

    # Step 5: sync to CLAUDE.md
    sync_result = {"state": "SKIPPED"}
    if not no_sync:
        from epic_claude.sync.handlers import _handle_context_sync
        sync_result = await _handle_context_sync({
            "project_id": project_id,
            "triggered_by": "plan",
        })
        if sync_result.get("success") and _RICH:
            console.print("[green]✓[/green] CLAUDE.md synced\n")

    return {
        "success": True,
        "project_id": project_id,
        "project_name": result["project_name"],
        "arch_dir": gen_result.get("arch_dir"),
        "artifact_count": len(gen_result.get("artifacts", [])),
        "sync_state": sync_result.get("state"),
        "cwd": str(cwd),
    }


# ---------------------------------------------------------------------------
# CLI command
# ---------------------------------------------------------------------------

if plan_app and typer:

    @plan_app.callback(invoke_without_command=True)
    def plan(
        description: str = typer.Argument(None, help='Project description. Example: "SaaS invoicing app in Python"'),
        config: Path  = typer.Option(None,  "--config", "-c",
            help="YAML config file for CI/non-interactive mode.",
            exists=False, file_okay=True, dir_okay=False,
        ),
        yes:     bool = typer.Option(False, "--yes", "-y",
            help="Skip all confirmation prompts (CI-safe)."),
        no_sync: bool = typer.Option(False, "--no-sync",
            help="Skip CLAUDE.md sync step."),
    ) -> None:
        """
        Start a new project: clarify requirements → confirm stack → generate architecture → sync.

        Interactive by default. Use --config=file.yaml for CI pipelines.
        """
        import os
        from pathlib import Path

        # API key guard
        if not os.environ.get("ANTHROPIC_API_KEY"):
            console.print("[bold red]✗[/bold red] ANTHROPIC_API_KEY is not set.\n")
            console.print("  [cyan]export ANTHROPIC_API_KEY=your-key[/cyan]")
            raise typer.Exit(code=1)

        from epic_claude.cli.output import is_json_mode
        cwd = Path(os.getcwd())

        try:
            result = asyncio.run(run_plan(
                description=description,
                cwd=cwd,
                config_file=config,
                yes=yes,
                no_sync=no_sync,
            ))
        except typer.Abort:
            console.print("[dim]Cancelled.[/dim]")
            return
        except Exception as exc:
            print_error(f"plan failed: {exc}")
            raise typer.Exit(code=1)

        if is_json_mode():
            print_json(result)
            return

        if not result.get("success"):
            err = result.get("error", "")
            if err == "unsupported_project_type":
                console.print(f"\n[red]✗[/red] {result.get('message')}")
                console.print(f"  Supported: backend_saas · rest_api · fullstack_web")
            else:
                print_error(result.get("message", "Unknown error"))
            raise typer.Exit(code=1)

        if _RICH:
            console.print(Panel(
                f"[bold green]✓ Project ready: {result['project_name']}[/bold green]\n\n"
                f"Architecture: [dim]{result.get('arch_dir', '?')}[/dim]\n"
                f"CLAUDE.md:    [dim]{cwd}/CLAUDE.md[/dim]\n\n"
                "[bold]Next:[/bold] Open Claude Code in this directory.",
                border_style="green",
            ))
        else:
            print(f"✓ {result['project_name']} ready. Open Claude Code in {cwd}")


# ---------------------------------------------------------------------------
# Config file loader (CI mode)
# ---------------------------------------------------------------------------

def _load_config_file(
    config_file: Path,
    description_override: str | None,
) -> tuple[dict[str, str], str | None]:
    """
    Load a YAML plan config file.

    Format:
      description: "my SaaS app"
      answers:
        scale: "1k-10k users"
        database: "PostgreSQL"
        deployment: "Railway"

    Returns: (answers dict, description)
    """
    try:
        import yaml  # type: ignore
    except ImportError:
        try:
            # Fallback: very simple YAML subset parser
            return _parse_simple_yaml(config_file.read_text()), description_override
        except Exception:
            raise ValueError(
                f"Could not parse {config_file}. "
                "Install PyYAML: pip install pyyaml"
            )

    data = yaml.safe_load(config_file.read_text())
    if not isinstance(data, dict):
        raise ValueError(f"Config file must be a YAML mapping: {config_file}")

    description = description_override or data.get("description")
    answers     = data.get("answers", {})
    if not isinstance(answers, dict):
        answers = {}

    return {str(k): str(v) for k, v in answers.items()}, description


def _parse_simple_yaml(text: str) -> dict[str, str]:
    """Minimal YAML parser — handles flat key:value pairs only."""
    result: dict[str, str] = {}
    in_answers = False
    for line in text.splitlines():
        line = line.rstrip()
        if not line or line.startswith("#"):
            continue
        if line.strip() == "answers:":
            in_answers = True
            continue
        if in_answers and line.startswith("  "):
            k, _, v = line.strip().partition(":")
            if k and v:
                result[k.strip()] = v.strip().strip('"').strip("'")
    return result
