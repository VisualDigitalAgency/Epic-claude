"""
EC-F006 — Context Syncer MCP tool handlers.

Wires 2 tools:
  - context_sync
  - context_recall

Called once at server startup via register_sync_handlers().
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import epic_claude.registry as reg_mod
from epic_claude.memory.database import bootstrap_memory_db
from epic_claude.server.logging import get_logger
from epic_claude.server.tools import register_handler
from epic_claude.sync.syncer import context_sync, context_recall

logger = get_logger(__name__)


async def _handle_context_sync(params: dict[str, Any]) -> dict[str, Any]:
    """
    Run the full sync state machine for a project.

    Required: project_id
    Optional: task, triggered_by, dry_run, force
    """
    project_id   = _require(params, "project_id")
    task         = params.get("task")
    dry_run      = bool(params.get("dry_run", False))
    force        = bool(params.get("force", False))
    triggered_by = params.get("triggered_by", "manual")

    registry_db = reg_mod.REGISTRY_DB_PATH
    memory_db   = reg_mod.PROJECTS_DIR / project_id / "memory.db"
    bootstrap_memory_db(memory_db)

    # Resolve CLAUDE.md path from registry
    from epic_claude.memory.registry_store import RegistryStore
    rs = RegistryStore(registry_db); rs.open()
    try:
        project = rs.require_by_id(project_id)
        if project.claude_md_path:
            claude_md_path = Path(project.claude_md_path)
        else:
            claude_md_path = Path(project.root_path) / "CLAUDE.md"
    finally:
        rs.close()

    try:
        result = context_sync(
            project_id=project_id,
            claude_md_path=claude_md_path,
            registry_db_path=registry_db,
            memory_db_path=memory_db,
            projects_dir=reg_mod.PROJECTS_DIR,
            task=task,
            triggered_by=triggered_by,
            dry_run=dry_run,
            force=force,
        )
        return {"success": result.get("synced", False), **result}
    except Exception as exc:
        logger.exception("context_sync failed: %s", exc)
        return {"success": False, "error": str(exc)}


async def _handle_context_recall(params: dict[str, Any]) -> dict[str, Any]:
    """
    Return task-relevant context without writing to CLAUDE.md.

    Required: project_id, task
    Optional: limit
    """
    project_id = _require(params, "project_id")
    task       = _require(params, "task")
    limit      = int(params.get("limit", 10))

    registry_db = reg_mod.REGISTRY_DB_PATH
    memory_db   = reg_mod.PROJECTS_DIR / project_id / "memory.db"

    try:
        result = context_recall(
            project_id=project_id,
            task=task,
            memory_db_path=memory_db,
            registry_db_path=registry_db,
            limit=limit,
        )
        return {"success": True, **result}
    except Exception as exc:
        logger.exception("context_recall failed: %s", exc)
        return {"success": False, "error": str(exc)}


def register_sync_handlers() -> None:
    """Wire EC-F006 handlers. Called once at server startup."""
    register_handler("context_sync",   _handle_context_sync)
    register_handler("context_recall", _handle_context_recall)
    logger.info("EC-F006 Context Syncer handlers registered (2 tools)")


def _require(params: dict[str, Any], key: str) -> Any:
    val = params.get(key)
    if val is None:
        raise TypeError(f"Required parameter missing: '{key}'")
    return val
