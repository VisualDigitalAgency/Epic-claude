"""
EPIC-Claude — Universal AI Solutions Architect for Claude Code.

Global MCP server that generates production-grade architecture for your projects.
JSON-RPC 2.0 over stdio. One install. All projects.
"""

__version__ = "1.0.0"
__author__ = "EPIC-Claude Contributors"
__license__ = "MIT"

# Schema versions — bump when DB schema changes requiring migration
__registry_schema_version__ = 1   # registry.db schema version
__memory_schema_version__   = 1   # memory.db schema version
