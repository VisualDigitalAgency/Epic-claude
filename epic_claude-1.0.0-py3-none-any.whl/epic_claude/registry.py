"""
EPIC-Claude global registry initialisation.

Handles creation of ~/.epic-claude/ with correct permissions,
config bootstrapping, and registry.db bootstrapping.
PRD §11 — Global Registry Structure.
PRD §18 — Security (mode 700 / 600).
"""

from __future__ import annotations

import stat
from pathlib import Path

from pathlib import Path as _Path
import os as _os

def _resolve_home() -> _Path:
    """
    Resolve the global state directory.

    Priority:
      1. EPIC_CLAUDE_HOME env var (explicit override — all platforms)
      2. Windows: %APPDATA%/epic-claude
      3. Linux/Mac XDG: $XDG_DATA_HOME/epic-claude
      4. Linux/Mac default: ~/.epic-claude
    """
    # Explicit env override takes priority on all platforms
    explicit = _os.environ.get("EPIC_CLAUDE_HOME")
    if explicit:
        return _Path(explicit)

    # Windows: use %APPDATA%
    if _os.name == "nt":
        appdata = _os.environ.get("APPDATA")
        if appdata:
            return _Path(appdata) / "epic-claude"
        # Fallback if APPDATA not set (rare)
        return _Path.home() / ".epic-claude"

    # Linux/Mac: respect XDG_DATA_HOME
    xdg = _os.environ.get("XDG_DATA_HOME")
    if xdg:
        return _Path(xdg) / "epic-claude"

    return _Path.home() / ".epic-claude"

EPIC_CLAUDE_HOME: _Path = _resolve_home()


# ---------------------------------------------------------------------------
# Directory layout constants (mirrors PRD §11)
# ---------------------------------------------------------------------------

REGISTRY_DB_PATH     = EPIC_CLAUDE_HOME / "registry.db"
CONFIG_PATH          = EPIC_CLAUDE_HOME / "config.json"
SERVER_LOG_PATH      = EPIC_CLAUDE_HOME / "server.log"
PROJECTS_DIR         = EPIC_CLAUDE_HOME / "projects"


def project_dir(project_id: str) -> Path:
    return PROJECTS_DIR / project_id

def memory_db_path(project_id: str) -> Path:
    return project_dir(project_id) / "memory.db"

def architecture_dir(project_id: str) -> Path:
    return project_dir(project_id) / "architecture"

def claude_md_backups_dir(project_id: str) -> Path:
    return project_dir(project_id) / "claude_md_backups"

def project_json_path(project_id: str) -> Path:
    return project_dir(project_id) / "project.json"


# ---------------------------------------------------------------------------
# Artifact filename map (PRD §11)
# ---------------------------------------------------------------------------

ARTIFACT_FILENAMES: dict[str, str] = {
    "prd":        "prd.md",
    "tech_stack": "techstack.md",
    "api_spec":   "api.yaml",
    "db_schema":  "schema.sql",
    "boundaries": "boundaries.md",
}


# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------

def bootstrap_home() -> None:
    """
    Initialise ~/.epic-claude/ if it does not already exist.

    Directory permissions:
      ~/.epic-claude/           → 700  (owner rwx only)
      ~/.epic-claude/projects/  → 700
    File permissions:
      registry.db               → 600 (created by DB layer on first use)
      server.log                → 600 (created by logging layer on first use)
      config.json               → 644 (readable, no credentials)

    Safe to call multiple times — idempotent.
    """
    # Root home directory — mode 700
    EPIC_CLAUDE_HOME.mkdir(mode=0o700, parents=True, exist_ok=True)
    _enforce_mode(EPIC_CLAUDE_HOME, 0o700)

    # Projects directory — mode 700
    PROJECTS_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    _enforce_mode(PROJECTS_DIR, 0o700)

    # Write default config if absent (lazy import avoids pydantic at module load)
    if not CONFIG_PATH.exists():
        try:
            from epic_claude.config import EpicClaudeConfig, save_config  # noqa: PLC0415
            save_config(EpicClaudeConfig())
        except ImportError:
            # pydantic not yet installed — write a minimal default config
            import json
            CONFIG_PATH.write_text(json.dumps({"log_level": "info"}, indent=2) + "\n")


def bootstrap_project(project_id: str) -> None:
    """
    Create per-project directory layout under ~/.epic-claude/projects/<id>/.
    Writes project.json with project_id and schema versions.
    Safe to call multiple times — idempotent.
    """
    dirs = [
        project_dir(project_id),
        architecture_dir(project_id),
        claude_md_backups_dir(project_id),
    ]
    for d in dirs:
        d.mkdir(mode=0o700, parents=True, exist_ok=True)
        _enforce_mode(d, 0o700)

    # Write project.json if not present — records version for migration checks
    pjson = project_json_path(project_id)
    if not pjson.exists():
        import json as _json
        from epic_claude import __registry_schema_version__, __memory_schema_version__
        pjson.write_text(_json.dumps({
            "project_id":             project_id,
            "project_version":        "1.0.0",
            "registry_schema_version": __registry_schema_version__,
            "memory_schema_version":   __memory_schema_version__,
            "created_at": __import__("datetime").datetime.utcnow().isoformat() + "Z",
        }, indent=2))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _enforce_mode(path: Path, mode: int) -> None:
    """Set permissions only if they differ from desired mode (idempotent)."""
    current = stat.S_IMODE(path.stat().st_mode)
    if current != mode:
        path.chmod(mode)


def home_is_initialised() -> bool:
    """Return True if ~/.epic-claude/ is fully bootstrapped."""
    return (
        EPIC_CLAUDE_HOME.is_dir()
        and PROJECTS_DIR.is_dir()
        and CONFIG_PATH.is_file()
    )
