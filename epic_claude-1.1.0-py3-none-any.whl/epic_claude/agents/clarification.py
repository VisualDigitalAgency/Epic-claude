"""
EC-F002 — Clarification Agent.

Conducts adaptive question-answer rounds to gather enough context
for confident tech stack and architecture decisions.

PRD §13 EC-F002 acceptance criteria:
  ✓ project_start triggers project detection + clarification
  ✓ Questions cover: type, scale, language, framework, db, auth, deployment, constraints
  ✓ Infers obvious answers — never re-asks what's already stated
  ✓ clarify_answer stores answers with confidence levels
  ✓ One follow-up per unknown answer
  ✓ If still unknown → assumption with confidence=low
  ✓ ready=True when sufficient context reached
  ✓ Maximum 3 main rounds
  ✓ clarify_revise allows correction before proceeding
  ✓ All state persisted to clarification_sessions table

PRD §4 Unknown Answer Handling:
  complete  → confidence=high
  partial   → confidence=medium
  unknown   → one follow-up → if still unknown → assume (confidence=low)
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from epic_claude.agents.llm import LLMClient, get_llm_client
from epic_claude.agents.prompts import (
    CLARIFICATION_SYSTEM,
    build_clarification_prompt,
    build_followup_prompt,
    build_assumption_prompt,
    build_sufficiency_prompt,
    format_answers_summary,
)
from epic_claude.constants import Confidence, ProjectType, SUPPORTED_PROJECT_TYPES
from epic_claude.exceptions import (
    ClarificationNotCompleteError,
    ClarificationSessionNotFoundError,
    UnsupportedProjectTypeError,
)
from epic_claude.memory.database import open_db, transaction
from epic_claude.memory.registry_store import RegistryStore
from epic_claude.server.logging import get_logger

logger = get_logger(__name__)

MAX_CLARIFICATION_ROUNDS = 3

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class Question:
    key: str
    question: str
    options: list[str]
    required: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "question": self.question,
            "options": self.options,
            "required": self.required,
        }


@dataclass
class ClarificationState:
    """In-memory state for an active clarification session."""
    session_id: str
    project_id: str
    project_name: str
    description: str
    round: int = 1
    status: str = "active"
    questions: list[Question] = field(default_factory=list)
    answers: dict[str, Any] = field(default_factory=dict)
    confidence: dict[str, str] = field(default_factory=dict)
    followup_asked: dict[str, str] = field(default_factory=dict)
    followup_answers: dict[str, Any] = field(default_factory=dict)
    assumptions: list[dict[str, Any]] = field(default_factory=list)
    inferred: dict[str, Any] = field(default_factory=dict)
    is_sufficient: bool = False


# ---------------------------------------------------------------------------
# Session registry (in-memory cache — state persisted to DB)
# ---------------------------------------------------------------------------

_sessions: dict[str, ClarificationState] = {}


def _get_session(session_id: str) -> ClarificationState:
    if session_id not in _sessions:
        raise ClarificationSessionNotFoundError(
            f"Clarification session not found: {session_id}",
            detail={"session_id": session_id},
        )
    return _sessions[session_id]


# ---------------------------------------------------------------------------
# Core agent operations
# ---------------------------------------------------------------------------

async def start_clarification(
    project_id: str,
    project_name: str,
    description: str,
    memory_db_path: Path,
    llm: LLMClient | None = None,
) -> dict[str, Any]:
    """
    EC-F002: Begin a clarification session for a new project.
    Calls LLM to generate the first round of questions.

    Returns:
        {session_id, questions, inferred, round}
    """
    if llm is None:
        llm = get_llm_client()

    session_id = str(uuid.uuid4())
    logger.info("Clarification starting | project=%s | session=%s", project_id, session_id)

    # Call LLM to generate questions
    response = await llm.complete_json(
        system=CLARIFICATION_SYSTEM,
        user=build_clarification_prompt(description),
    )

    inferred = response.get("inferred", {})
    raw_questions = response.get("questions", [])

    # Check if project type is unsupported
    project_type = inferred.get("project_type", "unknown")
    if project_type == "unsupported":
        raise UnsupportedProjectTypeError(
            f"Project type not supported in v1",
            detail={"description": description, "inferred_type": project_type},
        )

    questions = [
        Question(
            key=q["key"],
            question=q["question"],
            options=q.get("options", []),
            required=q.get("required", True),
        )
        for q in raw_questions
    ]

    # Seed answers with inferred values
    answers: dict[str, Any] = {}
    confidence: dict[str, str] = {}
    for k, v in inferred.items():
        if v:
            answers[k] = v
            confidence[k] = Confidence.HIGH

    state = ClarificationState(
        session_id=session_id,
        project_id=project_id,
        project_name=project_name,
        description=description,
        round=1,
        questions=questions,
        answers=answers,
        confidence=confidence,
        inferred=inferred,
    )
    _sessions[session_id] = state

    # Persist to DB
    _persist_session(state, memory_db_path)

    logger.info(
        "Clarification session created | session=%s | questions=%d | inferred=%s",
        session_id, len(questions), list(inferred.keys()),
    )

    return {
        "session_id": session_id,
        "round": 1,
        "questions": [q.to_dict() for q in questions],
        "inferred": inferred,
        "status": "active",
    }


async def submit_answers(
    session_id: str,
    answers: dict[str, Any],
    memory_db_path: Path,
    llm: LLMClient | None = None,
) -> dict[str, Any]:
    """
    EC-F002: Process a round of answers.

    For each unknown answer: ask one follow-up.
    If follow-up also unknown: generate assumption.
    Evaluates sufficiency after each round.

    Returns:
        {ready, round, followups, assumptions, answers, status}
    """
    if llm is None:
        llm = get_llm_client()

    state = _get_session(session_id)

    # Classify each answer
    followups_needed: list[Question] = []

    for key, value in answers.items():
        is_unknown = _is_unknown_answer(value)

        if is_unknown:
            state.confidence[key] = Confidence.UNKNOWN
            state.answers[key] = None
        else:
            state.answers[key] = value
            state.confidence[key] = Confidence.HIGH

        # If unknown AND we haven't asked a follow-up yet → ask one
        if is_unknown and key not in state.followup_asked:
            q = next((q for q in state.questions if q.key == key), None)
            if q:
                followups_needed.append(q)

    # Generate follow-up questions for unknowns
    followup_questions: list[dict[str, Any]] = []
    for q in followups_needed:
        try:
            fu_response = await llm.complete_json(
                system=CLARIFICATION_SYSTEM,
                user=build_followup_prompt(q.key, q.question),
            )
            fu_question = Question(
                key=fu_response["followup_key"],
                question=fu_response["followup_question"],
                options=fu_response.get("options", ["Unknown — make a reasonable assumption"]),
            )
            state.followup_asked[q.key] = fu_response["followup_question"]
            followup_questions.append(fu_question.to_dict())
        except Exception as exc:
            logger.warning("Follow-up generation failed for %s: %s", q.key, exc)

    state.round += 1

    # Handle answers that had follow-ups but are STILL unknown → assume
    # Only process follow-up resolution if the follow-up was asked in a PREVIOUS round
    # (i.e., followup_asked[key] exists AND this is a subsequent answer submission)
    new_assumptions: list[dict[str, Any]] = []
    for key, fu_q in list(state.followup_asked.items()):
        if key in state.followup_answers:
            continue  # already resolved

        # Check if this round's answers include the follow-up answer
        fu_key = f"{key}_followup"
        if fu_key in answers and not _is_unknown_answer(answers[fu_key]):
            # Follow-up resolved in this batch
            state.followup_answers[key] = answers[fu_key]
            state.answers[key] = answers[fu_key]
            state.confidence[key] = Confidence.HIGH
        elif fu_key in answers and _is_unknown_answer(answers[fu_key]):
            # Follow-up explicitly answered with "unknown" → assume
            assumption = await _generate_assumption(
                key=key,
                question=fu_q,
                state=state,
                llm=llm,
            )
            state.assumptions.append(assumption)
            state.answers[key] = assumption.get("assumed_value", "unknown")
            state.confidence[key] = Confidence.LOW
            new_assumptions.append(assumption)
        # else: follow-up not answered in this batch — wait for next round

    # Check sufficiency
    if state.round > MAX_CLARIFICATION_ROUNDS or not followup_questions:
        ready = await _check_sufficiency(state, llm)
        state.is_sufficient = ready
        if ready:
            state.status = "completed"
    else:
        ready = False

    # Persist updated state
    _persist_session(state, memory_db_path)

    logger.info(
        "Answers submitted | session=%s | round=%d | ready=%s | assumptions=%d",
        session_id, state.round, ready, len(new_assumptions),
    )

    return {
        "session_id": session_id,
        "ready": ready,
        "round": state.round,
        "followup_questions": followup_questions,
        "assumptions": new_assumptions,
        "answers": state.answers,
        "confidence": state.confidence,
        "status": state.status,
    }


def get_status(session_id: str) -> dict[str, Any]:
    """EC-F002: Return current clarification session status."""
    state = _get_session(session_id)
    unknowns = [k for k, c in state.confidence.items() if c == Confidence.UNKNOWN]
    return {
        "session_id": session_id,
        "project_id": state.project_id,
        "round": state.round,
        "status": state.status,
        "is_sufficient": state.is_sufficient,
        "answers_count": len([v for v in state.answers.values() if v is not None]),
        "unknowns": unknowns,
        "assumptions_count": len(state.assumptions),
        "questions": [q.to_dict() for q in state.questions],
        "answers": state.answers,
        "confidence": state.confidence,
        "assumptions": state.assumptions,
    }


def revise_answer(
    session_id: str,
    question_key: str,
    new_answer: str,
    memory_db_path: Path,
) -> dict[str, Any]:
    """EC-F002: Revise a single answer before proceeding to stack_decide."""
    state = _get_session(session_id)

    if state.status == "completed" and state.is_sufficient:
        # Allow revision even after completion
        logger.info("Revising answer on completed session: %s.%s", session_id, question_key)

    old_value = state.answers.get(question_key)
    state.answers[question_key] = new_answer
    state.confidence[question_key] = Confidence.HIGH

    # Remove any assumption for this key if it existed
    state.assumptions = [a for a in state.assumptions if a.get("key") != question_key]

    _persist_session(state, memory_db_path)

    logger.info(
        "Answer revised | session=%s | key=%s | %r → %r",
        session_id, question_key, old_value, new_answer,
    )

    return {
        "session_id": session_id,
        "revised_key": question_key,
        "old_value": old_value,
        "new_value": new_answer,
        "answers": state.answers,
    }


def get_session_for_project(project_id: str) -> ClarificationState | None:
    """Return the active clarification state for a project (if any)."""
    for state in _sessions.values():
        if state.project_id == project_id and state.status in ("active", "completed"):
            return state
    return None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _is_unknown_answer(value: Any) -> bool:
    """Return True if the answer indicates the user doesn't know."""
    if value is None:
        return True
    s = str(value).strip().lower()
    return s in (
        "i'm not sure", "im not sure", "not sure", "unknown",
        "don't know", "unsure", "i don't know", "n/a", "",
        "unknown — make a reasonable assumption",
    )


async def _generate_assumption(
    key: str,
    question: str,
    state: ClarificationState,
    llm: LLMClient,
) -> dict[str, Any]:
    """Generate a low-confidence assumption for an unknown answer."""
    project_type = state.inferred.get("project_type", state.answers.get("project_type", "unknown"))
    try:
        result = await llm.complete_json(
            system=CLARIFICATION_SYSTEM,
            user=build_assumption_prompt(
                key=key,
                question=question,
                project_type=project_type,
                description=state.description,
            ),
        )
        result["key"] = key
        return result
    except Exception as exc:
        logger.warning("Assumption generation failed for %s: %s", key, exc)
        return {
            "key": key,
            "assumed_value": "unknown",
            "confidence": Confidence.LOW,
            "assumption_text": f"Assumed: unknown — could not determine {key}",
            "impact": "Review before implementation",
        }


async def _check_sufficiency(state: ClarificationState, llm: LLMClient) -> bool:
    """Ask LLM whether current answers are sufficient to proceed."""
    answers_summary = format_answers_summary(state.answers, state.assumptions)
    project_type = state.inferred.get("project_type", state.answers.get("project_type", "unknown"))

    try:
        result = await llm.complete_json(
            system=CLARIFICATION_SYSTEM,
            user=build_sufficiency_prompt(project_type, answers_summary),
        )
        return bool(result.get("ready", False))
    except Exception as exc:
        logger.warning("Sufficiency check failed: %s — defaulting to True", exc)
        return True  # proceed with what we have


def _persist_session(state: ClarificationState, db_path: Path) -> None:
    """Write clarification session state to memory.db."""
    try:
        from epic_claude.memory.database import open_db, transaction
        conn = open_db(db_path)
        now = datetime.now(timezone.utc).isoformat()

        with transaction(conn, str(db_path)):
            conn.execute(
                """
                INSERT OR REPLACE INTO clarification_sessions (
                    id, project_id, round, status,
                    questions, answers, confidence,
                    followup_asked, followup_answers, assumptions,
                    is_sufficient, started_at, completed_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    state.session_id,
                    state.project_id,
                    state.round,
                    state.status,
                    json.dumps([q.to_dict() for q in state.questions]),
                    json.dumps(state.answers),
                    json.dumps(state.confidence),
                    json.dumps(state.followup_asked),
                    json.dumps(state.followup_answers),
                    json.dumps(state.assumptions),
                    1 if state.is_sufficient else 0,
                    now,
                    now if state.status == "completed" else None,
                ),
            )
        conn.close()
    except Exception as exc:
        logger.error("Failed to persist clarification session %s: %s", state.session_id, exc)
