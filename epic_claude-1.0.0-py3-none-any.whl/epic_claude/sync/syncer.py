"""
Context Syncer — EC-F006.

Orchestrates the full sync state machine for a project.
Wires together: backup → write → verify → log → done.

PRD §13 EC-F006 acceptance criteria:
  ✓ context_sync follows full sync state machine
  ✓ Always backs up before write
  ✓ Creates/appends/replaces managed section correctly
  ✓ Content outside managed section never touched
  ✓ Detects manual edits via checksum comparison
  ✓ Post-write checksum verification
  ✓ All operations logged to sync_log
  ✓ Task-scoped context (--task flag)
  ✓ context_recall returns context without writing
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from epic_claude.agents.architect import list_artifacts
from epic_claude.constants import SyncState, SyncTrigger
from epic_claude.exceptions import SyncVerifyError
from epic_claude.memory.store import MemoryStore, RecallRequest, get_store
from epic_claude.memory.registry_store import RegistryStore
from epic_claude.registry import claude_md_backups_dir
from epic_claude.server.logging import get_logger
from epic_claude.sync.backup import (
    create_backup,
    get_latest_backup,
    restore_from_backup,
    cleanup_old_backups,
)
from epic_claude.sync.claude_md import (
    build_managed_section,
    detect_manual_edit,
    read_managed_section,
    verify_section_written,
    write_managed_section,
)
from epic_claude.sync.state_machine import (
    SyncContext,
    SyncStateMachine,
    get_last_sync,
    user_message_for_state,
)
from epic_claude.agents.stack import get_stack
from epic_claude.templates.claude_md import render_managed_section, render_recall_context

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# context_sync — full state machine
# ---------------------------------------------------------------------------

def context_sync(
    project_id: str,
    claude_md_path: Path,
    registry_db_path: Path,
    memory_db_path: Path,
    projects_dir: Path,
    task: str | None = None,
    triggered_by: str = SyncTrigger.MANUAL,
    dry_run: bool = False,
    force: bool = False,
) -> dict[str, Any]:
    """
    Sync architecture context into CLAUDE.md via the managed section.

    PRD §7 state machine:
      READY → BACKING_UP → WRITING → VERIFYING → LOGGING → DONE

    Args:
        project_id:       Project UUID.
        claude_md_path:   Full path to project's CLAUDE.md.
        registry_db_path: Path to registry.db.
        memory_db_path:   Path to memory.db.
        projects_dir:     ~/.epic-claude/projects/ directory.
        task:             Optional task string for scoped context.
        triggered_by:     Trigger source (manual/session_start/auto).
        dry_run:          If True, render content but don't write.
        force:            If True, skip manual-edit detection prompt.

    Returns:
        dict with state, synced, message, section_lines, content_hash.
    """
    # ── Build context ──────────────────────────────────────────────────────
    registry = RegistryStore(registry_db_path)
    registry.open()
    try:
        project = registry.require_by_id(project_id)
        project_name = project.name
    finally:
        registry.close()

    stack_result = get_stack(project_id, memory_db_path)
    stack = stack_result["stack"]

    artifacts = list_artifacts(project_id, memory_db_path)

    store = get_store(project_id, memory_db_path)
    memory_entries_result = store.recall(RecallRequest(
        project_id=project_id,
        entry_type=None,
        importance=None,
        limit=50,
    ))
    memory_entries = [e.to_dict() for e in memory_entries_result]

    assumptions = _collect_assumptions(memory_db_path, project_id)

    # ── Render inner content ───────────────────────────────────────────────
    inner_content = render_managed_section(
        project_id=project_id,
        project_name=project_name,
        stack=stack,
        artifacts=artifacts,
        memory_entries=memory_entries,
        assumptions=assumptions,
        task=task,
    )
    full_section = build_managed_section(inner_content)

    if dry_run:
        from epic_claude.sync.claude_md import sha256
        return {
            "state": "DRY_RUN",
            "synced": False,
            "dry_run": True,
            "preview": full_section,
            "content_hash": sha256(inner_content),
            "message": "Dry run — nothing written.",
        }

    # ── Check for manual edits ─────────────────────────────────────────────
    if not force and claude_md_path.exists():
        existing_content = claude_md_path.read_text(encoding="utf-8")
        last_sync = get_last_sync(project_id, memory_db_path)
        last_hash = last_sync.get("content_hash") if last_sync else None

        if detect_manual_edit(existing_content, last_hash):
            logger.warning(
                "Manual edit detected in managed section | project=%s", project_id
            )
            return {
                "state": "MANUAL_EDIT_DETECTED",
                "synced": False,
                "manual_edit": True,
                "last_hash": last_hash,
                "message": (
                    "⚠ Manual edit detected inside EPIC-Claude managed section.\n"
                    "Pass force=True to overwrite, or use epic-claude sync --rollback to restore."
                ),
            }

    # ── Run state machine ──────────────────────────────────────────────────
    backup_dir = claude_md_backups_dir(project_id) if callable(claude_md_backups_dir) else (
        projects_dir / project_id / "claude_md_backups"
    )

    ctx = SyncContext(
        project_id=project_id,
        claude_md_path=claude_md_path,
        triggered_by=triggered_by,
        task=task,
        artifact_ids=[a.get("id", "") for a in artifacts],
    )

    machine = SyncStateMachine(memory_db_path)

    def backup_fn(c: SyncContext) -> Path:
        return create_backup(c.claude_md_path, backup_dir)

    def write_fn(c: SyncContext):
        result = write_managed_section(c.claude_md_path, full_section)
        return result.start_line, result.end_line, result.content_hash

    def restore_fn(c: SyncContext) -> None:
        if c.backup_path:
            restore_from_backup(c.claude_md_path, c.backup_path)

    def verify_fn(c: SyncContext) -> None:
        if c.content_hash:
            verify_section_written(c.claude_md_path, c.content_hash)

    ctx = machine.run(ctx, write_fn, backup_fn, restore_fn, verify_fn)

    # Cleanup old backups (non-fatal)
    try:
        cleanup_old_backups(backup_dir)
    except Exception as exc:
        logger.warning("Backup cleanup failed (non-fatal): %s", exc)

    # Update registry last_sync
    if ctx.state == SyncState.DONE:
        registry = RegistryStore(registry_db_path)
        registry.open()
        try:
            registry.update_fields(
                project_id,
                last_sync_at=_now(),
                last_sync_state=ctx.state,
                claude_md_path=str(claude_md_path),
            )
        finally:
            registry.close()

    message = user_message_for_state(ctx) if ctx.state != SyncState.DONE else (
        f"✓ CLAUDE.md synced successfully | lines {ctx.section_start_line}-{ctx.section_end_line}"
    )

    return {
        "state": ctx.state,
        "synced": ctx.state == SyncState.DONE,
        "message": message,
        "section_start_line": ctx.section_start_line,
        "section_end_line": ctx.section_end_line,
        "content_hash": ctx.content_hash,
        "backup_path": str(ctx.backup_path) if ctx.backup_path else None,
        "duration_ms": ctx.duration_ms,
    }


# ---------------------------------------------------------------------------
# context_recall — task-scoped context without writing
# ---------------------------------------------------------------------------

def context_recall(
    project_id: str,
    task: str,
    memory_db_path: Path,
    registry_db_path: Path,
    limit: int = 10,
) -> dict[str, Any]:
    """
    Return task-relevant architectural context without writing to CLAUDE.md.

    PRD §13 EC-F006: task-aware context recall.
    """
    registry = RegistryStore(registry_db_path)
    registry.open()
    try:
        project = registry.require_by_id(project_id)
        project_name = project.name
    finally:
        registry.close()

    stack_result = get_stack(project_id, memory_db_path)
    stack = stack_result["stack"]

    store = get_store(project_id, memory_db_path)
    entries = store.recall(RecallRequest(
        project_id=project_id,
        query=task,
        limit=limit,
    ))
    memory_entries = [e.to_dict() for e in entries]

    context_text = render_recall_context(
        project_name=project_name,
        stack=stack,
        memory_entries=memory_entries,
        task=task,
        limit=limit,
    )

    return {
        "project_id": project_id,
        "task": task,
        "context": context_text,
        "memory_entries": memory_entries,
        "entry_count": len(memory_entries),
    }


# ---------------------------------------------------------------------------
# Rollback
# ---------------------------------------------------------------------------

def rollback_sync(
    project_id: str,
    claude_md_path: Path,
    projects_dir: Path,
) -> dict[str, Any]:
    """
    Restore CLAUDE.md from the most recent backup.
    Used by: epic-claude sync --rollback
    """
    backup_dir = projects_dir / project_id / "claude_md_backups"
    latest = get_latest_backup(backup_dir)

    if latest is None:
        return {
            "success": False,
            "message": "No backup found. Cannot rollback.",
        }

    try:
        restore_from_backup(claude_md_path, latest)
        return {
            "success": True,
            "message": f"CLAUDE.md restored from {latest.name}",
            "backup_used": str(latest),
        }
    except Exception as exc:
        return {
            "success": False,
            "message": f"Rollback failed: {exc}",
        }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _collect_assumptions(memory_db_path: Path, project_id: str) -> list[str]:
    """Collect assumption strings from memory entries."""
    try:
        store = get_store(project_id, memory_db_path)
        entries = store.recall(RecallRequest(
            project_id=project_id,
            entry_type="assumption",
            confidence="low",
            limit=20,
        ))
        return [e.title for e in entries]
    except Exception:
        return []


def _now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()
