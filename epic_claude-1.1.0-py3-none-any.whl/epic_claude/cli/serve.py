"""
CLI command: epic-claude serve

Starts the global MCP server on stdio transport.
PRD §13 EC-F001 acceptance criteria:
  ✓ epic-claude serve starts the server
  ✓ epic-claude serve --dry-run validates config and exits cleanly
"""

from __future__ import annotations

import sys
from pathlib import Path

try:
    import typer
except ImportError:
    typer = None  # type: ignore

from epic_claude.config import EPIC_CLAUDE_HOME, load_config
from epic_claude.registry import SERVER_LOG_PATH, bootstrap_home

serve_app = typer.Typer(help="Start the EPIC-Claude global MCP server.")


@serve_app.callback(invoke_without_command=True)
def serve(
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Validate config and tool registry, then exit without starting.",
    ),
    log_level: str | None = typer.Option(
        None,
        "--log-level",
        help="Override log level (debug|info|warning|error).",
    ),
) -> None:
    """
    Start the EPIC-Claude MCP server (JSON-RPC 2.0 over stdio).

    Add to Claude Code ~/.claude/settings.json:

    \b
    {
      "mcpServers": {
        "epic-claude": {
          "command": "epic-claude",
          "args": ["serve"]
        }
      }
    }
    """
    # Bootstrap home directory (idempotent)
    bootstrap_home()

    # Load config
    config = load_config()

    # Override log level if flag provided
    if log_level:
        valid_levels = {"debug", "info", "warning", "error"}
        if log_level.lower() not in valid_levels:
            typer.echo(
                f"Invalid log level: {log_level!r}. "
                f"Choose from: {', '.join(sorted(valid_levels))}",
                err=True,
            )
            raise typer.Exit(code=1)
        # Pydantic model is frozen — create a new instance with override
        config = config.model_copy(update={"log_level": log_level.lower()})

    # Import here to avoid circular import at module load time
    from epic_claude.server.server import run_server

    exit_code = run_server(
        config=config,
        log_path=SERVER_LOG_PATH,
        dry_run=dry_run,
    )

    if dry_run:
        if exit_code == 0:
            typer.echo("✓ EPIC-Claude server dry run passed.")
        else:
            typer.echo("✗ EPIC-Claude server dry run FAILED. Check server.log.", err=True)

    raise typer.Exit(code=exit_code)
