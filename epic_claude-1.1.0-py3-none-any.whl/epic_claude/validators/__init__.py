"""
Validation Gates for EPIC-Claude.

  gate1.run_gate1()  — Pre-generation checklist (6 checkpoints)
  gate2.run_gate2()  — Per-artifact validators
  gate2.verify_written_file() — Gate 3 post-write checksum
  gate2.compute_sha256()      — SHA256 checksum utility
"""

from epic_claude.validators.gate1 import run_gate1, ChecklistResult, CheckpointResult
from epic_claude.validators.gate2 import (
    run_gate2,
    verify_written_file,
    compute_sha256,
    validate_prd,
    validate_openapi,
    validate_sql,
    validate_stack,
    validate_boundaries,
    ArtifactValidation,
)

__all__ = [
    "run_gate1", "ChecklistResult", "CheckpointResult",
    "run_gate2", "verify_written_file", "compute_sha256",
    "validate_prd", "validate_openapi", "validate_sql",
    "validate_stack", "validate_boundaries", "ArtifactValidation",
]
