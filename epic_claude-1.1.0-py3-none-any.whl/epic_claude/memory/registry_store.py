"""
Registry store — operations on registry.db (Tier 4).

Handles project identity: create, read, update, list.
No architectural content lives here — only identity and status flags.
PRD §12 — registry table.
"""

from __future__ import annotations

import json
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from epic_claude.exceptions import (
    ProjectAlreadyExistsError,
    ProjectNotFoundError,
)
from epic_claude.memory.database import (
    bootstrap_registry_db,
    db_exists,
    open_db,
    read_only,
    transaction,
)
from epic_claude.server.logging import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Data transfer object
# ---------------------------------------------------------------------------

@dataclass
class ProjectRecord:
    id: str
    name: str
    root_path: str
    description: str | None
    project_type: str | None
    clarification_complete: bool
    clarification_rounds: int
    stack_confirmed: bool
    stack_confirmed_at: str | None
    checklist_passed: bool
    architect_generated: bool
    architect_generated_at: str | None
    generated_feature_count: int
    last_sync_at: str | None
    last_sync_state: str | None
    claude_md_path: str | None
    is_active: bool
    created_at: str
    updated_at: str

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> "ProjectRecord":
        return cls(
            id=row["id"],
            name=row["name"],
            root_path=row["root_path"],
            description=row["description"],
            project_type=row["project_type"],
            clarification_complete=bool(row["clarification_complete"]),
            clarification_rounds=row["clarification_rounds"],
            stack_confirmed=bool(row["stack_confirmed"]),
            stack_confirmed_at=row["stack_confirmed_at"],
            checklist_passed=bool(row["checklist_passed"]),
            architect_generated=bool(row["architect_generated"]),
            architect_generated_at=row["architect_generated_at"],
            generated_feature_count=row["generated_feature_count"],
            last_sync_at=row["last_sync_at"],
            last_sync_state=row["last_sync_state"],
            claude_md_path=row["claude_md_path"],
            is_active=bool(row["is_active"]),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "root_path": self.root_path,
            "description": self.description,
            "project_type": self.project_type,
            "clarification_complete": self.clarification_complete,
            "clarification_rounds": self.clarification_rounds,
            "stack_confirmed": self.stack_confirmed,
            "stack_confirmed_at": self.stack_confirmed_at,
            "checklist_passed": self.checklist_passed,
            "architect_generated": self.architect_generated,
            "architect_generated_at": self.architect_generated_at,
            "generated_feature_count": self.generated_feature_count,
            "last_sync_at": self.last_sync_at,
            "last_sync_state": self.last_sync_state,
            "claude_md_path": self.claude_md_path,
            "is_active": self.is_active,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


# ---------------------------------------------------------------------------
# Registry Store
# ---------------------------------------------------------------------------

class RegistryStore:
    """CRUD operations on registry.db."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self._conn: sqlite3.Connection | None = None

    def open(self) -> None:
        if not db_exists(self.db_path):
            bootstrap_registry_db(self.db_path)
        self._conn = open_db(self.db_path)

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("RegistryStore not opened. Call open() first.")
        return self._conn

    # -----------------------------------------------------------------------
    # Create
    # -----------------------------------------------------------------------

    def create_project(
        self,
        name: str,
        root_path: str,
        description: str | None = None,
        project_type: str | None = None,
    ) -> ProjectRecord:
        """
        Register a new project. Raises ProjectAlreadyExistsError if root_path
        is already registered (UNIQUE constraint).
        """
        existing = self.get_by_root_path(root_path)
        if existing and existing.is_active:
            raise ProjectAlreadyExistsError(
                f"Project already registered at: {root_path}",
                detail={"root_path": root_path, "existing_id": existing.id},
            )

        project_id = str(uuid.uuid4())
        now = _utcnow()

        try:
            with transaction(self.conn, str(self.db_path)):
                self.conn.execute(
                    """
                    INSERT INTO registry (
                        id, name, root_path, description, project_type,
                        is_active, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, 1, ?, ?)
                    """,
                    (project_id, name, root_path, description, project_type, now, now),
                )
        except sqlite3.IntegrityError as exc:
            raise ProjectAlreadyExistsError(
                f"Project already exists at root_path: {root_path}"
            ) from exc

        logger.info("Project created: %s | name=%s | path=%s", project_id, name, root_path)
        return self.get_by_id(project_id)

    # -----------------------------------------------------------------------
    # Read
    # -----------------------------------------------------------------------

    def get_by_id(self, project_id: str) -> ProjectRecord | None:
        with read_only(self.conn):
            row = self.conn.execute(
                "SELECT * FROM registry WHERE id = ?", (project_id,)
            ).fetchone()
        return ProjectRecord.from_row(row) if row else None

    def get_by_root_path(self, root_path: str) -> ProjectRecord | None:
        with read_only(self.conn):
            row = self.conn.execute(
                "SELECT * FROM registry WHERE root_path = ?", (root_path,)
            ).fetchone()
        return ProjectRecord.from_row(row) if row else None

    def list_active(self) -> list[ProjectRecord]:
        with read_only(self.conn):
            rows = self.conn.execute(
                "SELECT * FROM registry WHERE is_active = 1 ORDER BY created_at DESC"
            ).fetchall()
        return [ProjectRecord.from_row(r) for r in rows]

    # -----------------------------------------------------------------------
    # Update (patch individual fields)
    # -----------------------------------------------------------------------

    def update_fields(self, project_id: str, **fields: Any) -> ProjectRecord:
        """
        Update one or more fields on a project record.
        Always updates updated_at.
        """
        if not fields:
            return self.get_by_id(project_id)

        allowed = {
            "name", "description", "project_type",
            "clarification_complete", "clarification_rounds",
            "stack_confirmed", "stack_confirmed_at",
            "checklist_passed",
            "architect_generated", "architect_generated_at",
            "generated_feature_count",
            "last_sync_at", "last_sync_state",
            "claude_md_path", "is_active",
        }
        invalid = set(fields) - allowed
        if invalid:
            raise ValueError(f"Cannot update unknown field(s): {invalid}")

        fields["updated_at"] = _utcnow()
        set_clause = ", ".join(f"{k} = ?" for k in fields)
        values = list(fields.values()) + [project_id]

        with transaction(self.conn, str(self.db_path)):
            self.conn.execute(
                f"UPDATE registry SET {set_clause} WHERE id = ?", values
            )

        record = self.get_by_id(project_id)
        if record is None:
            raise ProjectNotFoundError(f"Project not found after update: {project_id}")
        return record

    def require_by_id(self, project_id: str) -> ProjectRecord:
        """Get by ID, raising ProjectNotFoundError if missing."""
        record = self.get_by_id(project_id)
        if record is None:
            raise ProjectNotFoundError(
                f"Project not found: {project_id}",
                detail={"project_id": project_id},
            )
        return record


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()
