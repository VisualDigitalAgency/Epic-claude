"""
EPIC-Claude server logger.

All server activity is written to ~/.epic/server.log.
NEVER to stdio — stdio is reserved exclusively for JSON-RPC 2.0 wire traffic.

PRD §13 EC-F001:
  - Log to ~/.epic/server.log
  - Rotation: 10 MB max, 5 backups
  - Levels: debug / info / warning / error (configurable)
PRD §18 Security:
  - server.log created with mode 600 (owner read/write only)
"""

from __future__ import annotations

import logging
import os
import stat
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from epic_claude.config import EpicClaudeConfig


# Module-level logger — all server code uses `get_logger(__name__)`
_root_logger_name = "epic_claude"


def setup_server_logging(config: "EpicClaudeConfig", log_path: Path) -> None:
    """
    Configure the rotating file logger.
    Called once at server startup — idempotent (clears existing handlers).

    Args:
        config:   Loaded EpicClaudeConfig (supplies level, max_bytes, backup_count)
        log_path: Full path to server.log (e.g. ~/.epic/server.log)
    """
    # Ensure parent directory exists with correct permissions
    log_path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)

    # Resolve log level
    level_map = {
        "debug":   logging.DEBUG,
        "info":    logging.INFO,
        "warning": logging.WARNING,
        "error":   logging.ERROR,
    }
    level = level_map.get(config.log_level.lower(), logging.INFO)

    # Root logger for the entire epic_claude package
    root = logging.getLogger(_root_logger_name)
    root.setLevel(level)

    # Clear any handlers added by previous calls (idempotent)
    root.handlers.clear()

    # Rotating file handler — PRD §18: 10 MB × 5 backups
    handler = RotatingFileHandler(
        filename=str(log_path),
        maxBytes=config.log_max_bytes,
        backupCount=config.log_backup_count,
        encoding="utf-8",
    )
    handler.setLevel(level)
    handler.setFormatter(_make_formatter())
    root.addHandler(handler)

    # Enforce mode 600 on the log file after creation
    _enforce_log_permissions(log_path)

    # Prevent propagation to the root Python logger (which might touch stderr)
    root.propagate = False

    root.info(
        "EPIC-Claude server logging initialised | level=%s | path=%s",
        config.log_level,
        log_path,
    )


def get_logger(name: str) -> logging.Logger:
    """
    Return a logger namespaced under 'epic_claude'.
    Usage: logger = get_logger(__name__)
    """
    if name.startswith(_root_logger_name):
        return logging.getLogger(name)
    return logging.getLogger(f"{_root_logger_name}.{name}")


def _make_formatter() -> logging.Formatter:
    return logging.Formatter(
        fmt="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )


def _enforce_log_permissions(log_path: Path) -> None:
    """Set log file to mode 600 if it exists."""
    if log_path.exists():
        current = stat.S_IMODE(log_path.stat().st_mode)
        if current != 0o600:
            try:
                log_path.chmod(0o600)
            except OSError:
                # On some systems (e.g. Windows) chmod is limited — non-fatal
                pass
